<?php

$siteName = 'THAI818';
$registerUrl = 'https://www.thai818.net/?rc=thai818vip1';

require_once __DIR__ . '/helpers.php';

header('Content-Type: application/xml; charset=utf-8');

$contents = loadContents(__DIR__ . '/contents.json');
$baseUrl = rtrim(buildBaseUrl(), '/') . '/';
$maxUrlsPerSitemap = 500;

$urls = array($baseUrl);

foreach ($contents as $item) {
    if (empty($item['slug'])) {
        continue;
    }

    $urls[] = $baseUrl . rawurlencode((string) $item['slug']);
}

$chunks = array_chunk($urls, $maxUrlsPerSitemap);

if (empty($chunks)) {
    $chunks = array(array());
}

$requestUri = isset($_SERVER['REQUEST_URI']) ? $_SERVER['REQUEST_URI'] : '';
$requestPath = parse_url($requestUri, PHP_URL_PATH);
$requestFile = $requestPath !== null ? basename($requestPath) : '';

$isChunkRequest = false;
$chunkNumber = null;

if (preg_match('/^sitemap-(\d+)\.xml$/', $requestFile, $match)) {
    $isChunkRequest = true;
    $chunkNumber = (int) $match[1];
} elseif (isset($_GET['page'])) {
    $potential = (int) $_GET['page'];
    if ($potential > 0) {
        $isChunkRequest = true;
        $chunkNumber = $potential;
    }
}

if ($isChunkRequest) {
    outputSitemapChunk($chunks, $chunkNumber);
    return;
}

outputSitemapIndex($chunks, $baseUrl);

function outputSitemapIndex($chunks, $baseUrl)
{
    $chunkCount = count($chunks);

    echo '<?xml version="1.0" encoding="UTF-8"?>' . "\n";
    echo '<sitemapindex xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">' . "\n";

    for ($i = 1; $i <= $chunkCount; $i++) {
        $sitemapUrl = $baseUrl . 'sitemap-' . $i . '.xml';
        echo "  <sitemap>\n";
        echo '    <loc>' . htmlspecialchars($sitemapUrl, ENT_XML1) . "</loc>\n";
        echo "  </sitemap>\n";
    }

    echo '</sitemapindex>';
}

function outputSitemapChunk($chunks, $chunkNumber)
{
    if ($chunkNumber === null || $chunkNumber < 1 || $chunkNumber > count($chunks)) {
        http_response_code(404);
        echo '<?xml version="1.0" encoding="UTF-8"?>' . "\n";
        echo '<error>ร้องขอแผนผังเว็บไซต์ไม่ถูกต้อง</error>';
        return;
    }

    echo '<?xml version="1.0" encoding="UTF-8"?>' . "\n";
    echo '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">' . "\n";

    foreach ($chunks[$chunkNumber - 1] as $url) {
        if ($url === '') {
            continue;
        }

        echo "  <url>\n";
        echo '    <loc>' . htmlspecialchars($url, ENT_XML1) . "</loc>\n";
        echo "  </url>\n";
    }

    echo '</urlset>';
}
