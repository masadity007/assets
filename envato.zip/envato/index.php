<?php

$siteName = 'THAI818';
$registerUrl = 'https://www.thai818.net/?rc=thai818vip1';

require_once __DIR__ . '/helpers.php';
$contents = loadContents(__DIR__ . '/contents.json');

if (empty($contents)) {
    http_response_code(500);
    echo 'การกำหนดค่าเนื้อหาหายไป';
    exit;
}

$slug = detectSlug();
$content = null;

if ($slug !== null && $slug !== '') {
    $content = findContentBySlug($contents, $slug);
    if ($content === null) {
        http_response_code(404);
    }
} else {
    $content = $contents[0];
    $slug = isset($content['slug']) ? $content['slug'] : null;
}

if ($content === null) {
    $content = array();
}
$baseUrl = rtrim(buildBaseUrl(), '/') . '/';
$contentTitle = isset($content['title']) ? $content['title'] : 'ไม่พบเนื้อหา';
$contentDescription = isset($content['description']) ? $content['description'] : '';
$contentImage = isset($content['image']) ? $content['image'] : '';

$imageAlt = $contentTitle;
if (!empty($content['tags']) && is_array($content['tags'])) {
    $imageAlt = implode(', ', $content['tags']);
}

$canonicalUrl = $slug ? $baseUrl . rawurlencode($slug) : $baseUrl;
$canonicalHost = parse_url($canonicalUrl, PHP_URL_HOST);
if (!is_string($canonicalHost) || $canonicalHost === '') {
    $canonicalHost = parse_url($baseUrl, PHP_URL_HOST);
}
$canonicalHost = is_string($canonicalHost) && $canonicalHost !== '' ? $canonicalHost : 'localhost';

$metaImage = $contentImage !== '' ? ensureAbsoluteUrl($contentImage, $baseUrl) : '';

$structuredData = array(
    '@context' => 'https://schema.org',
    '@type' => 'Product',
    'name' => $contentTitle,
);

if ($contentDescription !== '') {
    $structuredData['description'] = $contentDescription;
}

if ($metaImage !== '') {
    $structuredData['image'] = array(
        '@type' => 'ImageObject',
        'url' => $metaImage,
        'caption' => $imageAlt,
    );
}

$positiveNotes = array();
$negativeNotes = array();

if (!empty($content['tags']) && is_array($content['tags'])) {
    $position = 1;
    foreach ($content['tags'] as $tag) {
        if ($position % 2 === 1) {
            $positiveNotes[] = array(
                '@type' => 'ListItem',
                'position' => $position,
                'name' => $tag,
            );
        } else {
            $negativeNotes[] = array(
                '@type' => 'ListItem',
                'position' => $position,
                'name' => $tag,
            );
        }

        $position++;
    }
}

$reviewName = $contentTitle . ' review';

$structuredData['review'] = array(
    '@type' => 'Review',
    'name' => $reviewName,
    'author' => array(
        '@type' => 'Person',
        'name' => isset($content['author']) ? $content['author'] : $siteName,
    ),
    'reviewRating' => array(
        '@type' => 'Rating',
        'ratingValue' => isset($content['rating']) ? (float) $content['rating'] : 5,
        'bestRating' => 5,
        'worstRating' => 1,
    ),
);

if (!empty($positiveNotes)) {
    $structuredData['review']['positiveNotes'] = array(
        '@type' => 'ItemList',
        'itemListElement' => $positiveNotes,
    );
}

if (!empty($negativeNotes)) {
    $structuredData['review']['negativeNotes'] = array(
        '@type' => 'ItemList',
        'itemListElement' => $negativeNotes,
    );
}

$structuredData['aggregateRating'] = array(
    '@type' => 'AggregateRating',
    'ratingValue' => isset($content['rating']) ? (float) $content['rating'] : 5,
    'reviewCount' => isset($content['review_count']) ? (int) $content['review_count'] : 1,
    'bestRating' => 5,
    'worstRating' => 1,
);

$structuredDataJson = json_encode($structuredData);

$otherContents = array();
foreach ($contents as $item) {
    $itemSlug = isset($item['slug']) ? $item['slug'] : '';
    $currentSlug = isset($content['slug']) ? $content['slug'] : '';
    if ($itemSlug !== '' && $itemSlug !== $currentSlug) {
        $otherContents[] = $item;
    }
}

if (count($otherContents) > 1) {
    shuffle($otherContents);
    $otherContents = array_slice($otherContents, 0, 6);
}

?>
<!doctype html>
<html
    class="js audio audio-ogg audio-mp3 audio-opus audio-wav audio-m4a cors cssanimations backgroundblendmode flexbox inputtypes-search inputtypes-tel inputtypes-url inputtypes-email no-inputtypes-datetime inputtypes-date inputtypes-month inputtypes-week inputtypes-time inputtypes-datetime-local inputtypes-number inputtypes-range inputtypes-color localstorage placeholder svg xhr2 translated-ltr audio audio-ogg audio-mp3 audio-opus audio-wav audio-m4a cors cssanimations backgroundblendmode flexbox inputtypes-search inputtypes-tel inputtypes-url inputtypes-email no-inputtypes-datetime inputtypes-date inputtypes-month inputtypes-week inputtypes-time inputtypes-datetime-local inputtypes-number inputtypes-range inputtypes-color localstorage placeholder svg xhr2 audio audio-ogg audio-mp3 audio-opus audio-wav audio-m4a cors cssanimations backgroundblendmode flexbox inputtypes-search inputtypes-tel inputtypes-url inputtypes-email no-inputtypes-datetime inputtypes-date inputtypes-month inputtypes-week inputtypes-time inputtypes-datetime-local inputtypes-number inputtypes-range inputtypes-color localstorage placeholder svg xhr2 audio audio-ogg audio-mp3 audio-opus audio-wav audio-m4a cors cssanimations backgroundblendmode flexbox inputtypes-search inputtypes-tel inputtypes-url inputtypes-email no-inputtypes-datetime inputtypes-date inputtypes-month inputtypes-week inputtypes-time inputtypes-datetime-local inputtypes-number inputtypes-range inputtypes-color localstorage placeholder svg xhr2"
    lang="th"
>
    <!--<!
    [endif]--><head>
        <style class="vjs-styles-defaults">
            .video-js {
                width: 300px;
                height: 150px;
            }

            .vjs-fluid {
                padding-top: 56.25%;
            }
        </style>
        <style>
            body,
            button,
            input,
            select,
            textarea {
                font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif !important;
                font-feature-settings: 'kern';
            }

            .dynamic-description {
                font-size: 1rem;
                line-height: 1.65;
                color: #1f2933;
                margin-bottom: 1.5rem;
            }

            .dynamic-description--warning {
                color: #b91c1c;
                font-weight: 600;
            }

            .dynamic-tags {
                list-style: none;
                padding: 0;
                margin: 1.5rem 0;
                display: flex;
                flex-wrap: wrap;
                gap: 0.5rem;
            }

            .dynamic-tags li {
                list-style: none;
                background: #e0f2fe;
                color: #035388;
                padding: 0.35rem 0.85rem;
                border-radius: 999px;
                font-size: 0.9rem;
            }

            .dynamic-related {
                margin-top: 2.5rem;
            }

            .dynamic-related ul {
                list-style: none;
                padding: 0;
                display: grid;
                gap: 0.75rem;
            }

            .dynamic-related li {
                list-style: none;
            }

            .dynamic-related li a {
                display: flex;
                gap: 0.75rem;
                align-items: center;
                padding: 0.75rem;
                border: 1px solid #e2e8f0;
                border-radius: 0.85rem;
                text-decoration: none;
                background: #fff;
                color: inherit;
                box-shadow: 0 6px 16px rgba(15, 23, 42, 0.08);
            }

            .dynamic-related li a:hover {
                border-color: #bfdbfe;
                box-shadow: 0 10px 24px rgba(15, 23, 42, 0.12);
            }

            .dynamic-related li img {
                width: 72px;
                height: 72px;
                aspect-ratio: 1 / 1;
                object-fit: cover;
                border-radius: 0.65rem;
                flex-shrink: 0;
                background: #e2e8f0;
            }

            .dynamic-related li span {
                display: flex;
                flex-direction: column;
                gap: 0.25rem;
                font-size: 0.95rem;
                color: #0f172a;
            }

            .dynamic-related li span small {
                color: #475569;
                font-size: 0.85rem;
            }

            .item-preview__placeholder {
                display: flex;
                align-items: center;
                justify-content: center;
                min-height: 240px;
                background: linear-gradient(135deg, #1d4ed8, #0ea5e9);
                color: #fff;
                font-weight: 600;
                border-radius: 1rem;
                padding: 1rem;
                text-align: center;
            }
        </style>
        <meta charset="utf-8" />
        <script nonce="OsU5/5mFiAlhOIba8K9gyA==">
            //<![CDATA[
            window.DATADOG_CONFIG = {
                clientToken: 'puba7a42f353afa86efd9e11ee56e5fc8d9',
                applicationId: '8561f3f6-5252-482b-ba9f-2bbb1b009106',
                site: 'datadoghq.com',
                service: 'marketplace',
                env: 'production',
                version: '6846b2b115d860375179e29d9649192007c3597e',
                sessionSampleRate: 0.2,
                sessionReplaySampleRate: 5
            };

            //]]>
        </script>
        <script nonce="OsU5/5mFiAlhOIba8K9gyA==">
            //<![CDATA[
            var rollbarEnvironment = 'production';
            var codeVersion = '6846b2b115d860375179e29d9649192007c3597e';

            //]]>
        </script>

        <meta content="origin-when-cross-origin" name="referrer" />
        <meta name="googlebot" content="notranslate">
        <meta name="googlebot-news" content="nosnippet">

        <link rel="dns-prefetch" href="//s3.envato.com" />
        <link rel="preconnect" href="https://public-assets.envato-static.com" crossorigin />
        <link rel="preconnect" href="https://pub-490fa8a925f141529611df33dc64d833.r2.dev" crossorigin />
        <link
            rel="preload"
            href="https://public-assets.envato-static.com/assets/generated_sprites/logos-20f56d7ae7a08da2c6698db678490c591ce302aedb1fcd05d3ad1e1484d3caf9.png"
            as="image"
        />
        <link
            rel="preload"
            href="https://public-assets.envato-static.com/assets/generated_sprites/common-5af54247f3a645893af51456ee4c483f6530608e9c15ca4a8ac5a6e994d9a340.png"
            as="image"
        />

        <title><?php echo htmlspecialchars($contentTitle, ENT_QUOTES, 'UTF-8'); ?></title>

        <?php if ($contentDescription !== ''): ?>
            <meta name="description" content="<?php echo htmlspecialchars($contentDescription, ENT_QUOTES, 'UTF-8'); ?>" />
        <?php endif; ?>

        <meta name="viewport" content="width=device-width,initial-scale=1" />

        <link
            rel="icon"
            type="image/x-icon"
            href="https://public-assets.envato-static.com/assets/icons/favicons/favicon-1147a1221bfa55e7ee6678c2566ccd7580fa564fe2172489284a1c0b1d8d595d.png"
        />
        <link
            rel="apple-touch-icon-precomposed"
            type="image/x-icon"
            href="https://public-assets.envato-static.com/assets/icons/favicons/apple-touch-icon-72x72-precomposed-ea6fb08063069270d41814bdcea6a36fee5fffaba8ec1f0be6ccf3ebbb63dddb.png"
            sizes="72x72"
        />
        <link
            rel="apple-touch-icon-precomposed"
            type="image/x-icon"
            href="https://public-assets.envato-static.com/assets/icons/favicons/apple-touch-icon-114x114-precomposed-bab982e452fbea0c6821ffac2547e01e4b78e1df209253520c7c4e293849c4d3.png"
            sizes="114x114"
        />
        <link
            rel="apple-touch-icon-precomposed"
            type="image/x-icon"
            href="https://public-assets.envato-static.com/assets/icons/favicons/apple-touch-icon-120x120-precomposed-8275dc5d1417e913b7bd8ad048dccd1719510f0ca4434f139d675172c1095386.png"
            sizes="120x120"
        />
        <link
            rel="apple-touch-icon-precomposed"
            type="image/x-icon"
            href="https://public-assets.envato-static.com/assets/icons/favicons/apple-touch-icon-144x144-precomposed-c581101b4f39d1ba1c4a5e45edb6b3418847c5c387b376930c6a9922071c8148.png"
            sizes="144x144"
        />
        <link
            rel="apple-touch-icon-precomposed"
            type="image/x-icon"
            href="https://public-assets.envato-static.com/assets/icons/favicons/apple-touch-icon-precomposed-c581101b4f39d1ba1c4a5e45edb6b3418847c5c387b376930c6a9922071c8148.png"
        />

        <link
            rel="preload"
            href="https://public-assets.envato-static.com/assets/market/core/index-d4d5d605227bb1918ca2bf258903e05dafa2c30a838fb6b341217c50b9e6e426.css"
            as="style"
            onload="this.onload=null;this.rel='stylesheet'"
        />
        <noscript>
            <link
                rel="stylesheet"
                href="https://public-assets.envato-static.com/assets/market/core/index-d4d5d605227bb1918ca2bf258903e05dafa2c30a838fb6b341217c50b9e6e426.css"
                media="all"
            />
        </noscript>
        <link
            rel="preload"
            href="https://public-assets.envato-static.com/assets/market/pages/default/index-cb8a909494e9edf684326b1d50af6c08c3378137901a82b5544f78d18d32ef20.css"
            as="style"
            onload="this.onload=null;this.rel='stylesheet'"
        />
        <noscript>
            <link
                rel="stylesheet"
                href="https://public-assets.envato-static.com/assets/market/pages/default/index-cb8a909494e9edf684326b1d50af6c08c3378137901a82b5544f78d18d32ef20.css"
                media="all"
            />
        </noscript>

        <script
            src="https://public-assets.envato-static.com/assets/components/brand_neue_tokens-be163cc4f2a1ec0b34ca166b7f51d683a268a0c06fedbb93e3a563f8ddfa7837.js"
            nonce="OsU5/5mFiAlhOIba8K9gyA=="
            defer="defer"
        ></script>
        <meta name="theme-color" content="#333333" />

        <link rel="canonical" href="<?php echo htmlspecialchars($canonicalUrl, ENT_QUOTES, 'UTF-8'); ?>" />
        <?php if ($metaImage !== ''): ?>
            <link rel="preload" as="image" href="<?php echo htmlspecialchars($metaImage, ENT_QUOTES, 'UTF-8'); ?>" fetchpriority="high" />
        <?php endif; ?>

        <meta property="og:title" content="<?php echo htmlspecialchars($contentTitle, ENT_QUOTES, 'UTF-8'); ?>" />
        <?php if ($contentDescription !== ''): ?>
            <meta property="og:description" content="<?php echo htmlspecialchars($contentDescription, ENT_QUOTES, 'UTF-8'); ?>" />
        <?php endif; ?>
        <meta property="og:url" content="<?php echo htmlspecialchars($canonicalUrl, ENT_QUOTES, 'UTF-8'); ?>" />
        <meta property="og:type" content="product" />
        <meta property="og:site_name" content="<?php echo htmlspecialchars($siteName, ENT_QUOTES, 'UTF-8'); ?>" />
        <?php if ($metaImage !== ''): ?>
            <meta property="og:image" content="<?php echo htmlspecialchars($metaImage, ENT_QUOTES, 'UTF-8'); ?>" />
            <meta property="og:image:alt" content="<?php echo htmlspecialchars($imageAlt, ENT_QUOTES, 'UTF-8'); ?>" />
        <?php endif; ?>

        <meta name="twitter:card" content="<?php echo $metaImage !== '' ? 'summary_large_image' : 'summary'; ?>" />
        <meta name="twitter:title" content="<?php echo htmlspecialchars($contentTitle, ENT_QUOTES, 'UTF-8'); ?>" />
        <?php if ($contentDescription !== ''): ?>
            <meta name="twitter:description" content="<?php echo htmlspecialchars($contentDescription, ENT_QUOTES, 'UTF-8'); ?>" />
        <?php endif; ?>
        <?php if ($metaImage !== ''): ?>
            <meta name="twitter:image" content="<?php echo htmlspecialchars($metaImage, ENT_QUOTES, 'UTF-8'); ?>" />
            <meta name="twitter:image:alt" content="<?php echo htmlspecialchars($imageAlt, ENT_QUOTES, 'UTF-8'); ?>" />
        <?php endif; ?>

        <?php if ($structuredDataJson !== false): ?>
            <script type="application/ld+json"><?php echo $structuredDataJson; ?></script>
        <?php endif; ?>

        <script nonce="OsU5/5mFiAlhOIba8K9gyA==">
            //<![CDATA[
            window.dataLayer = window.dataLayer || [];

            //]]>
        </script>
        <meta name="bingbot" content="nocache" />

        <meta name="twitter:domain" content="<?php echo htmlspecialchars($canonicalHost, ENT_QUOTES, 'UTF-8'); ?>" />

        <meta name="turbo-visit-control" content="reload" />

        <style>
            .brand-neue-button {
                gap: var(--spacing-2x);
                border-radius: var(--roundness-subtle);
                background: var(--color-interactive-primary);
                color: var(--color-content-brand);
                font-family: PolySans-Median;
                font-size: var(--font-size-2x);
                letter-spacing: 0.02em;
                text-align: center;
                padding: 0 20px;
            }
            .brand-neue-button:hover,
            .brand-neue-button:active,
            .brand-neue-button:focus {
                background: var(--color-interactive-primary-hover);
            }

            .brand-neue-button__open-in-new::after {
                font-size: 0;
                margin-left: 5px;
                vertical-align: sub;
                content: url('data:image/svg+xml,<svg width="14" height="14" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg"><g id="ico-/-24-/-actions-/-open_in_new"><path id="Icon-color" d="M17.5 12.0833V15.8333C17.5 16.7538 16.7538 17.5 15.8333 17.5H4.16667C3.24619 17.5 2.5 16.7538 2.5 15.8333V4.16667C2.5 3.24619 3.24619 2.5 4.16667 2.5H7.91667C8.14679 2.5 8.33333 2.68655 8.33333 2.91667V3.75C8.33333 3.98012 8.14679 4.16667 7.91667 4.16667H4.16667V15.8333H15.8333V12.0833C15.8333 11.8532 16.0199 11.6667 16.25 11.6667H17.0833C17.3135 11.6667 17.5 11.8532 17.5 12.0833ZM17.3167 2.91667L17.0917 2.69167C16.98 2.57535 16.8278 2.50668 16.6667 2.5H11.25C11.0199 2.5 10.8333 2.68655 10.8333 2.91667V3.75C10.8333 3.98012 11.0199 4.16667 11.25 4.16667H14.6583L7.625 11.2C7.54612 11.2782 7.50175 11.3847 7.50175 11.4958C7.50175 11.6069 7.54612 11.7134 7.625 11.7917L8.20833 12.375C8.28657 12.4539 8.39307 12.4982 8.50417 12.4982C8.61527 12.4982 8.72176 12.4539 8.8 12.375L15.8333 5.35V8.75C15.8333 8.98012 16.0199 9.16667 16.25 9.16667H17.0833C17.3135 9.16667 17.5 8.98012 17.5 8.75V3.33333C17.4955 3.17342 17.4299 3.02132 17.3167 2.90833V2.91667Z" fill="%231A4200"/></g></svg>');
            }
            /* Reduce layout shift from fonts */
            :root {
                font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif !important;
                font-display: swap;
            }
            /*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL2FwcC9qYXZhc2NyaXB0L2NvbXBvbmVudHMvYnJhbmRfbmV1ZV90b2tlbnMvY29tcG9uZW50cy9idXR0b24uc2FzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLHNCQUFBO0VBQ0Esc0NBQUE7RUFDQSw0Q0FBQTtFQUNBLGlDQUFBO0VBQ0EsNEJBQUE7RUFDQSw4QkFBQTtFQUNBLHNCQUFBO0VBQ0Esa0JBQUE7RUFDQSxlQUFBO0FBQ0Y7QUFBRTtFQUNFLGtEQUFBO0FBRUo7O0FBQ0U7RUFDRSxZQUFBO0VBQ0EsZ0JBQUE7RUFDQSxtQkFBQTtFQUNBLGdEQUFBO0FBRUoiLCJzb3VyY2VzQ29udGVudCI6WyIuYnJhbmQtbmV1ZS1idXR0b25cbiAgZ2FwOiB2YXIoLS1zcGFjaW5nLTJ4KVxuICBib3JkZXItcmFkaXVzOiB2YXIoLS1yb3VuZG5lc3Mtc3VidGxlKVxuICBiYWNrZ3JvdW5kOiB2YXIoLS1jb2xvci1pbnRlcmFjdGl2ZS1wcmltYXJ5KVxuICBjb2xvcjogdmFyKC0tY29sb3ItY29udGVudC1icmFuZClcbiAgZm9udC1mYW1pbHk6IFBvbHlTYW5zLU1lZGlhblxuICBmb250LXNpemU6IHZhcigtLWZvbnQtc2l6ZS0yeClcbiAgbGV0dGVyLXNwYWNpbmc6IDAuMDJlbVxuICB0ZXh0LWFsaWduOiBjZW50ZXJcbiAgcGFkZGluZzogMCAyMHB4XG4gICY6aG92ZXIsICY6YWN0aXZlLCAmOmZvY3VzXG4gICAgYmFja2dyb3VuZDogdmFyKC0tY29sb3ItaW50ZXJhY3RpdmUtcHJpbWFyeS1ob3ZlcilcblxuLmJyYW5kLW5ldWUtYnV0dG9uX19vcGVuLWluLW5ld1xuICAmOjphZnRlclxuICAgIGZvbnQtc2l6ZTogMFxuICAgIG1hcmdpbi1sZWZ0OiA1cHhcbiAgICB2ZXJ0aWNhbC1hbGlnbjogc3ViXG4gICAgY29udGVudDogdXJsKCdkYXRhOmltYWdlL3N2Zyt4bWwsPHN2ZyB3aWR0aD1cIjE0XCIgaGVpZ2h0PVwiMTRcIiB2aWV3Qm94PVwiMCAwIDIwIDIwXCIgZmlsbD1cIm5vbmVcIiB4bWxucz1cImh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnXCI+PGcgaWQ9XCJpY28tLy0yNC0vLWFjdGlvbnMtLy1vcGVuX2luX25ld1wiPjxwYXRoIGlkPVwiSWNvbi1jb2xvclwiIGQ9XCJNMTcuNSAxMi4wODMzVjE1LjgzMzNDMTcuNSAxNi43NTM4IDE2Ljc1MzggMTcuNSAxNS44MzMzIDE3LjVINC4xNjY2N0MzLjI0NjE5IDE3LjUgMi41IDE2Ljc1MzggMi41IDE1LjgzMzNWNC4xNjY2N0MyLjUgMy4yNDYxOSAzLjI0NjE5IDIuNSA0LjE2NjY3IDIuNUg3LjkxNjY3QzguMTQ2NzkgMi41IDguMzMzMzMgMi42ODY1NSA4LjMzMzMzIDIuOTE2NjdWMy43NUM4LjMzMzMzIDMuOTgwMTIgOC4xNDY3OSA0LjE2NjY3IDcuOTE2NjcgNC4xNjY2N0g0LjE2NjY3VjE1LjgzMzNIMTUuODMzM1YxMi4wODMzQzE1LjgzMzMgMTEuODUzMiAxNi4wMTk5IDExLjY2NjcgMTYuMjUgMTEuNjY2N0gxNy4wODMzQzE3LjMxMzUgMTEuNjY2NyAxNy41IDExLjg1MzIgMTcuNSAxMi4wODMzWk0xNy4zMTY3IDIuOTE2NjdMMTcuMDkxNyAyLjY5MTY3QzE2Ljk4IDIuNTc1MzUgMTYuODI3OCAyLjUwNjY4IDE2LjY2NjcgMi41SDExLjI1QzExLjAxOTkgMi41IDEwLjgzMzMgMi42ODY1NSAxMC44MzMzIDIuOTE2NjdWMy43NUMxMC44MzMzIDMuOTgwMTIgMTEuMDE5OSA0LjE2NjY3IDExLjI1IDQuMTY2NjdIMTQuNjU4M0w3LjYyNSAxMS4yQzcuNTQ2MTIgMTEuMjc4MiA3LjUwMTc1IDExLjM4NDcgNy41MDE3NSAxMS40OTU4QzcuNTAxNzUgMTEuNjA2OSA3LjU0NjEyIDExLjcxMzQgNy42MjUgMTEuNzkxN0w4LjIwODMzIDEyLjM3NUM4LjI4NjU3IDEyLjQ1MzkgOC4zOTMwNyAxMi40OTgyIDguNTA0MTcgMTIuNDk4MkM4LjYxNTI3IDEyLjQ5ODIgOC43MjE3NiAxMi40NTM5IDguOCAxMi4zNzVMMTUuODMzMyA1LjM1VjguNzVDMTUuODMzMyA4Ljk4MDEyIDE2LjAxOTkgOS4xNjY2NyAxNi4yNSA5LjE2NjY3SDE3LjA4MzNDMTcuMzEzNSA5LjE2NjY3IDE3LjUgOC45ODAxMiAxNy41IDguNzVWMy4zMzMzM0MxNy40OTU1IDMuMTczNDIgMTcuNDI5OSAzLjAyMTMyIDE3LjMxNjcgMi45MDgzM1YyLjkxNjY3WlwiIGZpbGw9XCIlMjMxQTQyMDBcIi8+PC9nPjwvc3ZnPicpXG5cbiJdLCJzb3VyY2VSb290IjoiIn0= */
        </style>
        <style type="text/css">
            .fancybox-margin {
                margin-right: 15px;
            }
        </style>
        <style type="text/css">
            /* Copyright 2021 Google Inc. All Rights Reserved. */
            <br > .goog-te-banner-frame {
                left: 0px;
                top: 0px;
                height: 39px;
                width: 100%;
                z-index: 10000001;
                position: fixed;
                border: none;
                border-bottom: 1px solid #6b90da;
                margin: 0;
                -moz-box-shadow: 0 0 8px 1px #999999;
                -webkit-box-shadow: 0 0 8px 1px #999999;
                box-shadow: 0 0 8px 1px #999999;
                _position: absolute;
            }
            .goog-te-menu-frame {
                z-index: 10000002;
                position: fixed;
                border: none;
                -moz-box-shadow: 0 3px 8px 2px #999999;
                -webkit-box-shadow: 0 3px 8px 2px #999999;
                box-shadow: 0 3px 8px 2px #999999;
                _position: absolute;
            }
            .goog-te-ftab-frame {
                z-index: 10000000;
                border: none;
                margin: 0;
            }
            .goog-te-gadget {
                font-family: arial;
                font-size: 11px;
                color: #666;
                white-space: nowrap;
            }
            .goog-te-gadget img {
                vertical-align: middle;
                border: none;
            }
            .goog-te-gadget-simple {
                background-color: #fff;
                border-left: 1px solid #d5d5d5;
                border-top: 1px solid #9b9b9b;
                border-bottom: 1px solid #e8e8e8;
                border-right: 1px solid #d5d5d5;
                font-size: 10pt;
                display: inline-block;
                padding-top: 1px;
                padding-bottom: 2px;
                cursor: pointer;
                zoom: 1;
                *display: inline;
            }
            .goog-te-gadget-icon {
                margin-left: 2px;
                margin-right: 2px;
                width: 19px;
                height: 19px;
                border: none;
                vertical-align: middle;
            }
            .goog-te-combo {
                margin-left: 4px;
                margin-right: 4px;
                vertical-align: baseline;
                *vertical-align: middle;
            }
            .goog-te-gadget .goog-te-combo {
                margin: 4px 0;
            }
            .goog-logo-link,
            .goog-logo-link:link,
            .goog-logo-link:visited,
            .goog-logo-link:hover,
            .goog-logo-link:active {
                font-size: 12px;
                font-weight: bold;
                color: #444;
                text-decoration: none;
            }
            .goog-te-banner .goog-logo-link,
            .goog-close-link {
                display: block;
                margin: 0px 10px;
            }
            .goog-te-banner .goog-logo-link {
                padding-top: 2px;
                padding-left: 4px;
            }
            .goog-te-combo,
            .goog-te-banner *,
            .goog-te-ftab *,
            .goog-te-menu *,
            .goog-te-menu2 *,
            .goog-te-balloon * {
                font-family: arial;
                font-size: 10pt;
            }
            .goog-te-banner {
                margin: 0;
                background-color: #e4effb;
                overflow: hidden;
            }
            .goog-te-banner img {
                border: none;
            }
            .goog-te-banner-content {
                color: #000;
            }
            .goog-te-banner-content img {
                vertical-align: middle;
            }
            .goog-te-banner-info {
                color: #666;
                vertical-align: top;
                margin-top: 0px;
                font-size: 7pt;
            }
            .goog-te-banner-margin {
                width: 8px;
            }
            .goog-te-button {
                border-color: #e7e7e7;
                border-style: none solid solid none;
                border-width: 0 1px 1px 0;
            }
            .goog-te-button div {
                border-color: #cccccc #999999 #999999 #cccccc;
                border-right: 1px solid #999999;
                border-style: solid;
                border-width: 1px;
                height: 20px;
            }
            .goog-te-button button {
                background: transparent;
                border: none;
                cursor: pointer;
                height: 20px;
                overflow: hidden;
                margin: 0;
                vertical-align: top;
                white-space: nowrap;
            }
            .goog-te-button button:active {
                background: none repeat scroll 0 0 #cccccc;
            }
            .goog-te-ftab {
                margin: 0px;
                background-color: #fff;
                white-space: nowrap;
            }
            .goog-te-ftab-link {
                text-decoration: none;
                font-weight: bold;
                font-size: 10pt;
                border: 1px outset #888;
                padding: 6px 10px;
                white-space: nowrap;
                position: absolute;
                left: 0px;
                top: 0px;
            }
            .goog-te-ftab-link img {
                margin-left: 2px;
                margin-right: 2px;
                width: 19px;
                height: 19px;
                border: none;
                vertical-align: middle;
            }
            .goog-te-ftab-link span {
                text-decoration: underline;
                margin-left: 2px;
                margin-right: 2px;
                vertical-align: middle;
            }
            .goog-float-top .goog-te-ftab-link {
                padding: 2px 2px;
                border-top-width: 0px;
            }
            .goog-float-bottom .goog-te-ftab-link {
                padding: 2px 2px;
                border-bottom-width: 0px;
            }
            .goog-te-menu-value {
                text-decoration: none;
                color: #0000cc;
                white-space: nowrap;
                margin-left: 4px;
                margin-right: 4px;
            }
            .goog-te-menu-value span {
                text-decoration: underline;
            }
            .goog-te-menu-value img {
                margin-left: 2px;
                margin-right: 2px;
            }
            .goog-te-gadget-simple .goog-te-menu-value {
                color: #000;
            }
            .goog-te-gadget-simple .goog-te-menu-value span {
                text-decoration: none;
            }
            .goog-te-menu {
                background-color: #ffffff;
                text-decoration: none;
                border: 2px solid #c3d9ff;
                overflow-y: scroll;
                overflow-x: hidden;
                position: absolute;
                left: 0;
                top: 0;
            }
            .goog-te-menu-item {
                padding: 3px;
                text-decoration: none;
            }
            .goog-te-menu-item,
            .goog-te-menu-item:link {
                color: #0000cc;
                background: #ffffff;
            }
            .goog-te-menu-item:visited {
                color: #551a8b;
            }
            .goog-te-menu-item:hover {
                background: #c3d9ff;
            }
            .goog-te-menu-item:active {
                color: #0000cc;
            }
            .goog-te-menu2 {
                background-color: #ffffff;
                text-decoration: none;
                border: 1px solid #6b90da;
                overflow: hidden;
                padding: 4px;
            }
            .goog-te-menu2-colpad {
                width: 16px;
            }
            .goog-te-menu2-separator {
                margin: 6px 0;
                height: 1px;
                background-color: #aaa;
                overflow: hidden;
            }
            .goog-te-menu2-item div,
            .goog-te-menu2-item-selected div {
                padding: 4px;
            }
            .goog-te-menu2-item .indicator {
                display: none;
            }
            .goog-te-menu2-item-selected .indicator {
                display: auto;
            }
            .goog-te-menu2-item-selected .text {
                padding-left: 4px;
                padding-right: 4px;
            }
            .goog-te-menu2-item,
            .goog-te-menu2-item-selected {
                text-decoration: none;
            }
            .goog-te-menu2-item div,
            .goog-te-menu2-item:link div,
            .goog-te-menu2-item:visited div,
            .goog-te-menu2-item:active div {
                color: #0000cc;
                background: #ffffff;
            }
            .goog-te-menu2-item:hover div {
                color: #ffffff;
                background: #3366cc;
            }
            .goog-te-menu2-item-selected div,
            .goog-te-menu2-item-selected:link div,
            .goog-te-menu2-item-selected:visited div,
            .goog-te-menu2-item-selected:hover div,
            .goog-te-menu2-item-selected:active div {
                color: #000;
                font-weight: bold;
            }
            .goog-te-balloon {
                background-color: #ffffff;
                overflow: hidden;
                padding: 8px;
                border: none;
                -moz-border-radius: 10px;
                border-radius: 10px;
            }
            .goog-te-balloon-frame {
                background-color: #ffffff;
                border: 1px solid #6b90da;
                -moz-box-shadow: 0 3px 8px 2px #999999;
                -webkit-box-shadow: 0 3px 8px 2px #999999;
                box-shadow: 0 3px 8px 2px #999999;
                -moz-border-radius: 8px;
                border-radius: 8px;
            }
            .goog-te-balloon img {
                border: none;
            }
            .goog-te-balloon-text {
                margin-top: 6px;
            }
            .goog-te-balloon-zippy {
                margin-top: 6px;
                white-space: nowrap;
            }
            .goog-te-balloon-zippy * {
                vertical-align: middle;
            }
            .goog-te-balloon-zippy .minus {
                background-image: url(//www.google.com/images/zippy_minus_sm.gif);
            }
            .goog-te-balloon-zippy .plus {
                background-image: url(//www.google.com/images/zippy_plus_sm.gif);
            }
            .goog-te-balloon-zippy span {
                color: #00c;
                text-decoration: underline;
                cursor: pointer;
                margin: 0 4px;
            }
            .goog-te-balloon-form {
                margin: 6px 0 0 0;
            }
            .goog-te-balloon-form form {
                margin: 0;
            }
            .goog-te-balloon-form form textarea {
                margin-bottom: 4px;
                width: 100%;
            }
            .goog-te-balloon-footer {
                margin: 6px 0 4px 0;
            }
            .goog-te-spinner-pos {
                z-index: 1000;
                position: fixed;
                transition-delay: 0.6s;
                left: -1000px;
                top: -1000px;
            }
            .goog-te-spinner-animation {
                background: #ccc;
                display: flex;
                align-items: center;
                justify-content: center;
                width: 104px;
                height: 104px;
                border-radius: 50px;
                background: #fff url(data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciLz4=)
                    50% 50% no-repeat;
                transition: all 0.6s ease-in-out;
                transform: scale(0.4);
                opacity: 0;
            }
            .goog-te-spinner-animation-show {
                transform: scale(0.5);
                opacity: 1;
            }
            .goog-te-spinner {
                margin: 2px 0 0 2px;
                animation: goog-te-spinner-rotator 1.4s linear infinite;
            }
            @keyframes goog-te-spinner-rotator {
                0% {
                    transform: rotate(0deg);
                }
                100% {
                    transform: rotate(270deg);
                }
            }
            .goog-te-spinner-path {
                stroke-dasharray: 187;
                stroke-dashoffset: 0;
                stroke: #4285f4;
                transform-origin: center;
                animation: goog-te-spinner-dash 1.4s ease-in-out infinite;
            }
            @keyframes goog-te-spinner-dash {
                0% {
                    stroke-dashoffset: 187;
                }
                50% {
                    stroke-dashoffset: 46.75;
                    transform: rotate(135deg);
                }
                100% {
                    stroke-dashoffset: 187;
                    transform: rotate(450deg);
                }
            }
            #goog-gt-tt html,
            #goog-gt-tt body,
            #goog-gt-tt div,
            #goog-gt-tt span,
            #goog-gt-tt iframe,
            #goog-gt-tt h1,
            #goog-gt-tt h2,
            #goog-gt-tt h3,
            #goog-gt-tt h4,
            #goog-gt-tt h5,
            #goog-gt-tt h6,
            #goog-gt-tt p,
            #goog-gt-tt a,
            #goog-gt-tt img,
            #goog-gt-tt ol,
            #goog-gt-tt ul,
            #goog-gt-tt li,
            #goog-gt-tt table,
            #goog-gt-tt form,
            #goog-gt-tt tbody,
            #goog-gt-tt tr,
            #goog-gt-tt td {
                margin: 0;
                padding: 0;
                border: 0;
                font-size: 100%;
                font: inherit;
                vertical-align: baseline;
                text-align: left;
                line-height: normal;
            }
            #goog-gt-tt ol,
            #goog-gt-tt ul {
                list-style: none;
            }
            #goog-gt-tt table {
                border-collapse: collapse;
                border-spacing: 0;
            }
            #goog-gt-tt caption,
            #goog-gt-tt th,
            #goog-gt-tt td {
                text-align: left;
                font-weight: normal;
            }
            #goog-gt-tt input::-moz-focus-inner {
                border: 0;
            }
            div#goog-gt-tt {
                padding: 10px 14px;
            }
            #goog-gt-tt {
                color: #222;
                background-color: #ffffff;
                border: 1px solid #eee;
                box-shadow: 0 4px 16px rgba(0, 0, 0, 0.2);
                -moz-box-shadow: 0 4px 16px rgba(0, 0, 0, 0.2);
                -webkit-box-shadow: 0 4px 16px rgba(0, 0, 0, 0.2);
                display: none;
                font-family: arial;
                font-size: 10pt;
                width: 420px;
                padding: 12px;
                position: absolute;
                z-index: 10000;
            }
            #goog-gt-tt .original-text,
            .gt-hl-layer {
                clear: both;
                font-size: 10pt;
                position: relative;
                text-align: justify;
                width: 100%;
            }
            #goog-gt-tt .title {
                color: #999;
                font-family: arial, sans-serif;
                margin: 4px 0;
                text-align: left;
            }
            #goog-gt-tt .close-button {
                display: none;
            }
            #goog-gt-tt .logo {
                float: left;
                margin: 0px;
            }
            #goog-gt-tt .activity-links {
                display: inline-block;
            }
            #goog-gt-tt .started-activity-container {
                display: none;
                width: 100%;
            }
            #goog-gt-tt .activity-root {
                margin-top: 20px;
            }
            #goog-gt-tt .left {
                float: left;
            }
            #goog-gt-tt .right {
                float: right;
            }
            #goog-gt-tt .bottom {
                min-height: 15px;
                position: relative;
                height: 1%;
            }
            #goog-gt-tt .status-message {
                background: -moz-linear-gradient(top, #29910d 0%, #20af0e 100%);
                background: -webkit-linear-gradient(top, #29910d 0%, #20af0e 100%);
                background: -o-linear-gradient(top, #29910d 0%, #20af0e 100%);
                background: -ms-linear-gradient(top, #29910d 0%, #20af0e 100%);
                background: linear-gradient(top, #29910d 0%, #20af0e 100%);
                background: #29910d;
                border-radius: 4px;
                -moz-border-radius: 4px;
                -webkit-border-radius: 4px;
                box-shadow: inset 0px 2px 2px #1e6609;
                -moz-box-shadow: inset 0px 2px 2px #1e6609;
                -webkit-box-shadow: inset 0px 2px 2px #1e6609;
                color: white;
                font-size: 9pt;
                font-weight: bolder;
                margin-top: 12px;
                padding: 6px;
                text-shadow: 1px 1px 1px #1e6609;
            }
            #goog-gt-tt .activity-link {
                color: #1155cc;
                cursor: pointer;
                font-family: arial;
                font-size: 11px;
                margin-right: 15px;
                text-decoration: none;
            }
            #goog-gt-tt textarea {
                font-family: arial;
                resize: vertical;
                width: 100%;
                margin-bottom: 10px;
                -webkit-border-radius: 1px;
                -moz-border-radius: 1px;
                border-radius: 1px;
                border: 1px solid #d9d9d9;
                border-top: 1px solid silver;
                font-size: 13px;
                height: auto;
                overflow-y: auto;
                padding: 1px;
            }
            #goog-gt-tt textarea:focus {
                -webkit-box-shadow: inset 0 1px 2px rgba(0, 0, 0, 0.3);
                -moz-box-shadow: inset 0 1px 2px rgba(0, 0, 0, 0.3);
                box-shadow: inset 0 1px 2px rgba(0, 0, 0, 0.3);
                border: 1px solid #4d90fe;
                outline: none;
            }
            #goog-gt-tt .activity-cancel {
                margin-right: 10px;
            }
            #goog-gt-tt .translate-form {
                min-height: 25px;
                vertical-align: middle;
                padding-top: 8px;
            }
            #goog-gt-tt .translate-form .activity-form {
                margin-bottom: 5px;
                margin-bottom: 0px;
            }
            #goog-gt-tt .translate-form .activity-form input {
                display: inline-block;
                min-width: 54px;
                *min-width: 70px;
                border: 1px solid #dcdcdc;
                border: 1px solid rgba(0, 0, 0, 0.1);
                text-align: center;
                color: #444;
                font-size: 11px;
                font-weight: bold;
                height: 27px;
                outline: 0;
                padding: 0 8px;
                vertical-align: middle;
                line-height: 27px;
                margin: 0 16px 0 0;
                box-shadow: 0 1px 2px rgba(0, 0, 0, 0.1);
                -moz-box-shadow: 0 1px 2px rgba(0, 0, 0, 0.1);
                -webkit-box-shadow: 0 1px 2px rgba(0, 0, 0, 0.1);
                -webkit-border-radius: 2px;
                -moz-border-radius: 2px;
                border-radius: 2px;
                -webkit-transition: all 0.218s;
                -moz-transition: all 0.218s;
                -o-transition: all 0.218s;
                transition: all 0.218s;
                background-color: #f5f5f5;
                background-image: -webkit-gradient(linear, left top, left bottom, from(#f5f5f5), to(#f1f1f1));
                background-image: -webkit-linear-gradient(top, #f5f5f5, #f1f1f1);
                background-image: -moz-linear-gradient(top, #f5f5f5, #f1f1f1);
                background-image: -ms-linear-gradient(top, #f5f5f5, #f1f1f1);
                background-image: -o-linear-gradient(top, #f5f5f5, #f1f1f1);
                background-image: linear-gradient(top, #f5f5f5, #f1f1f1);
                -webkit-user-select: none;
                -moz-user-select: none;
                cursor: default;
            }
            #goog-gt-tt .translate-form .activity-form input:hover {
                border: 1px solid #c6c6c6;
                color: #222;
                -webkit-transition: all 0s;
                -moz-transition: all 0s;
                -o-transition: all 0s;
                transition: all 0s;
                background-color: #f8f8f8;
                background-image: -webkit-gradient(linear, left top, left bottom, from(#f8f8f8), to(#f1f1f1));
                background-image: -webkit-linear-gradient(top, #f8f8f8, #f1f1f1);
                background-image: -moz-linear-gradient(top, #f8f8f8, #f1f1f1);
                background-image: -ms-linear-gradient(top, #f8f8f8, #f1f1f1);
                background-image: -o-linear-gradient(top, #f8f8f8, #f1f1f1);
                background-image: linear-gradient(top, #f8f8f8, #f1f1f1);
            }
            #goog-gt-tt .translate-form .activity-form input:active {
                border: 1px solid #c6c6c6;
                color: #333;
                background-color: #f6f6f6;
                background-image: -webkit-gradient(linear, left top, left bottom, from(#f6f6f6), to(#f1f1f1));
                background-image: -webkit-linear-gradient(top, #f6f6f6, #f1f1f1);
                background-image: -moz-linear-gradient(top, #f6f6f6, #f1f1f1);
                background-image: -ms-linear-gradient(top, #f6f6f6, #f1f1f1);
                background-image: -o-linear-gradient(top, #f6f6f6, #f1f1f1);
                background-image: linear-gradient(top, #f6f6f6, #f1f1f1);
            }
            #goog-gt-tt
                .translate-form
                .activity-form
                input:focus
                #goog-gt-tt
                .translate-form
                .activity-form
                input.focus
                #goog-gt-tt
                .translate-form
                .activity-form
                input:active,
            #goog-gt-tt .translate-form .activity-form input:focus:active,
            #goog-gt-tt .translate-form .activity-form input:.focus:active {
                box-shadow: inset 0 0 0 1px rgba(255, 255, 255, 0.5);
                -webkit-box-shadow: inset 0 0 0 1px rgba(255, 255, 255, 0.5);
                -moz-box-shadow: inset 0 0 0 1px rgba(255, 255, 255, 0.5);
            }
            #goog-gt-tt .translate-form .activity-form input:focus,
            #goog-gt-tt .translate-form .activity-form input.focus {
                outline: none;
                border: 1px solid #4d90fe;
                z-index: 4 !important;
            }
            #goog-gt-tt .translate-form .activity-form input.selected {
                background-color: #eeeeee;
                background-image: -webkit-gradient(linear, left top, left bottom, from(#eeeeee), to(#e0e0e0));
                background-image: -webkit-linear-gradient(top, #eeeeee, #e0e0e0);
                background-image: -moz-linear-gradient(top, #eeeeee, #e0e0e0);
                background-image: -ms-linear-gradient(top, #eeeeee, #e0e0e0);
                background-image: -o-linear-gradient(top, #eeeeee, #e0e0e0);
                background-image: linear-gradient(top, #eeeeee, #e0e0e0);
                -webkit-box-shadow: inset 0px 1px 2px rgba(0, 0, 0, 0.1);
                -moz-box-shadow: inset 0px 1px 2px rgba(0, 0, 0, 0.1);
                box-shadow: inset 0px 1px 2px rgba(0, 0, 0, 0.1);
                border: 1px solid #ccc;
                color: #333;
            }
            #goog-gt-tt .translate-form .activity-form input.activity-submit {
                color: white;
                border-color: #3079ed;
                background-color: #4d90fe;
                background-image: -webkit-gradient(linear, left top, left bottom, from(#4d90fe), to(#4787ed));
                background-image: -webkit-linear-gradient(top, #4d90fe, #4787ed);
                background-image: -moz-linear-gradient(top, #4d90fe, #4787ed);
                background-image: -ms-linear-gradient(top, #4d90fe, #4787ed);
                background-image: -o-linear-gradient(top, #4d90fe, #4787ed);
                background-image: linear-gradient(top, #4d90fe, #4787ed);
            }
            #goog-gt-tt
                .translate-form
                .activity-form
                input.activity-submit:hover
                #goog-gt-tt
                .translate-form
                .activity-form
                input.activity-submit:focus,
            #goog-gt-tt
                .translate-form
                .activity-form
                input.activity-submit.focus
                #goog-gt-tt
                .translate-form
                .activity-form
                input.activity-submit:active {
                border-color: #3079ed;
                background-color: #357ae8;
                background-image: -webkit-gradient(linear, left top, left bottom, from(#4d90fe), to(#357ae8));
                background-image: -webkit-linear-gradient(top, #4d90fe, #357ae8);
                background-image: -moz-linear-gradient(top, #4d90fe, #357ae8);
                background-image: -ms-linear-gradient(top, #4d90fe, #357ae8);
                background-image: -o-linear-gradient(top, #4d90fe, #357ae8);
                background-image: linear-gradient(top, #4d90fe, #357ae8);
            }
            #goog-gt-tt .translate-form .activity-form input.activity-submit:hover {
                box-shadow: inset 0 0 0 1px #fff, 0px 1px 1px rgba(0, 0, 0, 0.1);
                -webkit-box-shadow: inset 0 0 0 1px #fff, 0px 1px 1px rgba(0, 0, 0, 0.1);
                -moz-box-shadow: inset 0 0 0 1px #fff, 0px 1px 1px rgba(0, 0, 0, 0.1);
            }
            #goog-gt-tt .translate-form .activity-form input:focus,
            #goog-gt-tt .translate-form .activity-form input.focus,
            #goog-gt-tt .translate-form .activity-form input:active,
            #goog-gt-tt .translate-form .activity-form input:hover,
            #goog-gt-tt .translate-form .activity-form input.activity-submit:focus,
            #goog-gt-tt .translate-form .activity-form input.activity-submit.focus,
            #goog-gt-tt .translate-form .activity-form input.activity-submit:active,
            #goog-gt-tt .translate-form .activity-form input.activity-submit:hover {
                border-color: #3079ed;
            }
            #goog-gt-tt .gray {
                color: #999;
                font-family: arial, sans-serif;
            }
            #goog-gt-tt .alt-helper-text {
                color: #999;
                font-size: 11px;
                font-family: arial, sans-serif;
                margin: 15px 0px 5px 0px;
            }
            #goog-gt-tt .alt-error-text {
                color: #800;
                display: none;
                font-size: 9pt;
            }
            .goog-text-highlight {
                background-color: #c9d7f1;
                -webkit-box-shadow: 2px 2px 4px #9999aa;
                -moz-box-shadow: 2px 2px 4px #9999aa;
                box-shadow: 2px 2px 4px #9999aa;
                box-sizing: border-box;
                -webkit-box-sizing: border-box;
                -moz-box-sizing: border-box;
                position: relative;
            }
            #goog-gt-tt .alt-menu.goog-menu {
                background: #ffffff;
                border: 1px solid #dddddd;
                -webkit-box-shadow: 0px 3px 3px #888;
                -moz-box-shadow: 0px 2px 20px #888;
                box-shadow: 0px 2px 4px #99a;
                min-width: 0;
                outline: none;
                padding: 0;
                position: absolute;
                z-index: 2000;
            }
            #goog-gt-tt .alt-menu .goog-menuitem {
                cursor: pointer;
                padding: 2px 5px 5px;
                margin-right: 0px;
                border-style: none;
            }
            #goog-gt-tt .alt-menu div.goog-menuitem:hover {
                background: #ddd;
            }
            #goog-gt-tt .alt-menu .goog-menuitem h1 {
                font-size: 100%;
                font-weight: bold;
                margin: 4px 0px;
            }
            #goog-gt-tt .alt-menu .goog-menuitem strong {
                color: #345aad;
            }
            #goog-gt-tt .goog-submenu-arrow {
                text-align: right;
                position: absolute;
                right: 0;
                left: auto;
            }
            #goog-gt-tt .goog-menuitem-rtl .goog-submenu-arrow {
                text-align: left;
                position: absolute;
                left: 0;
                right: auto;
            }
            #goog-gt-tt .gt-hl-text,
            #goog-gt-tt .trans-target-highlight {
                background-color: #f1ea00;
                border-radius: 4px;
                -webkit-border-radius: 4px;
                -moz-border-radius: 4px;
                -moz-box-shadow: rgba(0, 0, 0, 0.5) 3px 3px 4px;
                -webkit-box-shadow: rgba(0, 0, 0, 0.5) 3px 3px 4px;
                box-shadow: rgba(0, 0, 0, 0.5) 3px 3px 4px;
                box-sizing: border-box;
                -webkit-box-sizing: border-box;
                -moz-box-sizing: border-box;
                color: #f1ea00;
                cursor: pointer;
                margin: -2px -2px -2px -3px;
                padding: 2px 2px 2px 3px;
                position: relative;
            }
            #goog-gt-tt .trans-target-highlight {
                color: #222;
            }
            #goog-gt-tt .gt-hl-layer {
                color: white;
                position: absolute !important;
            }
            #goog-gt-tt .trans-target,
            #goog-gt-tt .trans-target .trans-target-highlight {
                background-color: #c9d7f1;
                border-radius: 4px 4px 0px 0px;
                -webkit-border-radius: 4px 4px 0px 0px;
                -moz-border-radius: 4px 4px 0px 0px;
                -moz-box-shadow: rgba(0, 0, 0, 0.5) 3px 3px 4px;
                -webkit-box-shadow: rgba(0, 0, 0, 0.5) 3px 3px 4px;
                box-shadow: rgba(0, 0, 0, 0.5) 3px 3px 4px;
                box-sizing: border-box;
                -webkit-box-sizing: border-box;
                -moz-box-sizing: border-box;
                cursor: pointer;
                margin: -2px -2px -2px -3px;
                padding: 2px 2px 3px 3px;
                position: relative;
            }
            #goog-gt-tt span:focus {
                outline: none;
            }
            #goog-gt-tt .trans-edit {
                background-color: transparent;
                border: 1px solid #4d90fe;
                border-radius: 0em;
                -webkit-border-radius: 0em;
                -moz-border-radius: 0em;
                margin: -2px;
                padding: 1px;
            }
            #goog-gt-tt .gt-trans-highlight-l {
                border-left: 2px solid red;
                margin-left: -2px;
            }
            #goog-gt-tt .gt-trans-highlight-r {
                border-right: 2px solid red;
                margin-right: -2px;
            }
            #goog-gt-tt #alt-input {
                padding: 2px;
            }
            #goog-gt-tt #alt-input-text {
                font-size: 11px;
                padding: 2px 2px 3px;
                margin: 0;
                background-color: #fff;
                color: #333;
                border: 1px solid #d9d9d9;
                border-top: 1px solid #c0c0c0;
                display: inline-block;
                vertical-align: top;
                height: 21px;
                box-sizing: border-box;
                -webkit-box-sizing: border-box;
                -moz-box-sizing: border-box;
                -webkit-border-radius: 1px;
            }
            #goog-gt-tt #alt-input-text:hover {
                border: 1px solid #b9b9b9;
                border-top: 1px solid #a0a0a0;
                -webkit-box-shadow: inset 0px 1px 2px rgba(0, 0, 0, 0.1);
                -moz-box-shadow: inset 0px 1px 2px rgba(0, 0, 0, 0.1);
                box-shadow: inset 0px 1px 2px rgba(0, 0, 0, 0.1);
            }
            #goog-gt-tt #alt-input-text:focus {
                -webkit-box-shadow: inset 0px 1px 2px rgba(0, 0, 0, 0.3);
                -moz-box-shadow: inset 0px 1px 2px rgba(0, 0, 0, 0.3);
                box-shadow: inset 0px 1px 2px rgba(0, 0, 0, 0.3);
                outline: none;
                border: 1px solid #4d90fe;
            }
            #goog-gt-tt #alt-input-submit {
                font-size: 11px;
                padding: 2px 6px 3px;
                margin: 0 0 0 2px;
                height: 21px;
            }
            .goog-te-spinner-pos,
            #goog-gt-tt {
                display: none;
            }
        </style>
        <style>
            :root {
                --color-grey-1000: #191919;
                --color-grey-1000-mask: rgb(25 25 25 / 0.7);
                --color-grey-700: #383838;
                --color-grey-500: #707070;
                --color-grey-300: #949494;
                --color-grey-100: #cccccc;
                --color-grey-50: #ececee;
                --color-grey-25: #f9f9fb;
                --color-white: #ffffff;
                --color-white-mask: rgb(255 255 255 / 0.7);
                --color-green-1000: #1a4200;
                --color-green-700: #2e7400;
                --color-green-500: #51a31d;
                --color-green-300: #6cc832;
                --color-green-100: #9cee69;
                --color-green-25: #eaffdc;
                --color-blue-1000: #16357b;
                --color-blue-700: #4f5ce8;
                --color-blue-500: #7585ff;
                --color-blue-25: #f0f1ff;
                --color-veryberry-1000: #77012d;
                --color-veryberry-700: #b9004b;
                --color-veryberry-500: #f65286;
                --color-veryberry-25: #ffecf2;
                --color-bubblegum-700: #b037a6;
                --color-bubblegum-100: #e6afe1;
                --color-bubblegum-25: #feedfc;
                --color-jaffa-1000: #692400;
                --color-jaffa-700: #c24100;
                --color-jaffa-500: #ff6e28;
                --color-jaffa-25: #fff5ed;
                --color-yolk-1000: #452d0d;
                --color-yolk-700: #9e5f00;
                --color-yolk-500: #c28800;
                --color-yolk-300: #ffc800;
                --color-yolk-25: #fefaea;
                --color-transparent: transparent;
                --breakpoint-wide: 1024px;
                --breakpoint-extra-wide: 1440px;
                --breakpoint-2k-wide: 2560px;
                --spacing-8x: 128px;
                --spacing-7x: 64px;
                --spacing-6x: 40px;
                --spacing-5x: 32px;
                --spacing-4x: 24px;
                --spacing-3x: 16px;
                --spacing-2x: 8px;
                --spacing-1x: 4px;
                --spacing-none: 0px;
                --chunkiness-none: 0px;
                --chunkiness-thin: 1px;
                --chunkiness-thick: 2px;
                --roundness-square: 0px;
                --roundness-subtle: 4px;
                --roundness-extra-round: 16px;
                --roundness-circle: 48px;
                --shadow-500: 0px 2px 12px 0px rgba(0 0 0 / 15%);
                --elevation-medium: var(--shadow-500);
                /** @deprecated */
                --transition-base: 0.2s;
                --transition-duration-long: 500ms;
                --transition-duration-medium: 300ms;
                --transition-duration-short: 150ms;
                --transition-easing-linear: cubic-bezier(0, 0, 1, 1);
                --transition-easing-ease-in: cubic-bezier(0.42, 0, 1, 1);
                --transition-easing-ease-in-out: cubic-bezier(0.42, 0, 0.58, 1);
                --transition-easing-ease-out: cubic-bezier(0, 0, 0.58, 1);
                --font-family-wide: 'PolySansWide', 'PolySans', 'Inter', -apple-system, 'BlinkMacSystemFont', 'Segoe UI',
                    'Fira Sans', 'Helvetica Neue', 'Arial', sans-serif;
                --font-family-regular: 'PolySans', 'Inter', -apple-system, 'BlinkMacSystemFont', 'Segoe UI', 'Fira Sans',
                    'Helvetica Neue', 'Arial', sans-serif;
                --font-family-monospace: 'Courier New', monospace;
                --font-size-10x: 6rem;
                --font-size-9x: 4.5rem;
                --font-size-8x: 3rem;
                --font-size-7x: 2.25rem;
                --font-size-6x: 1.875rem;
                --font-size-5x: 1.5rem;
                --font-size-4x: 1.125rem;
                --font-size-3x: 1rem;
                --font-size-2x: 0.875rem;
                --font-size-1x: 0.75rem;
                --font-weight-bulky: 700;
                --font-weight-median: 600;
                --font-weight-neutral: 400;
                --font-spacing-tight: -0.02em;
                --font-spacing-normal: 0;
                --font-spacing-loose: 0.02em;
                --font-height-tight: 1;
                --font-height-normal: 1.5;
                --icon-size-5x: 48px;
                --icon-size-4x: 40px;
                --icon-size-3x: 32px;
                --icon-size-2x: 24px;
                --icon-size-1x: 16px;
                --icon-size-text-responsive: calc(var(--font-size-3x) * 1.5);
                --layer-depth-ceiling: 9999;
                --minimum-touch-area: 40px;
                /* component wiring? ------------------------------------------ */
                --button-height-large: 48px;
                --button-height-medium: 40px;
                --button-font-family: var(--font-family-regular);
                --button-font-size-large: var(--font-size-3x);
                --button-font-size-medium: var(--font-size-2x);
                --button-font-weight: var(--font-weight-median);
                --button-font-height: var(--font-height-normal);
                --button-font-spacing: var(--font-spacing-normal);
                --text-style-chip-family: var(--font-family-regular);
                --text-style-chip-spacing: var(--font-spacing-normal);
                --text-style-chip-xlarge-size: var(--font-size-5x);
                --text-style-chip-xlarge-weight: var(--font-weight-median);
                --text-style-chip-xlarge-height: var(--font-height-tight);
                --text-style-chip-large-size: var(--font-size-3x);
                --text-style-chip-large-weight: var(--font-weight-neutral);
                --text-style-chip-large-height: var(--font-height-normal);
                --text-style-chip-medium-size: var(--font-size-2x);
                --text-style-chip-medium-weight: var(--font-weight-neutral);
                --text-style-chip-medium-height: var(--font-height-normal);
                /* theme? ------------------------------------------------- */
                --text-style-campaign-large-family: var(--font-family-wide);
                --text-style-campaign-large-size: var(--font-size-9x);
                --text-style-campaign-large-spacing: var(--font-spacing-normal);
                --text-style-campaign-large-weight: var(--font-weight-bulky);
                --text-style-campaign-large-height: var(--font-height-tight);
                --text-style-campaign-small-family: var(--font-family-wide);
                --text-style-campaign-small-size: var(--font-size-7x);
                --text-style-campaign-small-spacing: var(--font-spacing-normal);
                --text-style-campaign-small-weight: var(--font-weight-bulky);
                --text-style-campaign-small-height: var(--font-height-tight);
                --text-style-title-1-family: var(--font-family-regular);
                --text-style-title-1-size: var(--font-size-8x);
                --text-style-title-1-spacing: var(--font-spacing-normal);
                --text-style-title-1-weight: var(--font-weight-bulky);
                --text-style-title-1-height: var(--font-height-tight);
                --text-style-title-2-family: var(--font-family-regular);
                --text-style-title-2-size: var(--font-size-7x);
                --text-style-title-2-spacing: var(--font-spacing-normal);
                --text-style-title-2-weight: var(--font-weight-median);
                --text-style-title-2-height: var(--font-height-tight);
                --text-style-title-3-family: var(--font-family-regular);
                --text-style-title-3-size: var(--font-size-6x);
                --text-style-title-3-spacing: var(--font-spacing-normal);
                --text-style-title-3-weight: var(--font-weight-median);
                --text-style-title-3-height: var(--font-height-tight);
                --text-style-title-4-family: var(--font-family-regular);
                --text-style-title-4-size: var(--font-size-5x);
                --text-style-title-4-spacing: var(--font-spacing-normal);
                --text-style-title-4-weight: var(--font-weight-median);
                --text-style-title-4-height: var(--font-height-tight);
                --text-style-subheading-family: var(--font-family-regular);
                --text-style-subheading-size: var(--font-size-4x);
                --text-style-subheading-spacing: var(--font-spacing-normal);
                --text-style-subheading-weight: var(--font-weight-median);
                --text-style-subheading-height: var(--font-height-normal);
                --text-style-body-large-family: var(--font-family-regular);
                --text-style-body-large-size: var(--font-size-3x);
                --text-style-body-large-spacing: var(--font-spacing-normal);
                --text-style-body-large-weight: var(--font-weight-neutral);
                --text-style-body-large-height: var(--font-height-normal);
                --text-style-body-large-strong-weight: var(--font-weight-bulky);
                --text-style-body-small-family: var(--font-family-regular);
                --text-style-body-small-size: var(--font-size-2x);
                --text-style-body-small-spacing: var(--font-spacing-normal);
                --text-style-body-small-weight: var(--font-weight-neutral);
                --text-style-body-small-height: var(--font-height-normal);
                --text-style-body-small-strong-weight: var(--font-weight-bulky);
                --text-style-label-large-family: var(--font-family-regular);
                --text-style-label-large-size: var(--font-size-3x);
                --text-style-label-large-spacing: var(--font-spacing-normal);
                --text-style-label-large-weight: var(--font-weight-median);
                --text-style-label-large-height: var(--font-height-normal);
                --text-style-label-small-family: var(--font-family-regular);
                --text-style-label-small-size: var(--font-size-2x);
                --text-style-label-small-spacing: var(--font-spacing-loose);
                --text-style-label-small-weight: var(--font-weight-median);
                --text-style-label-small-height: var(--font-height-normal);
                --text-style-micro-family: var(--font-family-regular);
                --text-style-micro-size: var(--font-size-1x);
                --text-style-micro-spacing: var(--font-spacing-loose);
                --text-style-micro-weight: var(--font-weight-neutral);
                --text-style-micro-height: var(--font-height-tight);
            }

            .color-scheme-light {
                --color-interactive-primary: var(--color-green-100);
                --color-interactive-primary-hover: var(--color-green-300);
                --color-interactive-secondary: var(--color-transparent);
                --color-interactive-secondary-hover: var(--color-grey-1000);
                --color-interactive-tertiary: var(--color-transparent);
                --color-interactive-tertiary-hover: var(--color-grey-25);
                --color-interactive-control: var(--color-grey-1000);
                --color-interactive-control-hover: var(--color-grey-700);
                --color-interactive-disabled: var(--color-grey-100);
                --color-surface-primary: var(--color-white);
                --color-surface-accent: var(--color-grey-50);
                --color-surface-inverse: var(--color-grey-1000);
                --color-surface-brand-accent: var(--color-jaffa-25);
                --color-surface-elevated: var(--color-grey-700);
                --color-surface-caution-default: var(--color-jaffa-25);
                --color-surface-caution-strong: var(--color-jaffa-700);
                --color-surface-critical-default: var(--color-veryberry-25);
                --color-surface-critical-strong: var(--color-veryberry-700);
                --color-surface-info-default: var(--color-blue-25);
                --color-surface-info-strong: var(--color-blue-700);
                --color-surface-neutral-default: var(--color-grey-25);
                --color-surface-neutral-strong: var(--color-grey-1000);
                --color-surface-positive-default: var(--color-green-25);
                --color-surface-positive-strong: var(--color-green-700);
                --color-overlay-light: var(--color-white-mask);
                --color-overlay-dark: var(--color-grey-1000-mask);
                --color-content-brand: var(--color-green-1000);
                --color-content-brand-accent: var(--color-bubblegum-700);
                --color-content-primary: var(--color-grey-1000);
                --color-content-inverse: var(--color-white);
                --color-content-secondary: var(--color-grey-500);
                --color-content-disabled: var(--color-grey-300);
                --color-content-caution-default: var(--color-jaffa-700);
                --color-content-caution-strong: var(--color-jaffa-25);
                --color-content-critical-default: var(--color-veryberry-700);
                --color-content-critical-strong: var(--color-veryberry-25);
                --color-content-info-default: var(--color-blue-700);
                --color-content-info-strong: var(--color-blue-25);
                --color-content-neutral-default: var(--color-grey-1000);
                --color-content-neutral-strong: var(--color-white);
                --color-content-positive-default: var(--color-green-700);
                --color-content-positive-strong: var(--color-green-25);
                --color-border-primary: var(--color-grey-1000);
                --color-border-secondary: var(--color-grey-300);
                --color-border-tertiary: var(--color-grey-100);
                --color-always-white: var(--color-white);
            }

            .color-scheme-dark {
                --color-interactive-primary: var(--color-green-100);
                --color-interactive-primary-hover: var(--color-green-300);
                --color-interactive-secondary: var(--color-transparent);
                --color-interactive-secondary-hover: var(--color-white);
                --color-interactive-tertiary: var(--color-transparent);
                --color-interactive-tertiary-hover: var(--color-grey-700);
                --color-interactive-control: var(--color-white);
                --color-interactive-control-hover: var(--color-grey-100);
                --color-interactive-disabled: var(--color-grey-700);
                --color-surface-primary: var(--color-grey-1000);
                --color-surface-accent: var(--color-grey-700);
                --color-surface-inverse: var(--color-white);
                --color-surface-brand-accent: var(--color-grey-700);
                --color-surface-elevated: var(--color-grey-700);
                --color-surface-caution-default: var(--color-jaffa-1000);
                --color-surface-caution-strong: var(--color-jaffa-500);
                --color-surface-critical-default: var(--color-veryberry-1000);
                --color-surface-critical-strong: var(--color-veryberry-500);
                --color-surface-info-default: var(--color-blue-1000);
                --color-surface-info-strong: var(--color-blue-500);
                --color-surface-neutral-default: var(--color-grey-700);
                --color-surface-neutral-strong: var(--color-white);
                --color-surface-positive-default: var(--color-green-1000);
                --color-surface-positive-strong: var(--color-green-500);
                --color-overlay-light: var(--color-white-mask);
                --color-overlay-dark: var(--color-grey-1000-mask);
                --color-content-brand: var(--color-green-1000);
                --color-content-brand-accent: var(--color-bubblegum-100);
                --color-content-primary: var(--color-white);
                --color-content-inverse: var(--color-grey-1000);
                --color-content-secondary: var(--color-grey-100);
                --color-content-disabled: var(--color-grey-500);
                --color-content-caution-default: var(--color-jaffa-500);
                --color-content-caution-strong: var(--color-jaffa-1000);
                --color-content-critical-default: var(--color-veryberry-500);
                --color-content-critical-strong: var(--color-veryberry-1000);
                --color-content-info-default: var(--color-blue-500);
                --color-content-info-strong: var(--color-blue-1000);
                --color-content-neutral-default: var(--color-white);
                --color-content-neutral-strong: var(--color-grey-1000);
                --color-content-positive-default: var(--color-green-500);
                --color-content-positive-strong: var(--color-green-1000);
                --color-border-primary: var(--color-white);
                --color-border-secondary: var(--color-grey-500);
                --color-border-tertiary: var(--color-grey-700);
                --color-always-white: var(--color-white);
            }
            /*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL2FwcC9qYXZhc2NyaXB0L2NvbXBvbmVudHMvYnJhbmRfbmV1ZV90b2tlbnMvYmFzZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUVBO0VBQ0UsMEJBQUE7RUFDQSwyQ0FBQTtFQUNBLHlCQUFBO0VBQ0EseUJBQUE7RUFDQSx5QkFBQTtFQUNBLHlCQUFBO0VBQ0Esd0JBQUE7RUFDQSx3QkFBQTtFQUNBLHNCQUFBO0VBQ0EsMENBQUE7RUFFQSwyQkFBQTtFQUNBLDBCQUFBO0VBQ0EsMEJBQUE7RUFDQSwwQkFBQTtFQUNBLDBCQUFBO0VBQ0EseUJBQUE7RUFFQSwwQkFBQTtFQUNBLHlCQUFBO0VBQ0EseUJBQUE7RUFDQSx3QkFBQTtFQUVBLCtCQUFBO0VBQ0EsOEJBQUE7RUFDQSw4QkFBQTtFQUNBLDZCQUFBO0VBRUEsOEJBQUE7RUFDQSw4QkFBQTtFQUNBLDZCQUFBO0VBRUEsMkJBQUE7RUFDQSwwQkFBQTtFQUNBLDBCQUFBO0VBQ0EseUJBQUE7RUFFQSwwQkFBQTtFQUNBLHlCQUFBO0VBQ0EseUJBQUE7RUFDQSx5QkFBQTtFQUNBLHdCQUFBO0VBRUEsZ0NBQUE7RUFFQSx5QkFBQTtFQUNBLCtCQUFBO0VBQ0EsNEJBQUE7RUFFQSxtQkFBQTtFQUNBLGtCQUFBO0VBQ0Esa0JBQUE7RUFDQSxrQkFBQTtFQUNBLGtCQUFBO0VBQ0Esa0JBQUE7RUFDQSxpQkFBQTtFQUNBLGlCQUFBO0VBQ0EsbUJBQUE7RUFFQSxzQkFBQTtFQUNBLHNCQUFBO0VBQ0EsdUJBQUE7RUFFQSx1QkFBQTtFQUNBLHVCQUFBO0VBQ0EsNkJBQUE7RUFDQSx3QkFBQTtFQUVBLGdEQUFBO0VBQ0EscUNBQUE7RUFFQSxpQkFBQTtFQUNBLHVCQUFBO0VBRUEsaUNBQUE7RUFDQSxtQ0FBQTtFQUNBLGtDQUFBO0VBRUEsb0RBQUE7RUFDQSx3REFBQTtFQUNBLCtEQUFBO0VBQ0EseURBQUE7RUFFQTtrRUFBQTtFQUVBO3NEQUFBO0VBRUEsaURBQUE7RUFFQSxxQkFBQTtFQUNBLHNCQUFBO0VBQ0Esb0JBQUE7RUFDQSx1QkFBQTtFQUNBLHdCQUFBO0VBQ0Esc0JBQUE7RUFDQSx3QkFBQTtFQUNBLG9CQUFBO0VBQ0Esd0JBQUE7RUFDQSx1QkFBQTtFQUVBLHdCQUFBO0VBQ0EseUJBQUE7RUFDQSwwQkFBQTtFQUVBLDZCQUFBO0VBQ0Esd0JBQUE7RUFDQSw0QkFBQTtFQUVBLHNCQUFBO0VBQ0EseUJBQUE7RUFFQSxvQkFBQTtFQUNBLG9CQUFBO0VBQ0Esb0JBQUE7RUFDQSxvQkFBQTtFQUNBLG9CQUFBO0VBQ0EsNERBQUE7RUFFQSwyQkFBQTtFQUVBLDBCQUFBO0VBRUEsaUVBQUE7RUFFQSwyQkFBQTtFQUNBLDRCQUFBO0VBQ0EsZ0RBQUE7RUFDQSw2Q0FBQTtFQUNBLDhDQUFBO0VBQ0EsK0NBQUE7RUFDQSwrQ0FBQTtFQUNBLGlEQUFBO0VBRUEsb0RBQUE7RUFDQSxxREFBQTtFQUNBLGtEQUFBO0VBQ0EsMERBQUE7RUFDQSx5REFBQTtFQUNBLGlEQUFBO0VBQ0EsMERBQUE7RUFDQSx5REFBQTtFQUNBLGtEQUFBO0VBQ0EsMkRBQUE7RUFDQSwwREFBQTtFQUVBLDZEQUFBO0VBRUEsMkRBQUE7RUFDQSxxREFBQTtFQUNBLCtEQUFBO0VBQ0EsNERBQUE7RUFDQSw0REFBQTtFQUVBLDJEQUFBO0VBQ0EscURBQUE7RUFDQSwrREFBQTtFQUNBLDREQUFBO0VBQ0EsNERBQUE7RUFFQSx1REFBQTtFQUNBLDhDQUFBO0VBQ0Esd0RBQUE7RUFDQSxxREFBQTtFQUNBLHFEQUFBO0VBRUEsdURBQUE7RUFDQSw4Q0FBQTtFQUNBLHdEQUFBO0VBQ0Esc0RBQUE7RUFDQSxxREFBQTtFQUVBLHVEQUFBO0VBQ0EsOENBQUE7RUFDQSx3REFBQTtFQUNBLHNEQUFBO0VBQ0EscURBQUE7RUFFQSx1REFBQTtFQUNBLDhDQUFBO0VBQ0Esd0RBQUE7RUFDQSxzREFBQTtFQUNBLHFEQUFBO0VBRUEsMERBQUE7RUFDQSxpREFBQTtFQUNBLDJEQUFBO0VBQ0EseURBQUE7RUFDQSx5REFBQTtFQUVBLDBEQUFBO0VBQ0EsaURBQUE7RUFDQSwyREFBQTtFQUNBLDBEQUFBO0VBQ0EseURBQUE7RUFDQSwrREFBQTtFQUVBLDBEQUFBO0VBQ0EsaURBQUE7RUFDQSwyREFBQTtFQUNBLDBEQUFBO0VBQ0EseURBQUE7RUFDQSwrREFBQTtFQUVBLDJEQUFBO0VBQ0Esa0RBQUE7RUFDQSw0REFBQTtFQUNBLDBEQUFBO0VBQ0EsMERBQUE7RUFFQSwyREFBQTtFQUNBLGtEQUFBO0VBQ0EsMkRBQUE7RUFDQSwwREFBQTtFQUNBLDBEQUFBO0VBRUEscURBQUE7RUFDQSw0Q0FBQTtFQUNBLHFEQUFBO0VBQ0EscURBQUE7RUFDQSxtREFBQTtBQXhDRjs7QUEyQ0E7RUFDRSxtREFBQTtFQUNBLHlEQUFBO0VBQ0EsdURBQUE7RUFDQSwyREFBQTtFQUNBLHNEQUFBO0VBQ0Esd0RBQUE7RUFDQSxtREFBQTtFQUNBLHdEQUFBO0VBQ0EsbURBQUE7RUFFQSwyQ0FBQTtFQUNBLDRDQUFBO0VBQ0EsK0NBQUE7RUFDQSxtREFBQTtFQUNBLCtDQUFBO0VBQ0Esc0RBQUE7RUFDQSxzREFBQTtFQUNBLDJEQUFBO0VBQ0EsMkRBQUE7RUFDQSxrREFBQTtFQUNBLGtEQUFBO0VBQ0EscURBQUE7RUFDQSxzREFBQTtFQUNBLHVEQUFBO0VBQ0EsdURBQUE7RUFFQSw4Q0FBQTtFQUNBLGlEQUFBO0VBRUEsOENBQUE7RUFDQSx3REFBQTtFQUNBLCtDQUFBO0VBQ0EsMkNBQUE7RUFDQSxnREFBQTtFQUNBLCtDQUFBO0VBQ0EsdURBQUE7RUFDQSxxREFBQTtFQUNBLDREQUFBO0VBQ0EsMERBQUE7RUFDQSxtREFBQTtFQUNBLGlEQUFBO0VBQ0EsdURBQUE7RUFDQSxrREFBQTtFQUNBLHdEQUFBO0VBQ0Esc0RBQUE7RUFFQSw4Q0FBQTtFQUNBLCtDQUFBO0VBQ0EsOENBQUE7RUFFQSx3Q0FBQTtBQTdDRjs7QUFnREE7RUFDRSxtREFBQTtFQUNBLHlEQUFBO0VBQ0EsdURBQUE7RUFDQSx1REFBQTtFQUNBLHNEQUFBO0VBQ0EseURBQUE7RUFDQSwrQ0FBQTtFQUNBLHdEQUFBO0VBQ0EsbURBQUE7RUFFQSwrQ0FBQTtFQUNBLDZDQUFBO0VBQ0EsMkNBQUE7RUFDQSxtREFBQTtFQUNBLCtDQUFBO0VBQ0Esd0RBQUE7RUFDQSxzREFBQTtFQUNBLDZEQUFBO0VBQ0EsMkRBQUE7RUFDQSxvREFBQTtFQUNBLGtEQUFBO0VBQ0Esc0RBQUE7RUFDQSxrREFBQTtFQUNBLHlEQUFBO0VBQ0EsdURBQUE7RUFFQSw4Q0FBQTtFQUNBLGlEQUFBO0VBRUEsOENBQUE7RUFDQSx3REFBQTtFQUNBLDJDQUFBO0VBQ0EsK0NBQUE7RUFDQSxnREFBQTtFQUNBLCtDQUFBO0VBQ0EsdURBQUE7RUFDQSx1REFBQTtFQUNBLDREQUFBO0VBQ0EsNERBQUE7RUFDQSxtREFBQTtFQUNBLG1EQUFBO0VBQ0EsbURBQUE7RUFDQSxzREFBQTtFQUNBLHdEQUFBO0VBQ0Esd0RBQUE7RUFFQSwwQ0FBQTtFQUNBLCtDQUFBO0VBQ0EsOENBQUE7RUFFQSx3Q0FBQTtBQWxERiIsInNvdXJjZXNDb250ZW50IjpbIi8vIENvcGllZCBmcm9tIGh0dHBzOi8vZ2l0aHViLmNvbS9lbnZhdG8vZW52YXRvLWRlc2lnbi10b2tlbnMvYmxvYi9tYWluL3Rva2Vucy5jc3NcblxuOnJvb3Qge1xuICAtLWNvbG9yLWdyZXktMTAwMDogIzE5MTkxOTtcbiAgLS1jb2xvci1ncmV5LTEwMDAtbWFzazogcmdiKDI1IDI1IDI1IC8gMC43KTtcbiAgLS1jb2xvci1ncmV5LTcwMDogIzM4MzgzODtcbiAgLS1jb2xvci1ncmV5LTUwMDogIzcwNzA3MDtcbiAgLS1jb2xvci1ncmV5LTMwMDogIzk0OTQ5NDtcbiAgLS1jb2xvci1ncmV5LTEwMDogI2NjY2NjYztcbiAgLS1jb2xvci1ncmV5LTUwOiAjZWNlY2VlO1xuICAtLWNvbG9yLWdyZXktMjU6ICNmOWY5ZmI7XG4gIC0tY29sb3Itd2hpdGU6ICNmZmZmZmY7XG4gIC0tY29sb3Itd2hpdGUtbWFzazogcmdiKDI1NSAyNTUgMjU1IC8gMC43KTtcblxuICAtLWNvbG9yLWdyZWVuLTEwMDA6ICMxYTQyMDA7XG4gIC0tY29sb3ItZ3JlZW4tNzAwOiAjMmU3NDAwO1xuICAtLWNvbG9yLWdyZWVuLTUwMDogIzUxYTMxZDtcbiAgLS1jb2xvci1ncmVlbi0zMDA6ICM2Y2M4MzI7XG4gIC0tY29sb3ItZ3JlZW4tMTAwOiAjOWNlZTY5O1xuICAtLWNvbG9yLWdyZWVuLTI1OiAjZWFmZmRjO1xuXG4gIC0tY29sb3ItYmx1ZS0xMDAwOiAjMTYzNTdiO1xuICAtLWNvbG9yLWJsdWUtNzAwOiAjNGY1Y2U4O1xuICAtLWNvbG9yLWJsdWUtNTAwOiAjNzU4NWZmO1xuICAtLWNvbG9yLWJsdWUtMjU6ICNmMGYxZmY7XG5cbiAgLS1jb2xvci12ZXJ5YmVycnktMTAwMDogIzc3MDEyZDtcbiAgLS1jb2xvci12ZXJ5YmVycnktNzAwOiAjYjkwMDRiO1xuICAtLWNvbG9yLXZlcnliZXJyeS01MDA6ICNmNjUyODY7XG4gIC0tY29sb3ItdmVyeWJlcnJ5LTI1OiAjZmZlY2YyO1xuXG4gIC0tY29sb3ItYnViYmxlZ3VtLTcwMDogI2IwMzdhNjtcbiAgLS1jb2xvci1idWJibGVndW0tMTAwOiAjZTZhZmUxO1xuICAtLWNvbG9yLWJ1YmJsZWd1bS0yNTogI2ZlZWRmYztcblxuICAtLWNvbG9yLWphZmZhLTEwMDA6ICM2OTI0MDA7XG4gIC0tY29sb3ItamFmZmEtNzAwOiAjYzI0MTAwO1xuICAtLWNvbG9yLWphZmZhLTUwMDogI2ZmNmUyODtcbiAgLS1jb2xvci1qYWZmYS0yNTogI2ZmZjVlZDtcblxuICAtLWNvbG9yLXlvbGstMTAwMDogIzQ1MmQwZDtcbiAgLS1jb2xvci15b2xrLTcwMDogIzllNWYwMDtcbiAgLS1jb2xvci15b2xrLTUwMDogI2MyODgwMDtcbiAgLS1jb2xvci15b2xrLTMwMDogI2ZmYzgwMDtcbiAgLS1jb2xvci15b2xrLTI1OiAjZmVmYWVhO1xuXG4gIC0tY29sb3ItdHJhbnNwYXJlbnQ6IHRyYW5zcGFyZW50O1xuXG4gIC0tYnJlYWtwb2ludC13aWRlOiAxMDI0cHg7XG4gIC0tYnJlYWtwb2ludC1leHRyYS13aWRlOiAxNDQwcHg7XG4gIC0tYnJlYWtwb2ludC0yay13aWRlOiAyNTYwcHg7XG5cbiAgLS1zcGFjaW5nLTh4OiAxMjhweDtcbiAgLS1zcGFjaW5nLTd4OiA2NHB4O1xuICAtLXNwYWNpbmctNng6IDQwcHg7XG4gIC0tc3BhY2luZy01eDogMzJweDtcbiAgLS1zcGFjaW5nLTR4OiAyNHB4O1xuICAtLXNwYWNpbmctM3g6IDE2cHg7XG4gIC0tc3BhY2luZy0yeDogOHB4O1xuICAtLXNwYWNpbmctMXg6IDRweDtcbiAgLS1zcGFjaW5nLW5vbmU6IDBweDtcblxuICAtLWNodW5raW5lc3Mtbm9uZTogMHB4O1xuICAtLWNodW5raW5lc3MtdGhpbjogMXB4O1xuICAtLWNodW5raW5lc3MtdGhpY2s6IDJweDtcblxuICAtLXJvdW5kbmVzcy1zcXVhcmU6IDBweDtcbiAgLS1yb3VuZG5lc3Mtc3VidGxlOiA0cHg7XG4gIC0tcm91bmRuZXNzLWV4dHJhLXJvdW5kOiAxNnB4O1xuICAtLXJvdW5kbmVzcy1jaXJjbGU6IDQ4cHg7XG5cbiAgLS1zaGFkb3ctNTAwOiAwcHggMnB4IDEycHggMHB4IHJnYmEoMCAwIDAgLyAxNSUpO1xuICAtLWVsZXZhdGlvbi1tZWRpdW06IHZhcigtLXNoYWRvdy01MDApO1xuXG4gIC8qKiBAZGVwcmVjYXRlZCAqL1xuICAtLXRyYW5zaXRpb24tYmFzZTogMC4ycztcblxuICAtLXRyYW5zaXRpb24tZHVyYXRpb24tbG9uZzogNTAwbXM7XG4gIC0tdHJhbnNpdGlvbi1kdXJhdGlvbi1tZWRpdW06IDMwMG1zO1xuICAtLXRyYW5zaXRpb24tZHVyYXRpb24tc2hvcnQ6IDE1MG1zO1xuXG4gIC0tdHJhbnNpdGlvbi1lYXNpbmctbGluZWFyOiBjdWJpYy1iZXppZXIoMCwgMCwgMSwgMSk7XG4gIC0tdHJhbnNpdGlvbi1lYXNpbmctZWFzZS1pbjogY3ViaWMtYmV6aWVyKDAuNDIsIDAsIDEsIDEpO1xuICAtLXRyYW5zaXRpb24tZWFzaW5nLWVhc2UtaW4tb3V0OiBjdWJpYy1iZXppZXIoMC40MiwgMCwgMC41OCwgMSk7XG4gIC0tdHJhbnNpdGlvbi1lYXNpbmctZWFzZS1vdXQ6IGN1YmljLWJlemllcigwLCAwLCAwLjU4LCAxKTtcblxuICAtLWZvbnQtZmFtaWx5LXdpZGU6IFwiUG9seVNhbnNXaWRlXCIsIFwiUG9seVNhbnNcIiwgXCJJbnRlclwiLCAtYXBwbGUtc3lzdGVtLCBcIkJsaW5rTWFjU3lzdGVtRm9udFwiLFxuICAgIFwiU2Vnb2UgVUlcIiwgXCJGaXJhIFNhbnNcIiwgXCJIZWx2ZXRpY2EgTmV1ZVwiLCBcIkFyaWFsXCIsIHNhbnMtc2VyaWY7XG4gIC0tZm9udC1mYW1pbHktcmVndWxhcjogXCJQb2x5U2Fuc1wiLCBcIkludGVyXCIsIC1hcHBsZS1zeXN0ZW0sIFwiQmxpbmtNYWNTeXN0ZW1Gb250XCIsIFwiU2Vnb2UgVUlcIixcbiAgICBcIkZpcmEgU2Fuc1wiLCBcIkhlbHZldGljYSBOZXVlXCIsIFwiQXJpYWxcIiwgc2Fucy1zZXJpZjtcbiAgLS1mb250LWZhbWlseS1tb25vc3BhY2U6IFwiQ291cmllciBOZXdcIiwgbW9ub3NwYWNlO1xuXG4gIC0tZm9udC1zaXplLTEweDogNnJlbTtcbiAgLS1mb250LXNpemUtOXg6IDQuNXJlbTtcbiAgLS1mb250LXNpemUtOHg6IDNyZW07XG4gIC0tZm9udC1zaXplLTd4OiAyLjI1cmVtO1xuICAtLWZvbnQtc2l6ZS02eDogMS44NzVyZW07XG4gIC0tZm9udC1zaXplLTV4OiAxLjVyZW07XG4gIC0tZm9udC1zaXplLTR4OiAxLjEyNXJlbTtcbiAgLS1mb250LXNpemUtM3g6IDFyZW07XG4gIC0tZm9udC1zaXplLTJ4OiAwLjg3NXJlbTtcbiAgLS1mb250LXNpemUtMXg6IDAuNzVyZW07XG5cbiAgLS1mb250LXdlaWdodC1idWxreTogNzAwO1xuICAtLWZvbnQtd2VpZ2h0LW1lZGlhbjogNjAwO1xuICAtLWZvbnQtd2VpZ2h0LW5ldXRyYWw6IDQwMDtcblxuICAtLWZvbnQtc3BhY2luZy10aWdodDogLTAuMDJlbTtcbiAgLS1mb250LXNwYWNpbmctbm9ybWFsOiAwO1xuICAtLWZvbnQtc3BhY2luZy1sb29zZTogMC4wMmVtO1xuXG4gIC0tZm9udC1oZWlnaHQtdGlnaHQ6IDE7XG4gIC0tZm9udC1oZWlnaHQtbm9ybWFsOiAxLjU7XG5cbiAgLS1pY29uLXNpemUtNXg6IDQ4cHg7XG4gIC0taWNvbi1zaXplLTR4OiA0MHB4O1xuICAtLWljb24tc2l6ZS0zeDogMzJweDtcbiAgLS1pY29uLXNpemUtMng6IDI0cHg7XG4gIC0taWNvbi1zaXplLTF4OiAxNnB4O1xuICAtLWljb24tc2l6ZS10ZXh0LXJlc3BvbnNpdmU6IGNhbGModmFyKC0tZm9udC1zaXplLTN4KSAqIDEuNSk7XG5cbiAgLS1sYXllci1kZXB0aC1jZWlsaW5nOiA5OTk5O1xuXG4gIC0tbWluaW11bS10b3VjaC1hcmVhOiA0MHB4O1xuXG4gIC8qIGNvbXBvbmVudCB3aXJpbmc/IC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLSAqL1xuXG4gIC0tYnV0dG9uLWhlaWdodC1sYXJnZTogNDhweDtcbiAgLS1idXR0b24taGVpZ2h0LW1lZGl1bTogNDBweDtcbiAgLS1idXR0b24tZm9udC1mYW1pbHk6IHZhcigtLWZvbnQtZmFtaWx5LXJlZ3VsYXIpO1xuICAtLWJ1dHRvbi1mb250LXNpemUtbGFyZ2U6IHZhcigtLWZvbnQtc2l6ZS0zeCk7XG4gIC0tYnV0dG9uLWZvbnQtc2l6ZS1tZWRpdW06IHZhcigtLWZvbnQtc2l6ZS0yeCk7XG4gIC0tYnV0dG9uLWZvbnQtd2VpZ2h0OiB2YXIoLS1mb250LXdlaWdodC1tZWRpYW4pO1xuICAtLWJ1dHRvbi1mb250LWhlaWdodDogdmFyKC0tZm9udC1oZWlnaHQtbm9ybWFsKTtcbiAgLS1idXR0b24tZm9udC1zcGFjaW5nOiB2YXIoLS1mb250LXNwYWNpbmctbm9ybWFsKTtcblxuICAtLXRleHQtc3R5bGUtY2hpcC1mYW1pbHk6IHZhcigtLWZvbnQtZmFtaWx5LXJlZ3VsYXIpO1xuICAtLXRleHQtc3R5bGUtY2hpcC1zcGFjaW5nOiB2YXIoLS1mb250LXNwYWNpbmctbm9ybWFsKTtcbiAgLS10ZXh0LXN0eWxlLWNoaXAteGxhcmdlLXNpemU6IHZhcigtLWZvbnQtc2l6ZS01eCk7XG4gIC0tdGV4dC1zdHlsZS1jaGlwLXhsYXJnZS13ZWlnaHQ6IHZhcigtLWZvbnQtd2VpZ2h0LW1lZGlhbik7XG4gIC0tdGV4dC1zdHlsZS1jaGlwLXhsYXJnZS1oZWlnaHQ6IHZhcigtLWZvbnQtaGVpZ2h0LXRpZ2h0KTtcbiAgLS10ZXh0LXN0eWxlLWNoaXAtbGFyZ2Utc2l6ZTogdmFyKC0tZm9udC1zaXplLTN4KTtcbiAgLS10ZXh0LXN0eWxlLWNoaXAtbGFyZ2Utd2VpZ2h0OiB2YXIoLS1mb250LXdlaWdodC1uZXV0cmFsKTtcbiAgLS10ZXh0LXN0eWxlLWNoaXAtbGFyZ2UtaGVpZ2h0OiB2YXIoLS1mb250LWhlaWdodC1ub3JtYWwpO1xuICAtLXRleHQtc3R5bGUtY2hpcC1tZWRpdW0tc2l6ZTogdmFyKC0tZm9udC1zaXplLTJ4KTtcbiAgLS10ZXh0LXN0eWxlLWNoaXAtbWVkaXVtLXdlaWdodDogdmFyKC0tZm9udC13ZWlnaHQtbmV1dHJhbCk7XG4gIC0tdGV4dC1zdHlsZS1jaGlwLW1lZGl1bS1oZWlnaHQ6IHZhcigtLWZvbnQtaGVpZ2h0LW5vcm1hbCk7XG5cbiAgLyogdGhlbWU/IC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0gKi9cblxuICAtLXRleHQtc3R5bGUtY2FtcGFpZ24tbGFyZ2UtZmFtaWx5OiB2YXIoLS1mb250LWZhbWlseS13aWRlKTtcbiAgLS10ZXh0LXN0eWxlLWNhbXBhaWduLWxhcmdlLXNpemU6IHZhcigtLWZvbnQtc2l6ZS05eCk7XG4gIC0tdGV4dC1zdHlsZS1jYW1wYWlnbi1sYXJnZS1zcGFjaW5nOiB2YXIoLS1mb250LXNwYWNpbmctbm9ybWFsKTtcbiAgLS10ZXh0LXN0eWxlLWNhbXBhaWduLWxhcmdlLXdlaWdodDogdmFyKC0tZm9udC13ZWlnaHQtYnVsa3kpO1xuICAtLXRleHQtc3R5bGUtY2FtcGFpZ24tbGFyZ2UtaGVpZ2h0OiB2YXIoLS1mb250LWhlaWdodC10aWdodCk7XG5cbiAgLS10ZXh0LXN0eWxlLWNhbXBhaWduLXNtYWxsLWZhbWlseTogdmFyKC0tZm9udC1mYW1pbHktd2lkZSk7XG4gIC0tdGV4dC1zdHlsZS1jYW1wYWlnbi1zbWFsbC1zaXplOiB2YXIoLS1mb250LXNpemUtN3gpO1xuICAtLXRleHQtc3R5bGUtY2FtcGFpZ24tc21hbGwtc3BhY2luZzogdmFyKC0tZm9udC1zcGFjaW5nLW5vcm1hbCk7XG4gIC0tdGV4dC1zdHlsZS1jYW1wYWlnbi1zbWFsbC13ZWlnaHQ6IHZhcigtLWZvbnQtd2VpZ2h0LWJ1bGt5KTtcbiAgLS10ZXh0LXN0eWxlLWNhbXBhaWduLXNtYWxsLWhlaWdodDogdmFyKC0tZm9udC1oZWlnaHQtdGlnaHQpO1xuXG4gIC0tdGV4dC1zdHlsZS10aXRsZS0xLWZhbWlseTogdmFyKC0tZm9udC1mYW1pbHktcmVndWxhcik7XG4gIC0tdGV4dC1zdHlsZS10aXRsZS0xLXNpemU6IHZhcigtLWZvbnQtc2l6ZS04eCk7XG4gIC0tdGV4dC1zdHlsZS10aXRsZS0xLXNwYWNpbmc6IHZhcigtLWZvbnQtc3BhY2luZy1ub3JtYWwpO1xuICAtLXRleHQtc3R5bGUtdGl0bGUtMS13ZWlnaHQ6IHZhcigtLWZvbnQtd2VpZ2h0LWJ1bGt5KTtcbiAgLS10ZXh0LXN0eWxlLXRpdGxlLTEtaGVpZ2h0OiB2YXIoLS1mb250LWhlaWdodC10aWdodCk7XG5cbiAgLS10ZXh0LXN0eWxlLXRpdGxlLTItZmFtaWx5OiB2YXIoLS1mb250LWZhbWlseS1yZWd1bGFyKTtcbiAgLS10ZXh0LXN0eWxlLXRpdGxlLTItc2l6ZTogdmFyKC0tZm9udC1zaXplLTd4KTtcbiAgLS10ZXh0LXN0eWxlLXRpdGxlLTItc3BhY2luZzogdmFyKC0tZm9udC1zcGFjaW5nLW5vcm1hbCk7XG4gIC0tdGV4dC1zdHlsZS10aXRsZS0yLXdlaWdodDogdmFyKC0tZm9udC13ZWlnaHQtbWVkaWFuKTtcbiAgLS10ZXh0LXN0eWxlLXRpdGxlLTItaGVpZ2h0OiB2YXIoLS1mb250LWhlaWdodC10aWdodCk7XG5cbiAgLS10ZXh0LXN0eWxlLXRpdGxlLTMtZmFtaWx5OiB2YXIoLS1mb250LWZhbWlseS1yZWd1bGFyKTtcbiAgLS10ZXh0LXN0eWxlLXRpdGxlLTMtc2l6ZTogdmFyKC0tZm9udC1zaXplLTZ4KTtcbiAgLS10ZXh0LXN0eWxlLXRpdGxlLTMtc3BhY2luZzogdmFyKC0tZm9udC1zcGFjaW5nLW5vcm1hbCk7XG4gIC0tdGV4dC1zdHlsZS10aXRsZS0zLXdlaWdodDogdmFyKC0tZm9udC13ZWlnaHQtbWVkaWFuKTtcbiAgLS10ZXh0LXN0eWxlLXRpdGxlLTMtaGVpZ2h0OiB2YXIoLS1mb250LWhlaWdodC10aWdodCk7XG5cbiAgLS10ZXh0LXN0eWxlLXRpdGxlLTQtZmFtaWx5OiB2YXIoLS1mb250LWZhbWlseS1yZWd1bGFyKTtcbiAgLS10ZXh0LXN0eWxlLXRpdGxlLTQtc2l6ZTogdmFyKC0tZm9udC1zaXplLTV4KTtcbiAgLS10ZXh0LXN0eWxlLXRpdGxlLTQtc3BhY2luZzogdmFyKC0tZm9udC1zcGFjaW5nLW5vcm1hbCk7XG4gIC0tdGV4dC1zdHlsZS10aXRsZS00LXdlaWdodDogdmFyKC0tZm9udC13ZWlnaHQtbWVkaWFuKTtcbiAgLS10ZXh0LXN0eWxlLXRpdGxlLTQtaGVpZ2h0OiB2YXIoLS1mb250LWhlaWdodC10aWdodCk7XG5cbiAgLS10ZXh0LXN0eWxlLXN1YmhlYWRpbmctZmFtaWx5OiB2YXIoLS1mb250LWZhbWlseS1yZWd1bGFyKTtcbiAgLS10ZXh0LXN0eWxlLXN1YmhlYWRpbmctc2l6ZTogdmFyKC0tZm9udC1zaXplLTR4KTtcbiAgLS10ZXh0LXN0eWxlLXN1YmhlYWRpbmctc3BhY2luZzogdmFyKC0tZm9udC1zcGFjaW5nLW5vcm1hbCk7XG4gIC0tdGV4dC1zdHlsZS1zdWJoZWFkaW5nLXdlaWdodDogdmFyKC0tZm9udC13ZWlnaHQtbWVkaWFuKTtcbiAgLS10ZXh0LXN0eWxlLXN1YmhlYWRpbmctaGVpZ2h0OiB2YXIoLS1mb250LWhlaWdodC1ub3JtYWwpO1xuXG4gIC0tdGV4dC1zdHlsZS1ib2R5LWxhcmdlLWZhbWlseTogdmFyKC0tZm9udC1mYW1pbHktcmVndWxhcik7XG4gIC0tdGV4dC1zdHlsZS1ib2R5LWxhcmdlLXNpemU6IHZhcigtLWZvbnQtc2l6ZS0zeCk7XG4gIC0tdGV4dC1zdHlsZS1ib2R5LWxhcmdlLXNwYWNpbmc6IHZhcigtLWZvbnQtc3BhY2luZy1ub3JtYWwpO1xuICAtLXRleHQtc3R5bGUtYm9keS1sYXJnZS13ZWlnaHQ6IHZhcigtLWZvbnQtd2VpZ2h0LW5ldXRyYWwpO1xuICAtLXRleHQtc3R5bGUtYm9keS1sYXJnZS1oZWlnaHQ6IHZhcigtLWZvbnQtaGVpZ2h0LW5vcm1hbCk7XG4gIC0tdGV4dC1zdHlsZS1ib2R5LWxhcmdlLXN0cm9uZy13ZWlnaHQ6IHZhcigtLWZvbnQtd2VpZ2h0LWJ1bGt5KTtcblxuICAtLXRleHQtc3R5bGUtYm9keS1zbWFsbC1mYW1pbHk6IHZhcigtLWZvbnQtZmFtaWx5LXJlZ3VsYXIpO1xuICAtLXRleHQtc3R5bGUtYm9keS1zbWFsbC1zaXplOiB2YXIoLS1mb250LXNpemUtMngpO1xuICAtLXRleHQtc3R5bGUtYm9keS1zbWFsbC1zcGFjaW5nOiB2YXIoLS1mb250LXNwYWNpbmctbm9ybWFsKTtcbiAgLS10ZXh0LXN0eWxlLWJvZHktc21hbGwtd2VpZ2h0OiB2YXIoLS1mb250LXdlaWdodC1uZXV0cmFsKTtcbiAgLS10ZXh0LXN0eWxlLWJvZHktc21hbGwtaGVpZ2h0OiB2YXIoLS1mb250LWhlaWdodC1ub3JtYWwpO1xuICAtLXRleHQtc3R5bGUtYm9keS1zbWFsbC1zdHJvbmctd2VpZ2h0OiB2YXIoLS1mb250LXdlaWdodC1idWxreSk7XG5cbiAgLS10ZXh0LXN0eWxlLWxhYmVsLWxhcmdlLWZhbWlseTogdmFyKC0tZm9udC1mYW1pbHktcmVndWxhcik7XG4gIC0tdGV4dC1zdHlsZS1sYWJlbC1sYXJnZS1zaXplOiB2YXIoLS1mb250LXNpemUtM3gpO1xuICAtLXRleHQtc3R5bGUtbGFiZWwtbGFyZ2Utc3BhY2luZzogdmFyKC0tZm9udC1zcGFjaW5nLW5vcm1hbCk7XG4gIC0tdGV4dC1zdHlsZS1sYWJlbC1sYXJnZS13ZWlnaHQ6IHZhcigtLWZvbnQtd2VpZ2h0LW1lZGlhbik7XG4gIC0tdGV4dC1zdHlsZS1sYWJlbC1sYXJnZS1oZWlnaHQ6IHZhcigtLWZvbnQtaGVpZ2h0LW5vcm1hbCk7XG5cbiAgLS10ZXh0LXN0eWxlLWxhYmVsLXNtYWxsLWZhbWlseTogdmFyKC0tZm9udC1mYW1pbHktcmVndWxhcik7XG4gIC0tdGV4dC1zdHlsZS1sYWJlbC1zbWFsbC1zaXplOiB2YXIoLS1mb250LXNpemUtMngpO1xuICAtLXRleHQtc3R5bGUtbGFiZWwtc21hbGwtc3BhY2luZzogdmFyKC0tZm9udC1zcGFjaW5nLWxvb3NlKTtcbiAgLS10ZXh0LXN0eWxlLWxhYmVsLXNtYWxsLXdlaWdodDogdmFyKC0tZm9udC13ZWlnaHQtbWVkaWFuKTtcbiAgLS10ZXh0LXN0eWxlLWxhYmVsLXNtYWxsLWhlaWdodDogdmFyKC0tZm9udC1oZWlnaHQtbm9ybWFsKTtcblxuICAtLXRleHQtc3R5bGUtbWljcm8tZmFtaWx5OiB2YXIoLS1mb250LWZhbWlseS1yZWd1bGFyKTtcbiAgLS10ZXh0LXN0eWxlLW1pY3JvLXNpemU6IHZhcigtLWZvbnQtc2l6ZS0xeCk7XG4gIC0tdGV4dC1zdHlsZS1taWNyby1zcGFjaW5nOiB2YXIoLS1mb250LXNwYWNpbmctbG9vc2UpO1xuICAtLXRleHQtc3R5bGUtbWljcm8td2VpZ2h0OiB2YXIoLS1mb250LXdlaWdodC1uZXV0cmFsKTtcbiAgLS10ZXh0LXN0eWxlLW1pY3JvLWhlaWdodDogdmFyKC0tZm9udC1oZWlnaHQtdGlnaHQpO1xufVxuXG4uY29sb3Itc2NoZW1lLWxpZ2h0IHtcbiAgLS1jb2xvci1pbnRlcmFjdGl2ZS1wcmltYXJ5OiB2YXIoLS1jb2xvci1ncmVlbi0xMDApO1xuICAtLWNvbG9yLWludGVyYWN0aXZlLXByaW1hcnktaG92ZXI6IHZhcigtLWNvbG9yLWdyZWVuLTMwMCk7XG4gIC0tY29sb3ItaW50ZXJhY3RpdmUtc2Vjb25kYXJ5OiB2YXIoLS1jb2xvci10cmFuc3BhcmVudCk7XG4gIC0tY29sb3ItaW50ZXJhY3RpdmUtc2Vjb25kYXJ5LWhvdmVyOiB2YXIoLS1jb2xvci1ncmV5LTEwMDApO1xuICAtLWNvbG9yLWludGVyYWN0aXZlLXRlcnRpYXJ5OiB2YXIoLS1jb2xvci10cmFuc3BhcmVudCk7XG4gIC0tY29sb3ItaW50ZXJhY3RpdmUtdGVydGlhcnktaG92ZXI6IHZhcigtLWNvbG9yLWdyZXktMjUpO1xuICAtLWNvbG9yLWludGVyYWN0aXZlLWNvbnRyb2w6IHZhcigtLWNvbG9yLWdyZXktMTAwMCk7XG4gIC0tY29sb3ItaW50ZXJhY3RpdmUtY29udHJvbC1ob3ZlcjogdmFyKC0tY29sb3ItZ3JleS03MDApO1xuICAtLWNvbG9yLWludGVyYWN0aXZlLWRpc2FibGVkOiB2YXIoLS1jb2xvci1ncmV5LTEwMCk7XG5cbiAgLS1jb2xvci1zdXJmYWNlLXByaW1hcnk6IHZhcigtLWNvbG9yLXdoaXRlKTtcbiAgLS1jb2xvci1zdXJmYWNlLWFjY2VudDogdmFyKC0tY29sb3ItZ3JleS01MCk7XG4gIC0tY29sb3Itc3VyZmFjZS1pbnZlcnNlOiB2YXIoLS1jb2xvci1ncmV5LTEwMDApO1xuICAtLWNvbG9yLXN1cmZhY2UtYnJhbmQtYWNjZW50OiB2YXIoLS1jb2xvci1qYWZmYS0yNSk7XG4gIC0tY29sb3Itc3VyZmFjZS1lbGV2YXRlZDogdmFyKC0tY29sb3ItZ3JleS03MDApO1xuICAtLWNvbG9yLXN1cmZhY2UtY2F1dGlvbi1kZWZhdWx0OiB2YXIoLS1jb2xvci1qYWZmYS0yNSk7XG4gIC0tY29sb3Itc3VyZmFjZS1jYXV0aW9uLXN0cm9uZzogdmFyKC0tY29sb3ItamFmZmEtNzAwKTtcbiAgLS1jb2xvci1zdXJmYWNlLWNyaXRpY2FsLWRlZmF1bHQ6IHZhcigtLWNvbG9yLXZlcnliZXJyeS0yNSk7XG4gIC0tY29sb3Itc3VyZmFjZS1jcml0aWNhbC1zdHJvbmc6IHZhcigtLWNvbG9yLXZlcnliZXJyeS03MDApO1xuICAtLWNvbG9yLXN1cmZhY2UtaW5mby1kZWZhdWx0OiB2YXIoLS1jb2xvci1ibHVlLTI1KTtcbiAgLS1jb2xvci1zdXJmYWNlLWluZm8tc3Ryb25nOiB2YXIoLS1jb2xvci1ibHVlLTcwMCk7XG4gIC0tY29sb3Itc3VyZmFjZS1uZXV0cmFsLWRlZmF1bHQ6IHZhcigtLWNvbG9yLWdyZXktMjUpO1xuICAtLWNvbG9yLXN1cmZhY2UtbmV1dHJhbC1zdHJvbmc6IHZhcigtLWNvbG9yLWdyZXktMTAwMCk7XG4gIC0tY29sb3Itc3VyZmFjZS1wb3NpdGl2ZS1kZWZhdWx0OiB2YXIoLS1jb2xvci1ncmVlbi0yNSk7XG4gIC0tY29sb3Itc3VyZmFjZS1wb3NpdGl2ZS1zdHJvbmc6IHZhcigtLWNvbG9yLWdyZWVuLTcwMCk7XG5cbiAgLS1jb2xvci1vdmVybGF5LWxpZ2h0OiB2YXIoLS1jb2xvci13aGl0ZS1tYXNrKTtcbiAgLS1jb2xvci1vdmVybGF5LWRhcms6IHZhcigtLWNvbG9yLWdyZXktMTAwMC1tYXNrKTtcblxuICAtLWNvbG9yLWNvbnRlbnQtYnJhbmQ6IHZhcigtLWNvbG9yLWdyZWVuLTEwMDApO1xuICAtLWNvbG9yLWNvbnRlbnQtYnJhbmQtYWNjZW50OiB2YXIoLS1jb2xvci1idWJibGVndW0tNzAwKTtcbiAgLS1jb2xvci1jb250ZW50LXByaW1hcnk6IHZhcigtLWNvbG9yLWdyZXktMTAwMCk7XG4gIC0tY29sb3ItY29udGVudC1pbnZlcnNlOiB2YXIoLS1jb2xvci13aGl0ZSk7XG4gIC0tY29sb3ItY29udGVudC1zZWNvbmRhcnk6IHZhcigtLWNvbG9yLWdyZXktNTAwKTtcbiAgLS1jb2xvci1jb250ZW50LWRpc2FibGVkOiB2YXIoLS1jb2xvci1ncmV5LTMwMCk7XG4gIC0tY29sb3ItY29udGVudC1jYXV0aW9uLWRlZmF1bHQ6IHZhcigtLWNvbG9yLWphZmZhLTcwMCk7XG4gIC0tY29sb3ItY29udGVudC1jYXV0aW9uLXN0cm9uZzogdmFyKC0tY29sb3ItamFmZmEtMjUpO1xuICAtLWNvbG9yLWNvbnRlbnQtY3JpdGljYWwtZGVmYXVsdDogdmFyKC0tY29sb3ItdmVyeWJlcnJ5LTcwMCk7XG4gIC0tY29sb3ItY29udGVudC1jcml0aWNhbC1zdHJvbmc6IHZhcigtLWNvbG9yLXZlcnliZXJyeS0yNSk7XG4gIC0tY29sb3ItY29udGVudC1pbmZvLWRlZmF1bHQ6IHZhcigtLWNvbG9yLWJsdWUtNzAwKTtcbiAgLS1jb2xvci1jb250ZW50LWluZm8tc3Ryb25nOiB2YXIoLS1jb2xvci1ibHVlLTI1KTtcbiAgLS1jb2xvci1jb250ZW50LW5ldXRyYWwtZGVmYXVsdDogdmFyKC0tY29sb3ItZ3JleS0xMDAwKTtcbiAgLS1jb2xvci1jb250ZW50LW5ldXRyYWwtc3Ryb25nOiB2YXIoLS1jb2xvci13aGl0ZSk7XG4gIC0tY29sb3ItY29udGVudC1wb3NpdGl2ZS1kZWZhdWx0OiB2YXIoLS1jb2xvci1ncmVlbi03MDApO1xuICAtLWNvbG9yLWNvbnRlbnQtcG9zaXRpdmUtc3Ryb25nOiB2YXIoLS1jb2xvci1ncmVlbi0yNSk7XG5cbiAgLS1jb2xvci1ib3JkZXItcHJpbWFyeTogdmFyKC0tY29sb3ItZ3JleS0xMDAwKTtcbiAgLS1jb2xvci1ib3JkZXItc2Vjb25kYXJ5OiB2YXIoLS1jb2xvci1ncmV5LTMwMCk7XG4gIC0tY29sb3ItYm9yZGVyLXRlcnRpYXJ5OiB2YXIoLS1jb2xvci1ncmV5LTEwMCk7XG5cbiAgLS1jb2xvci1hbHdheXMtd2hpdGU6IHZhcigtLWNvbG9yLXdoaXRlKTtcbn1cblxuLmNvbG9yLXNjaGVtZS1kYXJrIHtcbiAgLS1jb2xvci1pbnRlcmFjdGl2ZS1wcmltYXJ5OiB2YXIoLS1jb2xvci1ncmVlbi0xMDApO1xuICAtLWNvbG9yLWludGVyYWN0aXZlLXByaW1hcnktaG92ZXI6IHZhcigtLWNvbG9yLWdyZWVuLTMwMCk7XG4gIC0tY29sb3ItaW50ZXJhY3RpdmUtc2Vjb25kYXJ5OiB2YXIoLS1jb2xvci10cmFuc3BhcmVudCk7XG4gIC0tY29sb3ItaW50ZXJhY3RpdmUtc2Vjb25kYXJ5LWhvdmVyOiB2YXIoLS1jb2xvci13aGl0ZSk7XG4gIC0tY29sb3ItaW50ZXJhY3RpdmUtdGVydGlhcnk6IHZhcigtLWNvbG9yLXRyYW5zcGFyZW50KTtcbiAgLS1jb2xvci1pbnRlcmFjdGl2ZS10ZXJ0aWFyeS1ob3ZlcjogdmFyKC0tY29sb3ItZ3JleS03MDApO1xuICAtLWNvbG9yLWludGVyYWN0aXZlLWNvbnRyb2w6IHZhcigtLWNvbG9yLXdoaXRlKTtcbiAgLS1jb2xvci1pbnRlcmFjdGl2ZS1jb250cm9sLWhvdmVyOiB2YXIoLS1jb2xvci1ncmV5LTEwMCk7XG4gIC0tY29sb3ItaW50ZXJhY3RpdmUtZGlzYWJsZWQ6IHZhcigtLWNvbG9yLWdyZXktNzAwKTtcblxuICAtLWNvbG9yLXN1cmZhY2UtcHJpbWFyeTogdmFyKC0tY29sb3ItZ3JleS0xMDAwKTtcbiAgLS1jb2xvci1zdXJmYWNlLWFjY2VudDogdmFyKC0tY29sb3ItZ3JleS03MDApO1xuICAtLWNvbG9yLXN1cmZhY2UtaW52ZXJzZTogdmFyKC0tY29sb3Itd2hpdGUpO1xuICAtLWNvbG9yLXN1cmZhY2UtYnJhbmQtYWNjZW50OiB2YXIoLS1jb2xvci1ncmV5LTcwMCk7XG4gIC0tY29sb3Itc3VyZmFjZS1lbGV2YXRlZDogdmFyKC0tY29sb3ItZ3JleS03MDApO1xuICAtLWNvbG9yLXN1cmZhY2UtY2F1dGlvbi1kZWZhdWx0OiB2YXIoLS1jb2xvci1qYWZmYS0xMDAwKTtcbiAgLS1jb2xvci1zdXJmYWNlLWNhdXRpb24tc3Ryb25nOiB2YXIoLS1jb2xvci1qYWZmYS01MDApO1xuICAtLWNvbG9yLXN1cmZhY2UtY3JpdGljYWwtZGVmYXVsdDogdmFyKC0tY29sb3ItdmVyeWJlcnJ5LTEwMDApO1xuICAtLWNvbG9yLXN1cmZhY2UtY3JpdGljYWwtc3Ryb25nOiB2YXIoLS1jb2xvci12ZXJ5YmVycnktNTAwKTtcbiAgLS1jb2xvci1zdXJmYWNlLWluZm8tZGVmYXVsdDogdmFyKC0tY29sb3ItYmx1ZS0xMDAwKTtcbiAgLS1jb2xvci1zdXJmYWNlLWluZm8tc3Ryb25nOiB2YXIoLS1jb2xvci1ibHVlLTUwMCk7XG4gIC0tY29sb3Itc3VyZmFjZS1uZXV0cmFsLWRlZmF1bHQ6IHZhcigtLWNvbG9yLWdyZXktNzAwKTtcbiAgLS1jb2xvci1zdXJmYWNlLW5ldXRyYWwtc3Ryb25nOiB2YXIoLS1jb2xvci13aGl0ZSk7XG4gIC0tY29sb3Itc3VyZmFjZS1wb3NpdGl2ZS1kZWZhdWx0OiB2YXIoLS1jb2xvci1ncmVlbi0xMDAwKTtcbiAgLS1jb2xvci1zdXJmYWNlLXBvc2l0aXZlLXN0cm9uZzogdmFyKC0tY29sb3ItZ3JlZW4tNTAwKTtcblxuICAtLWNvbG9yLW92ZXJsYXktbGlnaHQ6IHZhcigtLWNvbG9yLXdoaXRlLW1hc2spO1xuICAtLWNvbG9yLW92ZXJsYXktZGFyazogdmFyKC0tY29sb3ItZ3JleS0xMDAwLW1hc2spO1xuXG4gIC0tY29sb3ItY29udGVudC1icmFuZDogdmFyKC0tY29sb3ItZ3JlZW4tMTAwMCk7XG4gIC0tY29sb3ItY29udGVudC1icmFuZC1hY2NlbnQ6IHZhcigtLWNvbG9yLWJ1YmJsZWd1bS0xMDApO1xuICAtLWNvbG9yLWNvbnRlbnQtcHJpbWFyeTogdmFyKC0tY29sb3Itd2hpdGUpO1xuICAtLWNvbG9yLWNvbnRlbnQtaW52ZXJzZTogdmFyKC0tY29sb3ItZ3JleS0xMDAwKTtcbiAgLS1jb2xvci1jb250ZW50LXNlY29uZGFyeTogdmFyKC0tY29sb3ItZ3JleS0xMDApO1xuICAtLWNvbG9yLWNvbnRlbnQtZGlzYWJsZWQ6IHZhcigtLWNvbG9yLWdyZXktNTAwKTtcbiAgLS1jb2xvci1jb250ZW50LWNhdXRpb24tZGVmYXVsdDogdmFyKC0tY29sb3ItamFmZmEtNTAwKTtcbiAgLS1jb2xvci1jb250ZW50LWNhdXRpb24tc3Ryb25nOiB2YXIoLS1jb2xvci1qYWZmYS0xMDAwKTtcbiAgLS1jb2xvci1jb250ZW50LWNyaXRpY2FsLWRlZmF1bHQ6IHZhcigtLWNvbG9yLXZlcnliZXJyeS01MDApO1xuICAtLWNvbG9yLWNvbnRlbnQtY3JpdGljYWwtc3Ryb25nOiB2YXIoLS1jb2xvci12ZXJ5YmVycnktMTAwMCk7XG4gIC0tY29sb3ItY29udGVudC1pbmZvLWRlZmF1bHQ6IHZhcigtLWNvbG9yLWJsdWUtNTAwKTtcbiAgLS1jb2xvci1jb250ZW50LWluZm8tc3Ryb25nOiB2YXIoLS1jb2xvci1ibHVlLTEwMDApO1xuICAtLWNvbG9yLWNvbnRlbnQtbmV1dHJhbC1kZWZhdWx0OiB2YXIoLS1jb2xvci13aGl0ZSk7XG4gIC0tY29sb3ItY29udGVudC1uZXV0cmFsLXN0cm9uZzogdmFyKC0tY29sb3ItZ3JleS0xMDAwKTtcbiAgLS1jb2xvci1jb250ZW50LXBvc2l0aXZlLWRlZmF1bHQ6IHZhcigtLWNvbG9yLWdyZWVuLTUwMCk7XG4gIC0tY29sb3ItY29udGVudC1wb3NpdGl2ZS1zdHJvbmc6IHZhcigtLWNvbG9yLWdyZWVuLTEwMDApO1xuXG4gIC0tY29sb3ItYm9yZGVyLXByaW1hcnk6IHZhcigtLWNvbG9yLXdoaXRlKTtcbiAgLS1jb2xvci1ib3JkZXItc2Vjb25kYXJ5OiB2YXIoLS1jb2xvci1ncmV5LTUwMCk7XG4gIC0tY29sb3ItYm9yZGVyLXRlcnRpYXJ5OiB2YXIoLS1jb2xvci1ncmV5LTcwMCk7XG5cbiAgLS1jb2xvci1hbHdheXMtd2hpdGU6IHZhcigtLWNvbG9yLXdoaXRlKTtcbn1cbiJdLCJzb3VyY2VSb290IjoiIn0= */
        </style>
        <style>
            .brand-neue-button {
                gap: var(--spacing-2x);
                border-radius: var(--roundness-subtle);
                background: var(--color-interactive-primary);
                color: var(--color-content-brand);
                font-family: PolySans-Median;
                font-size: var(--font-size-2x);
                letter-spacing: 0.02em;
                text-align: center;
                padding: 0 20px;
            }
            .brand-neue-button:hover,
            .brand-neue-button:active,
            .brand-neue-button:focus {
                background: var(--color-interactive-primary-hover);
            }

            .brand-neue-button__open-in-new::after {
                font-size: 0;
                margin-left: 5px;
                vertical-align: sub;
                content: url('data:image/svg+xml,<svg width="14" height="14" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg"><g id="ico-/-24-/-actions-/-open_in_new"><path id="Icon-color" d="M17.5 12.0833V15.8333C17.5 16.7538 16.7538 17.5 15.8333 17.5H4.16667C3.24619 17.5 2.5 16.7538 2.5 15.8333V4.16667C2.5 3.24619 3.24619 2.5 4.16667 2.5H7.91667C8.14679 2.5 8.33333 2.68655 8.33333 2.91667V3.75C8.33333 3.98012 8.14679 4.16667 7.91667 4.16667H4.16667V15.8333H15.8333V12.0833C15.8333 11.8532 16.0199 11.6667 16.25 11.6667H17.0833C17.3135 11.6667 17.5 11.8532 17.5 12.0833ZM17.3167 2.91667L17.0917 2.69167C16.98 2.57535 16.8278 2.50668 16.6667 2.5H11.25C11.0199 2.5 10.8333 2.68655 10.8333 2.91667V3.75C10.8333 3.98012 11.0199 4.16667 11.25 4.16667H14.6583L7.625 11.2C7.54612 11.2782 7.50175 11.3847 7.50175 11.4958C7.50175 11.6069 7.54612 11.7134 7.625 11.7917L8.20833 12.375C8.28657 12.4539 8.39307 12.4982 8.50417 12.4982C8.61527 12.4982 8.72176 12.4539 8.8 12.375L15.8333 5.35V8.75C15.8333 8.98012 16.0199 9.16667 16.25 9.16667H17.0833C17.3135 9.16667 17.5 8.98012 17.5 8.75V3.33333C17.4955 3.17342 17.4299 3.02132 17.3167 2.90833V2.91667Z" fill="%231A4200"/></g></svg>');
            }
            /*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL2FwcC9qYXZhc2NyaXB0L2NvbXBvbmVudHMvYnJhbmRfbmV1ZV90b2tlbnMvY29tcG9uZW50cy9idXR0b24uc2FzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLHNCQUFBO0VBQ0Esc0NBQUE7RUFDQSw0Q0FBQTtFQUNBLGlDQUFBO0VBQ0EsNEJBQUE7RUFDQSw4QkFBQTtFQUNBLHNCQUFBO0VBQ0Esa0JBQUE7RUFDQSxlQUFBO0FBQ0Y7QUFBRTtFQUNFLGtEQUFBO0FBRUo7O0FBQ0U7RUFDRSxZQUFBO0VBQ0EsZ0JBQUE7RUFDQSxtQkFBQTtFQUNBLGdEQUFBO0FBRUoiLCJzb3VyY2VzQ29udGVudCI6WyIuYnJhbmQtbmV1ZS1idXR0b25cbiAgZ2FwOiB2YXIoLS1zcGFjaW5nLTJ4KVxuICBib3JkZXItcmFkaXVzOiB2YXIoLS1yb3VuZG5lc3Mtc3VidGxlKVxuICBiYWNrZ3JvdW5kOiB2YXIoLS1jb2xvci1pbnRlcmFjdGl2ZS1wcmltYXJ5KVxuICBjb2xvcjogdmFyKC0tY29sb3ItY29udGVudC1icmFuZClcbiAgZm9udC1mYW1pbHk6IFBvbHlTYW5zLU1lZGlhblxuICBmb250LXNpemU6IHZhcigtLWZvbnQtc2l6ZS0yeClcbiAgbGV0dGVyLXNwYWNpbmc6IDAuMDJlbVxuICB0ZXh0LWFsaWduOiBjZW50ZXJcbiAgcGFkZGluZzogMCAyMHB4XG4gICY6aG92ZXIsICY6YWN0aXZlLCAmOmZvY3VzXG4gICAgYmFja2dyb3VuZDogdmFyKC0tY29sb3ItaW50ZXJhY3RpdmUtcHJpbWFyeS1ob3ZlcilcblxuLmJyYW5kLW5ldWUtYnV0dG9uX19vcGVuLWluLW5ld1xuICAmOjphZnRlclxuICAgIGZvbnQtc2l6ZTogMFxuICAgIG1hcmdpbi1sZWZ0OiA1cHhcbiAgICB2ZXJ0aWNhbC1hbGlnbjogc3ViXG4gICAgY29udGVudDogdXJsKCdkYXRhOmltYWdlL3N2Zyt4bWwsPHN2ZyB3aWR0aD1cIjE0XCIgaGVpZ2h0PVwiMTRcIiB2aWV3Qm94PVwiMCAwIDIwIDIwXCIgZmlsbD1cIm5vbmVcIiB4bWxucz1cImh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnXCI+PGcgaWQ9XCJpY28tLy0yNC0vLWFjdGlvbnMtLy1vcGVuX2luX25ld1wiPjxwYXRoIGlkPVwiSWNvbi1jb2xvclwiIGQ9XCJNMTcuNSAxMi4wODMzVjE1LjgzMzNDMTcuNSAxNi43NTM4IDE2Ljc1MzggMTcuNSAxNS44MzMzIDE3LjVINC4xNjY2N0MzLjI0NjE5IDE3LjUgMi41IDE2Ljc1MzggMi41IDE1LjgzMzNWNC4xNjY2N0MyLjUgMy4yNDYxOSAzLjI0NjE5IDIuNSA0LjE2NjY3IDIuNUg3LjkxNjY3QzguMTQ2NzkgMi41IDguMzMzMzMgMi42ODY1NSA4LjMzMzMzIDIuOTE2NjdWMy43NUM4LjMzMzMzIDMuOTgwMTIgOC4xNDY3OSA0LjE2NjY3IDcuOTE2NjcgNC4xNjY2N0g0LjE2NjY3VjE1LjgzMzNIMTUuODMzM1YxMi4wODMzQzE1LjgzMzMgMTEuODUzMiAxNi4wMTk5IDExLjY2NjcgMTYuMjUgMTEuNjY2N0gxNy4wODMzQzE3LjMxMzUgMTEuNjY2NyAxNy41IDExLjg1MzIgMTcuNSAxMi4wODMzWk0xNy4zMTY3IDIuOTE2NjdMMTcuMDkxNyAyLjY5MTY3QzE2Ljk4IDIuNTc1MzUgMTYuODI3OCAyLjUwNjY4IDE2LjY2NjcgMi41SDExLjI1QzExLjAxOTkgMi41IDEwLjgzMzMgMi42ODY1NSAxMC44MzMzIDIuOTE2NjdWMy43NUMxMC44MzMzIDMuOTgwMTIgMTEuMDE5OSA0LjE2NjY3IDExLjI1IDQuMTY2NjdIMTQuNjU4M0w3LjYyNSAxMS4yQzcuNTQ2MTIgMTEuMjc4MiA3LjUwMTc1IDExLjM4NDcgNy41MDE3NSAxMS40OTU4QzcuNTAxNzUgMTEuNjA2OSA3LjU0NjEyIDExLjcxMzQgNy42MjUgMTEuNzkxN0w4LjIwODMzIDEyLjM3NUM4LjI4NjU3IDEyLjQ1MzkgOC4zOTMwNyAxMi40OTgyIDguNTA0MTcgMTIuNDk4MkM4LjYxNTI3IDEyLjQ5ODIgOC43MjE3NiAxMi40NTM5IDguOCAxMi4zNzVMMTUuODMzMyA1LjM1VjguNzVDMTUuODMzMyA4Ljk4MDEyIDE2LjAxOTkgOS4xNjY2NyAxNi4yNSA5LjE2NjY3SDE3LjA4MzNDMTcuMzEzNSA5LjE2NjY3IDE3LjUgOC45ODAxMiAxNy41IDguNzVWMy4zMzMzM0MxNy40OTU1IDMuMTczNDIgMTcuNDI5OSAzLjAyMTMyIDE3LjMxNjcgMi45MDgzM1YyLjkxNjY3WlwiIGZpbGw9XCIlMjMxQTQyMDBcIi8+PC9nPjwvc3ZnPicpXG5cbiJdLCJzb3VyY2VSb290IjoiIn0= */
        </style>
        <style type="text/css">
            .fancybox-margin {
                margin-right: 15px;
            }
        </style>
        <style>
            :root {
                --color-grey-1000: #191919;
                --color-grey-1000-mask: rgb(25 25 25 / 0.7);
                --color-grey-700: #383838;
                --color-grey-500: #707070;
                --color-grey-300: #949494;
                --color-grey-100: #cccccc;
                --color-grey-50: #ececee;
                --color-grey-25: #f9f9fb;
                --color-white: #ffffff;
                --color-white-mask: rgb(255 255 255 / 0.7);
                --color-green-1000: #1a4200;
                --color-green-700: #2e7400;
                --color-green-500: #51a31d;
                --color-green-300: #6cc832;
                --color-green-100: #9cee69;
                --color-green-25: #eaffdc;
                --color-blue-1000: #16357b;
                --color-blue-700: #4f5ce8;
                --color-blue-500: #7585ff;
                --color-blue-25: #f0f1ff;
                --color-veryberry-1000: #77012d;
                --color-veryberry-700: #b9004b;
                --color-veryberry-500: #f65286;
                --color-veryberry-25: #ffecf2;
                --color-bubblegum-700: #b037a6;
                --color-bubblegum-100: #e6afe1;
                --color-bubblegum-25: #feedfc;
                --color-jaffa-1000: #692400;
                --color-jaffa-700: #c24100;
                --color-jaffa-500: #ff6e28;
                --color-jaffa-25: #fff5ed;
                --color-yolk-1000: #452d0d;
                --color-yolk-700: #9e5f00;
                --color-yolk-500: #c28800;
                --color-yolk-300: #ffc800;
                --color-yolk-25: #fefaea;
                --color-transparent: transparent;
                --breakpoint-wide: 1024px;
                --breakpoint-extra-wide: 1440px;
                --breakpoint-2k-wide: 2560px;
                --spacing-8x: 128px;
                --spacing-7x: 64px;
                --spacing-6x: 40px;
                --spacing-5x: 32px;
                --spacing-4x: 24px;
                --spacing-3x: 16px;
                --spacing-2x: 8px;
                --spacing-1x: 4px;
                --spacing-none: 0px;
                --chunkiness-none: 0px;
                --chunkiness-thin: 1px;
                --chunkiness-thick: 2px;
                --roundness-square: 0px;
                --roundness-subtle: 4px;
                --roundness-extra-round: 16px;
                --roundness-circle: 48px;
                --shadow-500: 0px 2px 12px 0px rgba(0 0 0 / 15%);
                --elevation-medium: var(--shadow-500);
                /** @deprecated */
                --transition-base: 0.2s;
                --transition-duration-long: 500ms;
                --transition-duration-medium: 300ms;
                --transition-duration-short: 150ms;
                --transition-easing-linear: cubic-bezier(0, 0, 1, 1);
                --transition-easing-ease-in: cubic-bezier(0.42, 0, 1, 1);
                --transition-easing-ease-in-out: cubic-bezier(0.42, 0, 0.58, 1);
                --transition-easing-ease-out: cubic-bezier(0, 0, 0.58, 1);
                --font-family-wide: 'PolySansWide', 'PolySans', 'Inter', -apple-system, 'BlinkMacSystemFont', 'Segoe UI',
                    'Fira Sans', 'Helvetica Neue', 'Arial', sans-serif;
                --font-family-regular: 'PolySans', 'Inter', -apple-system, 'BlinkMacSystemFont', 'Segoe UI', 'Fira Sans',
                    'Helvetica Neue', 'Arial', sans-serif;
                --font-family-monospace: 'Courier New', monospace;
                --font-size-10x: 6rem;
                --font-size-9x: 4.5rem;
                --font-size-8x: 3rem;
                --font-size-7x: 2.25rem;
                --font-size-6x: 1.875rem;
                --font-size-5x: 1.5rem;
                --font-size-4x: 1.125rem;
                --font-size-3x: 1rem;
                --font-size-2x: 0.875rem;
                --font-size-1x: 0.75rem;
                --font-weight-bulky: 700;
                --font-weight-median: 600;
                --font-weight-neutral: 400;
                --font-spacing-tight: -0.02em;
                --font-spacing-normal: 0;
                --font-spacing-loose: 0.02em;
                --font-height-tight: 1;
                --font-height-normal: 1.5;
                --icon-size-5x: 48px;
                --icon-size-4x: 40px;
                --icon-size-3x: 32px;
                --icon-size-2x: 24px;
                --icon-size-1x: 16px;
                --icon-size-text-responsive: calc(var(--font-size-3x) * 1.5);
                --layer-depth-ceiling: 9999;
                --minimum-touch-area: 40px;
                /* component wiring? ------------------------------------------ */
                --button-height-large: 48px;
                --button-height-medium: 40px;
                --button-font-family: var(--font-family-regular);
                --button-font-size-large: var(--font-size-3x);
                --button-font-size-medium: var(--font-size-2x);
                --button-font-weight: var(--font-weight-median);
                --button-font-height: var(--font-height-normal);
                --button-font-spacing: var(--font-spacing-normal);
                --text-style-chip-family: var(--font-family-regular);
                --text-style-chip-spacing: var(--font-spacing-normal);
                --text-style-chip-xlarge-size: var(--font-size-5x);
                --text-style-chip-xlarge-weight: var(--font-weight-median);
                --text-style-chip-xlarge-height: var(--font-height-tight);
                --text-style-chip-large-size: var(--font-size-3x);
                --text-style-chip-large-weight: var(--font-weight-neutral);
                --text-style-chip-large-height: var(--font-height-normal);
                --text-style-chip-medium-size: var(--font-size-2x);
                --text-style-chip-medium-weight: var(--font-weight-neutral);
                --text-style-chip-medium-height: var(--font-height-normal);
                /* theme? ------------------------------------------------- */
                --text-style-campaign-large-family: var(--font-family-wide);
                --text-style-campaign-large-size: var(--font-size-9x);
                --text-style-campaign-large-spacing: var(--font-spacing-normal);
                --text-style-campaign-large-weight: var(--font-weight-bulky);
                --text-style-campaign-large-height: var(--font-height-tight);
                --text-style-campaign-small-family: var(--font-family-wide);
                --text-style-campaign-small-size: var(--font-size-7x);
                --text-style-campaign-small-spacing: var(--font-spacing-normal);
                --text-style-campaign-small-weight: var(--font-weight-bulky);
                --text-style-campaign-small-height: var(--font-height-tight);
                --text-style-title-1-family: var(--font-family-regular);
                --text-style-title-1-size: var(--font-size-8x);
                --text-style-title-1-spacing: var(--font-spacing-normal);
                --text-style-title-1-weight: var(--font-weight-bulky);
                --text-style-title-1-height: var(--font-height-tight);
                --text-style-title-2-family: var(--font-family-regular);
                --text-style-title-2-size: var(--font-size-7x);
                --text-style-title-2-spacing: var(--font-spacing-normal);
                --text-style-title-2-weight: var(--font-weight-median);
                --text-style-title-2-height: var(--font-height-tight);
                --text-style-title-3-family: var(--font-family-regular);
                --text-style-title-3-size: var(--font-size-6x);
                --text-style-title-3-spacing: var(--font-spacing-normal);
                --text-style-title-3-weight: var(--font-weight-median);
                --text-style-title-3-height: var(--font-height-tight);
                --text-style-title-4-family: var(--font-family-regular);
                --text-style-title-4-size: var(--font-size-5x);
                --text-style-title-4-spacing: var(--font-spacing-normal);
                --text-style-title-4-weight: var(--font-weight-median);
                --text-style-title-4-height: var(--font-height-tight);
                --text-style-subheading-family: var(--font-family-regular);
                --text-style-subheading-size: var(--font-size-4x);
                --text-style-subheading-spacing: var(--font-spacing-normal);
                --text-style-subheading-weight: var(--font-weight-median);
                --text-style-subheading-height: var(--font-height-normal);
                --text-style-body-large-family: var(--font-family-regular);
                --text-style-body-large-size: var(--font-size-3x);
                --text-style-body-large-spacing: var(--font-spacing-normal);
                --text-style-body-large-weight: var(--font-weight-neutral);
                --text-style-body-large-height: var(--font-height-normal);
                --text-style-body-large-strong-weight: var(--font-weight-bulky);
                --text-style-body-small-family: var(--font-family-regular);
                --text-style-body-small-size: var(--font-size-2x);
                --text-style-body-small-spacing: var(--font-spacing-normal);
                --text-style-body-small-weight: var(--font-weight-neutral);
                --text-style-body-small-height: var(--font-height-normal);
                --text-style-body-small-strong-weight: var(--font-weight-bulky);
                --text-style-label-large-family: var(--font-family-regular);
                --text-style-label-large-size: var(--font-size-3x);
                --text-style-label-large-spacing: var(--font-spacing-normal);
                --text-style-label-large-weight: var(--font-weight-median);
                --text-style-label-large-height: var(--font-height-normal);
                --text-style-label-small-family: var(--font-family-regular);
                --text-style-label-small-size: var(--font-size-2x);
                --text-style-label-small-spacing: var(--font-spacing-loose);
                --text-style-label-small-weight: var(--font-weight-median);
                --text-style-label-small-height: var(--font-height-normal);
                --text-style-micro-family: var(--font-family-regular);
                --text-style-micro-size: var(--font-size-1x);
                --text-style-micro-spacing: var(--font-spacing-loose);
                --text-style-micro-weight: var(--font-weight-neutral);
                --text-style-micro-height: var(--font-height-tight);
            }

            .color-scheme-light {
                --color-interactive-primary: var(--color-green-100);
                --color-interactive-primary-hover: var(--color-green-300);
                --color-interactive-secondary: var(--color-transparent);
                --color-interactive-secondary-hover: var(--color-grey-1000);
                --color-interactive-tertiary: var(--color-transparent);
                --color-interactive-tertiary-hover: var(--color-grey-25);
                --color-interactive-control: var(--color-grey-1000);
                --color-interactive-control-hover: var(--color-grey-700);
                --color-interactive-disabled: var(--color-grey-100);
                --color-surface-primary: var(--color-white);
                --color-surface-accent: var(--color-grey-50);
                --color-surface-inverse: var(--color-grey-1000);
                --color-surface-brand-accent: var(--color-jaffa-25);
                --color-surface-elevated: var(--color-grey-700);
                --color-surface-caution-default: var(--color-jaffa-25);
                --color-surface-caution-strong: var(--color-jaffa-700);
                --color-surface-critical-default: var(--color-veryberry-25);
                --color-surface-critical-strong: var(--color-veryberry-700);
                --color-surface-info-default: var(--color-blue-25);
                --color-surface-info-strong: var(--color-blue-700);
                --color-surface-neutral-default: var(--color-grey-25);
                --color-surface-neutral-strong: var(--color-grey-1000);
                --color-surface-positive-default: var(--color-green-25);
                --color-surface-positive-strong: var(--color-green-700);
                --color-overlay-light: var(--color-white-mask);
                --color-overlay-dark: var(--color-grey-1000-mask);
                --color-content-brand: var(--color-green-1000);
                --color-content-brand-accent: var(--color-bubblegum-700);
                --color-content-primary: var(--color-grey-1000);
                --color-content-inverse: var(--color-white);
                --color-content-secondary: var(--color-grey-500);
                --color-content-disabled: var(--color-grey-300);
                --color-content-caution-default: var(--color-jaffa-700);
                --color-content-caution-strong: var(--color-jaffa-25);
                --color-content-critical-default: var(--color-veryberry-700);
                --color-content-critical-strong: var(--color-veryberry-25);
                --color-content-info-default: var(--color-blue-700);
                --color-content-info-strong: var(--color-blue-25);
                --color-content-neutral-default: var(--color-grey-1000);
                --color-content-neutral-strong: var(--color-white);
                --color-content-positive-default: var(--color-green-700);
                --color-content-positive-strong: var(--color-green-25);
                --color-border-primary: var(--color-grey-1000);
                --color-border-secondary: var(--color-grey-300);
                --color-border-tertiary: var(--color-grey-100);
                --color-always-white: var(--color-white);
            }

            .color-scheme-dark {
                --color-interactive-primary: var(--color-green-100);
                --color-interactive-primary-hover: var(--color-green-300);
                --color-interactive-secondary: var(--color-transparent);
                --color-interactive-secondary-hover: var(--color-white);
                --color-interactive-tertiary: var(--color-transparent);
                --color-interactive-tertiary-hover: var(--color-grey-700);
                --color-interactive-control: var(--color-white);
                --color-interactive-control-hover: var(--color-grey-100);
                --color-interactive-disabled: var(--color-grey-700);
                --color-surface-primary: var(--color-grey-1000);
                --color-surface-accent: var(--color-grey-700);
                --color-surface-inverse: var(--color-white);
                --color-surface-brand-accent: var(--color-grey-700);
                --color-surface-elevated: var(--color-grey-700);
                --color-surface-caution-default: var(--color-jaffa-1000);
                --color-surface-caution-strong: var(--color-jaffa-500);
                --color-surface-critical-default: var(--color-veryberry-1000);
                --color-surface-critical-strong: var(--color-veryberry-500);
                --color-surface-info-default: var(--color-blue-1000);
                --color-surface-info-strong: var(--color-blue-500);
                --color-surface-neutral-default: var(--color-grey-700);
                --color-surface-neutral-strong: var(--color-white);
                --color-surface-positive-default: var(--color-green-1000);
                --color-surface-positive-strong: var(--color-green-500);
                --color-overlay-light: var(--color-white-mask);
                --color-overlay-dark: var(--color-grey-1000-mask);
                --color-content-brand: var(--color-green-1000);
                --color-content-brand-accent: var(--color-bubblegum-100);
                --color-content-primary: var(--color-white);
                --color-content-inverse: var(--color-grey-1000);
                --color-content-secondary: var(--color-grey-100);
                --color-content-disabled: var(--color-grey-500);
                --color-content-caution-default: var(--color-jaffa-500);
                --color-content-caution-strong: var(--color-jaffa-1000);
                --color-content-critical-default: var(--color-veryberry-500);
                --color-content-critical-strong: var(--color-veryberry-1000);
                --color-content-info-default: var(--color-blue-500);
                --color-content-info-strong: var(--color-blue-1000);
                --color-content-neutral-default: var(--color-white);
                --color-content-neutral-strong: var(--color-grey-1000);
                --color-content-positive-default: var(--color-green-500);
                --color-content-positive-strong: var(--color-green-1000);
                --color-border-primary: var(--color-white);
                --color-border-secondary: var(--color-grey-500);
                --color-border-tertiary: var(--color-grey-700);
                --color-always-white: var(--color-white);
            }
            /*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL2FwcC9qYXZhc2NyaXB0L2NvbXBvbmVudHMvYnJhbmRfbmV1ZV90b2tlbnMvYmFzZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUVBO0VBQ0UsMEJBQUE7RUFDQSwyQ0FBQTtFQUNBLHlCQUFBO0VBQ0EseUJBQUE7RUFDQSx5QkFBQTtFQUNBLHlCQUFBO0VBQ0Esd0JBQUE7RUFDQSx3QkFBQTtFQUNBLHNCQUFBO0VBQ0EsMENBQUE7RUFFQSwyQkFBQTtFQUNBLDBCQUFBO0VBQ0EsMEJBQUE7RUFDQSwwQkFBQTtFQUNBLDBCQUFBO0VBQ0EseUJBQUE7RUFFQSwwQkFBQTtFQUNBLHlCQUFBO0VBQ0EseUJBQUE7RUFDQSx3QkFBQTtFQUVBLCtCQUFBO0VBQ0EsOEJBQUE7RUFDQSw4QkFBQTtFQUNBLDZCQUFBO0VBRUEsOEJBQUE7RUFDQSw4QkFBQTtFQUNBLDZCQUFBO0VBRUEsMkJBQUE7RUFDQSwwQkFBQTtFQUNBLDBCQUFBO0VBQ0EseUJBQUE7RUFFQSwwQkFBQTtFQUNBLHlCQUFBO0VBQ0EseUJBQUE7RUFDQSx5QkFBQTtFQUNBLHdCQUFBO0VBRUEsZ0NBQUE7RUFFQSx5QkFBQTtFQUNBLCtCQUFBO0VBQ0EsNEJBQUE7RUFFQSxtQkFBQTtFQUNBLGtCQUFBO0VBQ0Esa0JBQUE7RUFDQSxrQkFBQTtFQUNBLGtCQUFBO0VBQ0Esa0JBQUE7RUFDQSxpQkFBQTtFQUNBLGlCQUFBO0VBQ0EsbUJBQUE7RUFFQSxzQkFBQTtFQUNBLHNCQUFBO0VBQ0EsdUJBQUE7RUFFQSx1QkFBQTtFQUNBLHVCQUFBO0VBQ0EsNkJBQUE7RUFDQSx3QkFBQTtFQUVBLGdEQUFBO0VBQ0EscUNBQUE7RUFFQSxpQkFBQTtFQUNBLHVCQUFBO0VBRUEsaUNBQUE7RUFDQSxtQ0FBQTtFQUNBLGtDQUFBO0VBRUEsb0RBQUE7RUFDQSx3REFBQTtFQUNBLCtEQUFBO0VBQ0EseURBQUE7RUFFQTtrRUFBQTtFQUVBO3NEQUFBO0VBRUEsaURBQUE7RUFFQSxxQkFBQTtFQUNBLHNCQUFBO0VBQ0Esb0JBQUE7RUFDQSx1QkFBQTtFQUNBLHdCQUFBO0VBQ0Esc0JBQUE7RUFDQSx3QkFBQTtFQUNBLG9CQUFBO0VBQ0Esd0JBQUE7RUFDQSx1QkFBQTtFQUVBLHdCQUFBO0VBQ0EseUJBQUE7RUFDQSwwQkFBQTtFQUVBLDZCQUFBO0VBQ0Esd0JBQUE7RUFDQSw0QkFBQTtFQUVBLHNCQUFBO0VBQ0EseUJBQUE7RUFFQSxvQkFBQTtFQUNBLG9CQUFBO0VBQ0Esb0JBQUE7RUFDQSxvQkFBQTtFQUNBLG9CQUFBO0VBQ0EsNERBQUE7RUFFQSwyQkFBQTtFQUVBLDBCQUFBO0VBRUEsaUVBQUE7RUFFQSwyQkFBQTtFQUNBLDRCQUFBO0VBQ0EsZ0RBQUE7RUFDQSw2Q0FBQTtFQUNBLDhDQUFBO0VBQ0EsK0NBQUE7RUFDQSwrQ0FBQTtFQUNBLGlEQUFBO0VBRUEsb0RBQUE7RUFDQSxxREFBQTtFQUNBLGtEQUFBO0VBQ0EsMERBQUE7RUFDQSx5REFBQTtFQUNBLGlEQUFBO0VBQ0EsMERBQUE7RUFDQSx5REFBQTtFQUNBLGtEQUFBO0VBQ0EsMkRBQUE7RUFDQSwwREFBQTtFQUVBLDZEQUFBO0VBRUEsMkRBQUE7RUFDQSxxREFBQTtFQUNBLCtEQUFBO0VBQ0EsNERBQUE7RUFDQSw0REFBQTtFQUVBLDJEQUFBO0VBQ0EscURBQUE7RUFDQSwrREFBQTtFQUNBLDREQUFBO0VBQ0EsNERBQUE7RUFFQSx1REFBQTtFQUNBLDhDQUFBO0VBQ0Esd0RBQUE7RUFDQSxxREFBQTtFQUNBLHFEQUFBO0VBRUEsdURBQUE7RUFDQSw4Q0FBQTtFQUNBLHdEQUFBO0VBQ0Esc0RBQUE7RUFDQSxxREFBQTtFQUVBLHVEQUFBO0VBQ0EsOENBQUE7RUFDQSx3REFBQTtFQUNBLHNEQUFBO0VBQ0EscURBQUE7RUFFQSx1REFBQTtFQUNBLDhDQUFBO0VBQ0Esd0RBQUE7RUFDQSxzREFBQTtFQUNBLHFEQUFBO0VBRUEsMERBQUE7RUFDQSxpREFBQTtFQUNBLDJEQUFBO0VBQ0EseURBQUE7RUFDQSx5REFBQTtFQUVBLDBEQUFBO0VBQ0EsaURBQUE7RUFDQSwyREFBQTtFQUNBLDBEQUFBO0VBQ0EseURBQUE7RUFDQSwrREFBQTtFQUVBLDBEQUFBO0VBQ0EsaURBQUE7RUFDQSwyREFBQTtFQUNBLDBEQUFBO0VBQ0EseURBQUE7RUFDQSwrREFBQTtFQUVBLDJEQUFBO0VBQ0Esa0RBQUE7RUFDQSw0REFBQTtFQUNBLDBEQUFBO0VBQ0EsMERBQUE7RUFFQSwyREFBQTtFQUNBLGtEQUFBO0VBQ0EsMkRBQUE7RUFDQSwwREFBQTtFQUNBLDBEQUFBO0VBRUEscURBQUE7RUFDQSw0Q0FBQTtFQUNBLHFEQUFBO0VBQ0EscURBQUE7RUFDQSxtREFBQTtBQXhDRjs7QUEyQ0E7RUFDRSxtREFBQTtFQUNBLHlEQUFBO0VBQ0EsdURBQUE7RUFDQSwyREFBQTtFQUNBLHNEQUFBO0VBQ0Esd0RBQUE7RUFDQSxtREFBQTtFQUNBLHdEQUFBO0VBQ0EsbURBQUE7RUFFQSwyQ0FBQTtFQUNBLDRDQUFBO0VBQ0EsK0NBQUE7RUFDQSxtREFBQTtFQUNBLCtDQUFBO0VBQ0Esc0RBQUE7RUFDQSxzREFBQTtFQUNBLDJEQUFBO0VBQ0EsMkRBQUE7RUFDQSxrREFBQTtFQUNBLGtEQUFBO0VBQ0EscURBQUE7RUFDQSxzREFBQTtFQUNBLHVEQUFBO0VBQ0EsdURBQUE7RUFFQSw4Q0FBQTtFQUNBLGlEQUFBO0VBRUEsOENBQUE7RUFDQSx3REFBQTtFQUNBLCtDQUFBO0VBQ0EsMkNBQUE7RUFDQSxnREFBQTtFQUNBLCtDQUFBO0VBQ0EsdURBQUE7RUFDQSxxREFBQTtFQUNBLDREQUFBO0VBQ0EsMERBQUE7RUFDQSxtREFBQTtFQUNBLGlEQUFBO0VBQ0EsdURBQUE7RUFDQSxrREFBQTtFQUNBLHdEQUFBO0VBQ0Esc0RBQUE7RUFFQSw4Q0FBQTtFQUNBLCtDQUFBO0VBQ0EsOENBQUE7RUFFQSx3Q0FBQTtBQTdDRjs7QUFnREE7RUFDRSxtREFBQTtFQUNBLHlEQUFBO0VBQ0EsdURBQUE7RUFDQSx1REFBQTtFQUNBLHNEQUFBO0VBQ0EseURBQUE7RUFDQSwrQ0FBQTtFQUNBLHdEQUFBO0VBQ0EsbURBQUE7RUFFQSwrQ0FBQTtFQUNBLDZDQUFBO0VBQ0EsMkNBQUE7RUFDQSxtREFBQTtFQUNBLCtDQUFBO0VBQ0Esd0RBQUE7RUFDQSxzREFBQTtFQUNBLDZEQUFBO0VBQ0EsMkRBQUE7RUFDQSxvREFBQTtFQUNBLGtEQUFBO0VBQ0Esc0RBQUE7RUFDQSxrREFBQTtFQUNBLHlEQUFBO0VBQ0EsdURBQUE7RUFFQSw4Q0FBQTtFQUNBLGlEQUFBO0VBRUEsOENBQUE7RUFDQSx3REFBQTtFQUNBLDJDQUFBO0VBQ0EsK0NBQUE7RUFDQSxnREFBQTtFQUNBLCtDQUFBO0VBQ0EsdURBQUE7RUFDQSx1REFBQTtFQUNBLDREQUFBO0VBQ0EsNERBQUE7RUFDQSxtREFBQTtFQUNBLG1EQUFBO0VBQ0EsbURBQUE7RUFDQSxzREFBQTtFQUNBLHdEQUFBO0VBQ0Esd0RBQUE7RUFFQSwwQ0FBQTtFQUNBLCtDQUFBO0VBQ0EsOENBQUE7RUFFQSx3Q0FBQTtBQWxERiIsInNvdXJjZXNDb250ZW50IjpbIi8vIENvcGllZCBmcm9tIGh0dHBzOi8vZ2l0aHViLmNvbS9lbnZhdG8vZW52YXRvLWRlc2lnbi10b2tlbnMvYmxvYi9tYWluL3Rva2Vucy5jc3NcblxuOnJvb3Qge1xuICAtLWNvbG9yLWdyZXktMTAwMDogIzE5MTkxOTtcbiAgLS1jb2xvci1ncmV5LTEwMDAtbWFzazogcmdiKDI1IDI1IDI1IC8gMC43KTtcbiAgLS1jb2xvci1ncmV5LTcwMDogIzM4MzgzODtcbiAgLS1jb2xvci1ncmV5LTUwMDogIzcwNzA3MDtcbiAgLS1jb2xvci1ncmV5LTMwMDogIzk0OTQ5NDtcbiAgLS1jb2xvci1ncmV5LTEwMDogI2NjY2NjYztcbiAgLS1jb2xvci1ncmV5LTUwOiAjZWNlY2VlO1xuICAtLWNvbG9yLWdyZXktMjU6ICNmOWY5ZmI7XG4gIC0tY29sb3Itd2hpdGU6ICNmZmZmZmY7XG4gIC0tY29sb3Itd2hpdGUtbWFzazogcmdiKDI1NSAyNTUgMjU1IC8gMC43KTtcblxuICAtLWNvbG9yLWdyZWVuLTEwMDA6ICMxYTQyMDA7XG4gIC0tY29sb3ItZ3JlZW4tNzAwOiAjMmU3NDAwO1xuICAtLWNvbG9yLWdyZWVuLTUwMDogIzUxYTMxZDtcbiAgLS1jb2xvci1ncmVlbi0zMDA6ICM2Y2M4MzI7XG4gIC0tY29sb3ItZ3JlZW4tMTAwOiAjOWNlZTY5O1xuICAtLWNvbG9yLWdyZWVuLTI1OiAjZWFmZmRjO1xuXG4gIC0tY29sb3ItYmx1ZS0xMDAwOiAjMTYzNTdiO1xuICAtLWNvbG9yLWJsdWUtNzAwOiAjNGY1Y2U4O1xuICAtLWNvbG9yLWJsdWUtNTAwOiAjNzU4NWZmO1xuICAtLWNvbG9yLWJsdWUtMjU6ICNmMGYxZmY7XG5cbiAgLS1jb2xvci12ZXJ5YmVycnktMTAwMDogIzc3MDEyZDtcbiAgLS1jb2xvci12ZXJ5YmVycnktNzAwOiAjYjkwMDRiO1xuICAtLWNvbG9yLXZlcnliZXJyeS01MDA6ICNmNjUyODY7XG4gIC0tY29sb3ItdmVyeWJlcnJ5LTI1OiAjZmZlY2YyO1xuXG4gIC0tY29sb3ItYnViYmxlZ3VtLTcwMDogI2IwMzdhNjtcbiAgLS1jb2xvci1idWJibGVndW0tMTAwOiAjZTZhZmUxO1xuICAtLWNvbG9yLWJ1YmJsZWd1bS0yNTogI2ZlZWRmYztcblxuICAtLWNvbG9yLWphZmZhLTEwMDA6ICM2OTI0MDA7XG4gIC0tY29sb3ItamFmZmEtNzAwOiAjYzI0MTAwO1xuICAtLWNvbG9yLWphZmZhLTUwMDogI2ZmNmUyODtcbiAgLS1jb2xvci1qYWZmYS0yNTogI2ZmZjVlZDtcblxuICAtLWNvbG9yLXlvbGstMTAwMDogIzQ1MmQwZDtcbiAgLS1jb2xvci15b2xrLTcwMDogIzllNWYwMDtcbiAgLS1jb2xvci15b2xrLTUwMDogI2MyODgwMDtcbiAgLS1jb2xvci15b2xrLTMwMDogI2ZmYzgwMDtcbiAgLS1jb2xvci15b2xrLTI1OiAjZmVmYWVhO1xuXG4gIC0tY29sb3ItdHJhbnNwYXJlbnQ6IHRyYW5zcGFyZW50O1xuXG4gIC0tYnJlYWtwb2ludC13aWRlOiAxMDI0cHg7XG4gIC0tYnJlYWtwb2ludC1leHRyYS13aWRlOiAxNDQwcHg7XG4gIC0tYnJlYWtwb2ludC0yay13aWRlOiAyNTYwcHg7XG5cbiAgLS1zcGFjaW5nLTh4OiAxMjhweDtcbiAgLS1zcGFjaW5nLTd4OiA2NHB4O1xuICAtLXNwYWNpbmctNng6IDQwcHg7XG4gIC0tc3BhY2luZy01eDogMzJweDtcbiAgLS1zcGFjaW5nLTR4OiAyNHB4O1xuICAtLXNwYWNpbmctM3g6IDE2cHg7XG4gIC0tc3BhY2luZy0yeDogOHB4O1xuICAtLXNwYWNpbmctMXg6IDRweDtcbiAgLS1zcGFjaW5nLW5vbmU6IDBweDtcblxuICAtLWNodW5raW5lc3Mtbm9uZTogMHB4O1xuICAtLWNodW5raW5lc3MtdGhpbjogMXB4O1xuICAtLWNodW5raW5lc3MtdGhpY2s6IDJweDtcblxuICAtLXJvdW5kbmVzcy1zcXVhcmU6IDBweDtcbiAgLS1yb3VuZG5lc3Mtc3VidGxlOiA0cHg7XG4gIC0tcm91bmRuZXNzLWV4dHJhLXJvdW5kOiAxNnB4O1xuICAtLXJvdW5kbmVzcy1jaXJjbGU6IDQ4cHg7XG5cbiAgLS1zaGFkb3ctNTAwOiAwcHggMnB4IDEycHggMHB4IHJnYmEoMCAwIDAgLyAxNSUpO1xuICAtLWVsZXZhdGlvbi1tZWRpdW06IHZhcigtLXNoYWRvdy01MDApO1xuXG4gIC8qKiBAZGVwcmVjYXRlZCAqL1xuICAtLXRyYW5zaXRpb24tYmFzZTogMC4ycztcblxuICAtLXRyYW5zaXRpb24tZHVyYXRpb24tbG9uZzogNTAwbXM7XG4gIC0tdHJhbnNpdGlvbi1kdXJhdGlvbi1tZWRpdW06IDMwMG1zO1xuICAtLXRyYW5zaXRpb24tZHVyYXRpb24tc2hvcnQ6IDE1MG1zO1xuXG4gIC0tdHJhbnNpdGlvbi1lYXNpbmctbGluZWFyOiBjdWJpYy1iZXppZXIoMCwgMCwgMSwgMSk7XG4gIC0tdHJhbnNpdGlvbi1lYXNpbmctZWFzZS1pbjogY3ViaWMtYmV6aWVyKDAuNDIsIDAsIDEsIDEpO1xuICAtLXRyYW5zaXRpb24tZWFzaW5nLWVhc2UtaW4tb3V0OiBjdWJpYy1iZXppZXIoMC40MiwgMCwgMC41OCwgMSk7XG4gIC0tdHJhbnNpdGlvbi1lYXNpbmctZWFzZS1vdXQ6IGN1YmljLWJlemllcigwLCAwLCAwLjU4LCAxKTtcblxuICAtLWZvbnQtZmFtaWx5LXdpZGU6IFwiUG9seVNhbnNXaWRlXCIsIFwiUG9seVNhbnNcIiwgXCJJbnRlclwiLCAtYXBwbGUtc3lzdGVtLCBcIkJsaW5rTWFjU3lzdGVtRm9udFwiLFxuICAgIFwiU2Vnb2UgVUlcIiwgXCJGaXJhIFNhbnNcIiwgXCJIZWx2ZXRpY2EgTmV1ZVwiLCBcIkFyaWFsXCIsIHNhbnMtc2VyaWY7XG4gIC0tZm9udC1mYW1pbHktcmVndWxhcjogXCJQb2x5U2Fuc1wiLCBcIkludGVyXCIsIC1hcHBsZS1zeXN0ZW0sIFwiQmxpbmtNYWNTeXN0ZW1Gb250XCIsIFwiU2Vnb2UgVUlcIixcbiAgICBcIkZpcmEgU2Fuc1wiLCBcIkhlbHZldGljYSBOZXVlXCIsIFwiQXJpYWxcIiwgc2Fucy1zZXJpZjtcbiAgLS1mb250LWZhbWlseS1tb25vc3BhY2U6IFwiQ291cmllciBOZXdcIiwgbW9ub3NwYWNlO1xuXG4gIC0tZm9udC1zaXplLTEweDogNnJlbTtcbiAgLS1mb250LXNpemUtOXg6IDQuNXJlbTtcbiAgLS1mb250LXNpemUtOHg6IDNyZW07XG4gIC0tZm9udC1zaXplLTd4OiAyLjI1cmVtO1xuICAtLWZvbnQtc2l6ZS02eDogMS44NzVyZW07XG4gIC0tZm9udC1zaXplLTV4OiAxLjVyZW07XG4gIC0tZm9udC1zaXplLTR4OiAxLjEyNXJlbTtcbiAgLS1mb250LXNpemUtM3g6IDFyZW07XG4gIC0tZm9udC1zaXplLTJ4OiAwLjg3NXJlbTtcbiAgLS1mb250LXNpemUtMXg6IDAuNzVyZW07XG5cbiAgLS1mb250LXdlaWdodC1idWxreTogNzAwO1xuICAtLWZvbnQtd2VpZ2h0LW1lZGlhbjogNjAwO1xuICAtLWZvbnQtd2VpZ2h0LW5ldXRyYWw6IDQwMDtcblxuICAtLWZvbnQtc3BhY2luZy10aWdodDogLTAuMDJlbTtcbiAgLS1mb250LXNwYWNpbmctbm9ybWFsOiAwO1xuICAtLWZvbnQtc3BhY2luZy1sb29zZTogMC4wMmVtO1xuXG4gIC0tZm9udC1oZWlnaHQtdGlnaHQ6IDE7XG4gIC0tZm9udC1oZWlnaHQtbm9ybWFsOiAxLjU7XG5cbiAgLS1pY29uLXNpemUtNXg6IDQ4cHg7XG4gIC0taWNvbi1zaXplLTR4OiA0MHB4O1xuICAtLWljb24tc2l6ZS0zeDogMzJweDtcbiAgLS1pY29uLXNpemUtMng6IDI0cHg7XG4gIC0taWNvbi1zaXplLTF4OiAxNnB4O1xuICAtLWljb24tc2l6ZS10ZXh0LXJlc3BvbnNpdmU6IGNhbGModmFyKC0tZm9udC1zaXplLTN4KSAqIDEuNSk7XG5cbiAgLS1sYXllci1kZXB0aC1jZWlsaW5nOiA5OTk5O1xuXG4gIC0tbWluaW11bS10b3VjaC1hcmVhOiA0MHB4O1xuXG4gIC8qIGNvbXBvbmVudCB3aXJpbmc/IC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLSAqL1xuXG4gIC0tYnV0dG9uLWhlaWdodC1sYXJnZTogNDhweDtcbiAgLS1idXR0b24taGVpZ2h0LW1lZGl1bTogNDBweDtcbiAgLS1idXR0b24tZm9udC1mYW1pbHk6IHZhcigtLWZvbnQtZmFtaWx5LXJlZ3VsYXIpO1xuICAtLWJ1dHRvbi1mb250LXNpemUtbGFyZ2U6IHZhcigtLWZvbnQtc2l6ZS0zeCk7XG4gIC0tYnV0dG9uLWZvbnQtc2l6ZS1tZWRpdW06IHZhcigtLWZvbnQtc2l6ZS0yeCk7XG4gIC0tYnV0dG9uLWZvbnQtd2VpZ2h0OiB2YXIoLS1mb250LXdlaWdodC1tZWRpYW4pO1xuICAtLWJ1dHRvbi1mb250LWhlaWdodDogdmFyKC0tZm9udC1oZWlnaHQtbm9ybWFsKTtcbiAgLS1idXR0b24tZm9udC1zcGFjaW5nOiB2YXIoLS1mb250LXNwYWNpbmctbm9ybWFsKTtcblxuICAtLXRleHQtc3R5bGUtY2hpcC1mYW1pbHk6IHZhcigtLWZvbnQtZmFtaWx5LXJlZ3VsYXIpO1xuICAtLXRleHQtc3R5bGUtY2hpcC1zcGFjaW5nOiB2YXIoLS1mb250LXNwYWNpbmctbm9ybWFsKTtcbiAgLS10ZXh0LXN0eWxlLWNoaXAteGxhcmdlLXNpemU6IHZhcigtLWZvbnQtc2l6ZS01eCk7XG4gIC0tdGV4dC1zdHlsZS1jaGlwLXhsYXJnZS13ZWlnaHQ6IHZhcigtLWZvbnQtd2VpZ2h0LW1lZGlhbik7XG4gIC0tdGV4dC1zdHlsZS1jaGlwLXhsYXJnZS1oZWlnaHQ6IHZhcigtLWZvbnQtaGVpZ2h0LXRpZ2h0KTtcbiAgLS10ZXh0LXN0eWxlLWNoaXAtbGFyZ2Utc2l6ZTogdmFyKC0tZm9udC1zaXplLTN4KTtcbiAgLS10ZXh0LXN0eWxlLWNoaXAtbGFyZ2Utd2VpZ2h0OiB2YXIoLS1mb250LXdlaWdodC1uZXV0cmFsKTtcbiAgLS10ZXh0LXN0eWxlLWNoaXAtbGFyZ2UtaGVpZ2h0OiB2YXIoLS1mb250LWhlaWdodC1ub3JtYWwpO1xuICAtLXRleHQtc3R5bGUtY2hpcC1tZWRpdW0tc2l6ZTogdmFyKC0tZm9udC1zaXplLTJ4KTtcbiAgLS10ZXh0LXN0eWxlLWNoaXAtbWVkaXVtLXdlaWdodDogdmFyKC0tZm9udC13ZWlnaHQtbmV1dHJhbCk7XG4gIC0tdGV4dC1zdHlsZS1jaGlwLW1lZGl1bS1oZWlnaHQ6IHZhcigtLWZvbnQtaGVpZ2h0LW5vcm1hbCk7XG5cbiAgLyogdGhlbWU/IC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0gKi9cblxuICAtLXRleHQtc3R5bGUtY2FtcGFpZ24tbGFyZ2UtZmFtaWx5OiB2YXIoLS1mb250LWZhbWlseS13aWRlKTtcbiAgLS10ZXh0LXN0eWxlLWNhbXBhaWduLWxhcmdlLXNpemU6IHZhcigtLWZvbnQtc2l6ZS05eCk7XG4gIC0tdGV4dC1zdHlsZS1jYW1wYWlnbi1sYXJnZS1zcGFjaW5nOiB2YXIoLS1mb250LXNwYWNpbmctbm9ybWFsKTtcbiAgLS10ZXh0LXN0eWxlLWNhbXBhaWduLWxhcmdlLXdlaWdodDogdmFyKC0tZm9udC13ZWlnaHQtYnVsa3kpO1xuICAtLXRleHQtc3R5bGUtY2FtcGFpZ24tbGFyZ2UtaGVpZ2h0OiB2YXIoLS1mb250LWhlaWdodC10aWdodCk7XG5cbiAgLS10ZXh0LXN0eWxlLWNhbXBhaWduLXNtYWxsLWZhbWlseTogdmFyKC0tZm9udC1mYW1pbHktd2lkZSk7XG4gIC0tdGV4dC1zdHlsZS1jYW1wYWlnbi1zbWFsbC1zaXplOiB2YXIoLS1mb250LXNpemUtN3gpO1xuICAtLXRleHQtc3R5bGUtY2FtcGFpZ24tc21hbGwtc3BhY2luZzogdmFyKC0tZm9udC1zcGFjaW5nLW5vcm1hbCk7XG4gIC0tdGV4dC1zdHlsZS1jYW1wYWlnbi1zbWFsbC13ZWlnaHQ6IHZhcigtLWZvbnQtd2VpZ2h0LWJ1bGt5KTtcbiAgLS10ZXh0LXN0eWxlLWNhbXBhaWduLXNtYWxsLWhlaWdodDogdmFyKC0tZm9udC1oZWlnaHQtdGlnaHQpO1xuXG4gIC0tdGV4dC1zdHlsZS10aXRsZS0xLWZhbWlseTogdmFyKC0tZm9udC1mYW1pbHktcmVndWxhcik7XG4gIC0tdGV4dC1zdHlsZS10aXRsZS0xLXNpemU6IHZhcigtLWZvbnQtc2l6ZS04eCk7XG4gIC0tdGV4dC1zdHlsZS10aXRsZS0xLXNwYWNpbmc6IHZhcigtLWZvbnQtc3BhY2luZy1ub3JtYWwpO1xuICAtLXRleHQtc3R5bGUtdGl0bGUtMS13ZWlnaHQ6IHZhcigtLWZvbnQtd2VpZ2h0LWJ1bGt5KTtcbiAgLS10ZXh0LXN0eWxlLXRpdGxlLTEtaGVpZ2h0OiB2YXIoLS1mb250LWhlaWdodC10aWdodCk7XG5cbiAgLS10ZXh0LXN0eWxlLXRpdGxlLTItZmFtaWx5OiB2YXIoLS1mb250LWZhbWlseS1yZWd1bGFyKTtcbiAgLS10ZXh0LXN0eWxlLXRpdGxlLTItc2l6ZTogdmFyKC0tZm9udC1zaXplLTd4KTtcbiAgLS10ZXh0LXN0eWxlLXRpdGxlLTItc3BhY2luZzogdmFyKC0tZm9udC1zcGFjaW5nLW5vcm1hbCk7XG4gIC0tdGV4dC1zdHlsZS10aXRsZS0yLXdlaWdodDogdmFyKC0tZm9udC13ZWlnaHQtbWVkaWFuKTtcbiAgLS10ZXh0LXN0eWxlLXRpdGxlLTItaGVpZ2h0OiB2YXIoLS1mb250LWhlaWdodC10aWdodCk7XG5cbiAgLS10ZXh0LXN0eWxlLXRpdGxlLTMtZmFtaWx5OiB2YXIoLS1mb250LWZhbWlseS1yZWd1bGFyKTtcbiAgLS10ZXh0LXN0eWxlLXRpdGxlLTMtc2l6ZTogdmFyKC0tZm9udC1zaXplLTZ4KTtcbiAgLS10ZXh0LXN0eWxlLXRpdGxlLTMtc3BhY2luZzogdmFyKC0tZm9udC1zcGFjaW5nLW5vcm1hbCk7XG4gIC0tdGV4dC1zdHlsZS10aXRsZS0zLXdlaWdodDogdmFyKC0tZm9udC13ZWlnaHQtbWVkaWFuKTtcbiAgLS10ZXh0LXN0eWxlLXRpdGxlLTMtaGVpZ2h0OiB2YXIoLS1mb250LWhlaWdodC10aWdodCk7XG5cbiAgLS10ZXh0LXN0eWxlLXRpdGxlLTQtZmFtaWx5OiB2YXIoLS1mb250LWZhbWlseS1yZWd1bGFyKTtcbiAgLS10ZXh0LXN0eWxlLXRpdGxlLTQtc2l6ZTogdmFyKC0tZm9udC1zaXplLTV4KTtcbiAgLS10ZXh0LXN0eWxlLXRpdGxlLTQtc3BhY2luZzogdmFyKC0tZm9udC1zcGFjaW5nLW5vcm1hbCk7XG4gIC0tdGV4dC1zdHlsZS10aXRsZS00LXdlaWdodDogdmFyKC0tZm9udC13ZWlnaHQtbWVkaWFuKTtcbiAgLS10ZXh0LXN0eWxlLXRpdGxlLTQtaGVpZ2h0OiB2YXIoLS1mb250LWhlaWdodC10aWdodCk7XG5cbiAgLS10ZXh0LXN0eWxlLXN1YmhlYWRpbmctZmFtaWx5OiB2YXIoLS1mb250LWZhbWlseS1yZWd1bGFyKTtcbiAgLS10ZXh0LXN0eWxlLXN1YmhlYWRpbmctc2l6ZTogdmFyKC0tZm9udC1zaXplLTR4KTtcbiAgLS10ZXh0LXN0eWxlLXN1YmhlYWRpbmctc3BhY2luZzogdmFyKC0tZm9udC1zcGFjaW5nLW5vcm1hbCk7XG4gIC0tdGV4dC1zdHlsZS1zdWJoZWFkaW5nLXdlaWdodDogdmFyKC0tZm9udC13ZWlnaHQtbWVkaWFuKTtcbiAgLS10ZXh0LXN0eWxlLXN1YmhlYWRpbmctaGVpZ2h0OiB2YXIoLS1mb250LWhlaWdodC1ub3JtYWwpO1xuXG4gIC0tdGV4dC1zdHlsZS1ib2R5LWxhcmdlLWZhbWlseTogdmFyKC0tZm9udC1mYW1pbHktcmVndWxhcik7XG4gIC0tdGV4dC1zdHlsZS1ib2R5LWxhcmdlLXNpemU6IHZhcigtLWZvbnQtc2l6ZS0zeCk7XG4gIC0tdGV4dC1zdHlsZS1ib2R5LWxhcmdlLXNwYWNpbmc6IHZhcigtLWZvbnQtc3BhY2luZy1ub3JtYWwpO1xuICAtLXRleHQtc3R5bGUtYm9keS1sYXJnZS13ZWlnaHQ6IHZhcigtLWZvbnQtd2VpZ2h0LW5ldXRyYWwpO1xuICAtLXRleHQtc3R5bGUtYm9keS1sYXJnZS1oZWlnaHQ6IHZhcigtLWZvbnQtaGVpZ2h0LW5vcm1hbCk7XG4gIC0tdGV4dC1zdHlsZS1ib2R5LWxhcmdlLXN0cm9uZy13ZWlnaHQ6IHZhcigtLWZvbnQtd2VpZ2h0LWJ1bGt5KTtcblxuICAtLXRleHQtc3R5bGUtYm9keS1zbWFsbC1mYW1pbHk6IHZhcigtLWZvbnQtZmFtaWx5LXJlZ3VsYXIpO1xuICAtLXRleHQtc3R5bGUtYm9keS1zbWFsbC1zaXplOiB2YXIoLS1mb250LXNpemUtMngpO1xuICAtLXRleHQtc3R5bGUtYm9keS1zbWFsbC1zcGFjaW5nOiB2YXIoLS1mb250LXNwYWNpbmctbm9ybWFsKTtcbiAgLS10ZXh0LXN0eWxlLWJvZHktc21hbGwtd2VpZ2h0OiB2YXIoLS1mb250LXdlaWdodC1uZXV0cmFsKTtcbiAgLS10ZXh0LXN0eWxlLWJvZHktc21hbGwtaGVpZ2h0OiB2YXIoLS1mb250LWhlaWdodC1ub3JtYWwpO1xuICAtLXRleHQtc3R5bGUtYm9keS1zbWFsbC1zdHJvbmctd2VpZ2h0OiB2YXIoLS1mb250LXdlaWdodC1idWxreSk7XG5cbiAgLS10ZXh0LXN0eWxlLWxhYmVsLWxhcmdlLWZhbWlseTogdmFyKC0tZm9udC1mYW1pbHktcmVndWxhcik7XG4gIC0tdGV4dC1zdHlsZS1sYWJlbC1sYXJnZS1zaXplOiB2YXIoLS1mb250LXNpemUtM3gpO1xuICAtLXRleHQtc3R5bGUtbGFiZWwtbGFyZ2Utc3BhY2luZzogdmFyKC0tZm9udC1zcGFjaW5nLW5vcm1hbCk7XG4gIC0tdGV4dC1zdHlsZS1sYWJlbC1sYXJnZS13ZWlnaHQ6IHZhcigtLWZvbnQtd2VpZ2h0LW1lZGlhbik7XG4gIC0tdGV4dC1zdHlsZS1sYWJlbC1sYXJnZS1oZWlnaHQ6IHZhcigtLWZvbnQtaGVpZ2h0LW5vcm1hbCk7XG5cbiAgLS10ZXh0LXN0eWxlLWxhYmVsLXNtYWxsLWZhbWlseTogdmFyKC0tZm9udC1mYW1pbHktcmVndWxhcik7XG4gIC0tdGV4dC1zdHlsZS1sYWJlbC1zbWFsbC1zaXplOiB2YXIoLS1mb250LXNpemUtMngpO1xuICAtLXRleHQtc3R5bGUtbGFiZWwtc21hbGwtc3BhY2luZzogdmFyKC0tZm9udC1zcGFjaW5nLWxvb3NlKTtcbiAgLS10ZXh0LXN0eWxlLWxhYmVsLXNtYWxsLXdlaWdodDogdmFyKC0tZm9udC13ZWlnaHQtbWVkaWFuKTtcbiAgLS10ZXh0LXN0eWxlLWxhYmVsLXNtYWxsLWhlaWdodDogdmFyKC0tZm9udC1oZWlnaHQtbm9ybWFsKTtcblxuICAtLXRleHQtc3R5bGUtbWljcm8tZmFtaWx5OiB2YXIoLS1mb250LWZhbWlseS1yZWd1bGFyKTtcbiAgLS10ZXh0LXN0eWxlLW1pY3JvLXNpemU6IHZhcigtLWZvbnQtc2l6ZS0xeCk7XG4gIC0tdGV4dC1zdHlsZS1taWNyby1zcGFjaW5nOiB2YXIoLS1mb250LXNwYWNpbmctbG9vc2UpO1xuICAtLXRleHQtc3R5bGUtbWljcm8td2VpZ2h0OiB2YXIoLS1mb250LXdlaWdodC1uZXV0cmFsKTtcbiAgLS10ZXh0LXN0eWxlLW1pY3JvLWhlaWdodDogdmFyKC0tZm9udC1oZWlnaHQtdGlnaHQpO1xufVxuXG4uY29sb3Itc2NoZW1lLWxpZ2h0IHtcbiAgLS1jb2xvci1pbnRlcmFjdGl2ZS1wcmltYXJ5OiB2YXIoLS1jb2xvci1ncmVlbi0xMDApO1xuICAtLWNvbG9yLWludGVyYWN0aXZlLXByaW1hcnktaG92ZXI6IHZhcigtLWNvbG9yLWdyZWVuLTMwMCk7XG4gIC0tY29sb3ItaW50ZXJhY3RpdmUtc2Vjb25kYXJ5OiB2YXIoLS1jb2xvci10cmFuc3BhcmVudCk7XG4gIC0tY29sb3ItaW50ZXJhY3RpdmUtc2Vjb25kYXJ5LWhvdmVyOiB2YXIoLS1jb2xvci1ncmV5LTEwMDApO1xuICAtLWNvbG9yLWludGVyYWN0aXZlLXRlcnRpYXJ5OiB2YXIoLS1jb2xvci10cmFuc3BhcmVudCk7XG4gIC0tY29sb3ItaW50ZXJhY3RpdmUtdGVydGlhcnktaG92ZXI6IHZhcigtLWNvbG9yLWdyZXktMjUpO1xuICAtLWNvbG9yLWludGVyYWN0aXZlLWNvbnRyb2w6IHZhcigtLWNvbG9yLWdyZXktMTAwMCk7XG4gIC0tY29sb3ItaW50ZXJhY3RpdmUtY29udHJvbC1ob3ZlcjogdmFyKC0tY29sb3ItZ3JleS03MDApO1xuICAtLWNvbG9yLWludGVyYWN0aXZlLWRpc2FibGVkOiB2YXIoLS1jb2xvci1ncmV5LTEwMCk7XG5cbiAgLS1jb2xvci1zdXJmYWNlLXByaW1hcnk6IHZhcigtLWNvbG9yLXdoaXRlKTtcbiAgLS1jb2xvci1zdXJmYWNlLWFjY2VudDogdmFyKC0tY29sb3ItZ3JleS01MCk7XG4gIC0tY29sb3Itc3VyZmFjZS1pbnZlcnNlOiB2YXIoLS1jb2xvci1ncmV5LTEwMDApO1xuICAtLWNvbG9yLXN1cmZhY2UtYnJhbmQtYWNjZW50OiB2YXIoLS1jb2xvci1qYWZmYS0yNSk7XG4gIC0tY29sb3Itc3VyZmFjZS1lbGV2YXRlZDogdmFyKC0tY29sb3ItZ3JleS03MDApO1xuICAtLWNvbG9yLXN1cmZhY2UtY2F1dGlvbi1kZWZhdWx0OiB2YXIoLS1jb2xvci1qYWZmYS0yNSk7XG4gIC0tY29sb3Itc3VyZmFjZS1jYXV0aW9uLXN0cm9uZzogdmFyKC0tY29sb3ItamFmZmEtNzAwKTtcbiAgLS1jb2xvci1zdXJmYWNlLWNyaXRpY2FsLWRlZmF1bHQ6IHZhcigtLWNvbG9yLXZlcnliZXJyeS0yNSk7XG4gIC0tY29sb3Itc3VyZmFjZS1jcml0aWNhbC1zdHJvbmc6IHZhcigtLWNvbG9yLXZlcnliZXJyeS03MDApO1xuICAtLWNvbG9yLXN1cmZhY2UtaW5mby1kZWZhdWx0OiB2YXIoLS1jb2xvci1ibHVlLTI1KTtcbiAgLS1jb2xvci1zdXJmYWNlLWluZm8tc3Ryb25nOiB2YXIoLS1jb2xvci1ibHVlLTcwMCk7XG4gIC0tY29sb3Itc3VyZmFjZS1uZXV0cmFsLWRlZmF1bHQ6IHZhcigtLWNvbG9yLWdyZXktMjUpO1xuICAtLWNvbG9yLXN1cmZhY2UtbmV1dHJhbC1zdHJvbmc6IHZhcigtLWNvbG9yLWdyZXktMTAwMCk7XG4gIC0tY29sb3Itc3VyZmFjZS1wb3NpdGl2ZS1kZWZhdWx0OiB2YXIoLS1jb2xvci1ncmVlbi0yNSk7XG4gIC0tY29sb3Itc3VyZmFjZS1wb3NpdGl2ZS1zdHJvbmc6IHZhcigtLWNvbG9yLWdyZWVuLTcwMCk7XG5cbiAgLS1jb2xvci1vdmVybGF5LWxpZ2h0OiB2YXIoLS1jb2xvci13aGl0ZS1tYXNrKTtcbiAgLS1jb2xvci1vdmVybGF5LWRhcms6IHZhcigtLWNvbG9yLWdyZXktMTAwMC1tYXNrKTtcblxuICAtLWNvbG9yLWNvbnRlbnQtYnJhbmQ6IHZhcigtLWNvbG9yLWdyZWVuLTEwMDApO1xuICAtLWNvbG9yLWNvbnRlbnQtYnJhbmQtYWNjZW50OiB2YXIoLS1jb2xvci1idWJibGVndW0tNzAwKTtcbiAgLS1jb2xvci1jb250ZW50LXByaW1hcnk6IHZhcigtLWNvbG9yLWdyZXktMTAwMCk7XG4gIC0tY29sb3ItY29udGVudC1pbnZlcnNlOiB2YXIoLS1jb2xvci13aGl0ZSk7XG4gIC0tY29sb3ItY29udGVudC1zZWNvbmRhcnk6IHZhcigtLWNvbG9yLWdyZXktNTAwKTtcbiAgLS1jb2xvci1jb250ZW50LWRpc2FibGVkOiB2YXIoLS1jb2xvci1ncmV5LTMwMCk7XG4gIC0tY29sb3ItY29udGVudC1jYXV0aW9uLWRlZmF1bHQ6IHZhcigtLWNvbG9yLWphZmZhLTcwMCk7XG4gIC0tY29sb3ItY29udGVudC1jYXV0aW9uLXN0cm9uZzogdmFyKC0tY29sb3ItamFmZmEtMjUpO1xuICAtLWNvbG9yLWNvbnRlbnQtY3JpdGljYWwtZGVmYXVsdDogdmFyKC0tY29sb3ItdmVyeWJlcnJ5LTcwMCk7XG4gIC0tY29sb3ItY29udGVudC1jcml0aWNhbC1zdHJvbmc6IHZhcigtLWNvbG9yLXZlcnliZXJyeS0yNSk7XG4gIC0tY29sb3ItY29udGVudC1pbmZvLWRlZmF1bHQ6IHZhcigtLWNvbG9yLWJsdWUtNzAwKTtcbiAgLS1jb2xvci1jb250ZW50LWluZm8tc3Ryb25nOiB2YXIoLS1jb2xvci1ibHVlLTI1KTtcbiAgLS1jb2xvci1jb250ZW50LW5ldXRyYWwtZGVmYXVsdDogdmFyKC0tY29sb3ItZ3JleS0xMDAwKTtcbiAgLS1jb2xvci1jb250ZW50LW5ldXRyYWwtc3Ryb25nOiB2YXIoLS1jb2xvci13aGl0ZSk7XG4gIC0tY29sb3ItY29udGVudC1wb3NpdGl2ZS1kZWZhdWx0OiB2YXIoLS1jb2xvci1ncmVlbi03MDApO1xuICAtLWNvbG9yLWNvbnRlbnQtcG9zaXRpdmUtc3Ryb25nOiB2YXIoLS1jb2xvci1ncmVlbi0yNSk7XG5cbiAgLS1jb2xvci1ib3JkZXItcHJpbWFyeTogdmFyKC0tY29sb3ItZ3JleS0xMDAwKTtcbiAgLS1jb2xvci1ib3JkZXItc2Vjb25kYXJ5OiB2YXIoLS1jb2xvci1ncmV5LTMwMCk7XG4gIC0tY29sb3ItYm9yZGVyLXRlcnRpYXJ5OiB2YXIoLS1jb2xvci1ncmV5LTEwMCk7XG5cbiAgLS1jb2xvci1hbHdheXMtd2hpdGU6IHZhcigtLWNvbG9yLXdoaXRlKTtcbn1cblxuLmNvbG9yLXNjaGVtZS1kYXJrIHtcbiAgLS1jb2xvci1pbnRlcmFjdGl2ZS1wcmltYXJ5OiB2YXIoLS1jb2xvci1ncmVlbi0xMDApO1xuICAtLWNvbG9yLWludGVyYWN0aXZlLXByaW1hcnktaG92ZXI6IHZhcigtLWNvbG9yLWdyZWVuLTMwMCk7XG4gIC0tY29sb3ItaW50ZXJhY3RpdmUtc2Vjb25kYXJ5OiB2YXIoLS1jb2xvci10cmFuc3BhcmVudCk7XG4gIC0tY29sb3ItaW50ZXJhY3RpdmUtc2Vjb25kYXJ5LWhvdmVyOiB2YXIoLS1jb2xvci13aGl0ZSk7XG4gIC0tY29sb3ItaW50ZXJhY3RpdmUtdGVydGlhcnk6IHZhcigtLWNvbG9yLXRyYW5zcGFyZW50KTtcbiAgLS1jb2xvci1pbnRlcmFjdGl2ZS10ZXJ0aWFyeS1ob3ZlcjogdmFyKC0tY29sb3ItZ3JleS03MDApO1xuICAtLWNvbG9yLWludGVyYWN0aXZlLWNvbnRyb2w6IHZhcigtLWNvbG9yLXdoaXRlKTtcbiAgLS1jb2xvci1pbnRlcmFjdGl2ZS1jb250cm9sLWhvdmVyOiB2YXIoLS1jb2xvci1ncmV5LTEwMCk7XG4gIC0tY29sb3ItaW50ZXJhY3RpdmUtZGlzYWJsZWQ6IHZhcigtLWNvbG9yLWdyZXktNzAwKTtcblxuICAtLWNvbG9yLXN1cmZhY2UtcHJpbWFyeTogdmFyKC0tY29sb3ItZ3JleS0xMDAwKTtcbiAgLS1jb2xvci1zdXJmYWNlLWFjY2VudDogdmFyKC0tY29sb3ItZ3JleS03MDApO1xuICAtLWNvbG9yLXN1cmZhY2UtaW52ZXJzZTogdmFyKC0tY29sb3Itd2hpdGUpO1xuICAtLWNvbG9yLXN1cmZhY2UtYnJhbmQtYWNjZW50OiB2YXIoLS1jb2xvci1ncmV5LTcwMCk7XG4gIC0tY29sb3Itc3VyZmFjZS1lbGV2YXRlZDogdmFyKC0tY29sb3ItZ3JleS03MDApO1xuICAtLWNvbG9yLXN1cmZhY2UtY2F1dGlvbi1kZWZhdWx0OiB2YXIoLS1jb2xvci1qYWZmYS0xMDAwKTtcbiAgLS1jb2xvci1zdXJmYWNlLWNhdXRpb24tc3Ryb25nOiB2YXIoLS1jb2xvci1qYWZmYS01MDApO1xuICAtLWNvbG9yLXN1cmZhY2UtY3JpdGljYWwtZGVmYXVsdDogdmFyKC0tY29sb3ItdmVyeWJlcnJ5LTEwMDApO1xuICAtLWNvbG9yLXN1cmZhY2UtY3JpdGljYWwtc3Ryb25nOiB2YXIoLS1jb2xvci12ZXJ5YmVycnktNTAwKTtcbiAgLS1jb2xvci1zdXJmYWNlLWluZm8tZGVmYXVsdDogdmFyKC0tY29sb3ItYmx1ZS0xMDAwKTtcbiAgLS1jb2xvci1zdXJmYWNlLWluZm8tc3Ryb25nOiB2YXIoLS1jb2xvci1ibHVlLTUwMCk7XG4gIC0tY29sb3Itc3VyZmFjZS1uZXV0cmFsLWRlZmF1bHQ6IHZhcigtLWNvbG9yLWdyZXktNzAwKTtcbiAgLS1jb2xvci1zdXJmYWNlLW5ldXRyYWwtc3Ryb25nOiB2YXIoLS1jb2xvci13aGl0ZSk7XG4gIC0tY29sb3Itc3VyZmFjZS1wb3NpdGl2ZS1kZWZhdWx0OiB2YXIoLS1jb2xvci1ncmVlbi0xMDAwKTtcbiAgLS1jb2xvci1zdXJmYWNlLXBvc2l0aXZlLXN0cm9uZzogdmFyKC0tY29sb3ItZ3JlZW4tNTAwKTtcblxuICAtLWNvbG9yLW92ZXJsYXktbGlnaHQ6IHZhcigtLWNvbG9yLXdoaXRlLW1hc2spO1xuICAtLWNvbG9yLW92ZXJsYXktZGFyazogdmFyKC0tY29sb3ItZ3JleS0xMDAwLW1hc2spO1xuXG4gIC0tY29sb3ItY29udGVudC1icmFuZDogdmFyKC0tY29sb3ItZ3JlZW4tMTAwMCk7XG4gIC0tY29sb3ItY29udGVudC1icmFuZC1hY2NlbnQ6IHZhcigtLWNvbG9yLWJ1YmJsZWd1bS0xMDApO1xuICAtLWNvbG9yLWNvbnRlbnQtcHJpbWFyeTogdmFyKC0tY29sb3Itd2hpdGUpO1xuICAtLWNvbG9yLWNvbnRlbnQtaW52ZXJzZTogdmFyKC0tY29sb3ItZ3JleS0xMDAwKTtcbiAgLS1jb2xvci1jb250ZW50LXNlY29uZGFyeTogdmFyKC0tY29sb3ItZ3JleS0xMDApO1xuICAtLWNvbG9yLWNvbnRlbnQtZGlzYWJsZWQ6IHZhcigtLWNvbG9yLWdyZXktNTAwKTtcbiAgLS1jb2xvci1jb250ZW50LWNhdXRpb24tZGVmYXVsdDogdmFyKC0tY29sb3ItamFmZmEtNTAwKTtcbiAgLS1jb2xvci1jb250ZW50LWNhdXRpb24tc3Ryb25nOiB2YXIoLS1jb2xvci1qYWZmYS0xMDAwKTtcbiAgLS1jb2xvci1jb250ZW50LWNyaXRpY2FsLWRlZmF1bHQ6IHZhcigtLWNvbG9yLXZlcnliZXJyeS01MDApO1xuICAtLWNvbG9yLWNvbnRlbnQtY3JpdGljYWwtc3Ryb25nOiB2YXIoLS1jb2xvci12ZXJ5YmVycnktMTAwMCk7XG4gIC0tY29sb3ItY29udGVudC1pbmZvLWRlZmF1bHQ6IHZhcigtLWNvbG9yLWJsdWUtNTAwKTtcbiAgLS1jb2xvci1jb250ZW50LWluZm8tc3Ryb25nOiB2YXIoLS1jb2xvci1ibHVlLTEwMDApO1xuICAtLWNvbG9yLWNvbnRlbnQtbmV1dHJhbC1kZWZhdWx0OiB2YXIoLS1jb2xvci13aGl0ZSk7XG4gIC0tY29sb3ItY29udGVudC1uZXV0cmFsLXN0cm9uZzogdmFyKC0tY29sb3ItZ3JleS0xMDAwKTtcbiAgLS1jb2xvci1jb250ZW50LXBvc2l0aXZlLWRlZmF1bHQ6IHZhcigtLWNvbG9yLWdyZWVuLTUwMCk7XG4gIC0tY29sb3ItY29udGVudC1wb3NpdGl2ZS1zdHJvbmc6IHZhcigtLWNvbG9yLWdyZWVuLTEwMDApO1xuXG4gIC0tY29sb3ItYm9yZGVyLXByaW1hcnk6IHZhcigtLWNvbG9yLXdoaXRlKTtcbiAgLS1jb2xvci1ib3JkZXItc2Vjb25kYXJ5OiB2YXIoLS1jb2xvci1ncmV5LTUwMCk7XG4gIC0tY29sb3ItYm9yZGVyLXRlcnRpYXJ5OiB2YXIoLS1jb2xvci1ncmV5LTcwMCk7XG5cbiAgLS1jb2xvci1hbHdheXMtd2hpdGU6IHZhcigtLWNvbG9yLXdoaXRlKTtcbn1cbiJdLCJzb3VyY2VSb290IjoiIn0= */
        </style>
        <style>
            .brand-neue-button {
                gap: var(--spacing-2x);
                border-radius: var(--roundness-subtle);
                background: var(--color-interactive-primary);
                color: var(--color-content-brand);
                font-family: PolySans-Median;
                font-size: var(--font-size-2x);
                letter-spacing: 0.02em;
                text-align: center;
                padding: 0 20px;
            }
            .brand-neue-button:hover,
            .brand-neue-button:active,
            .brand-neue-button:focus {
                background: var(--color-interactive-primary-hover);
            }

            .brand-neue-button__open-in-new::after {
                font-size: 0;
                margin-left: 5px;
                vertical-align: sub;
                content: url('data:image/svg+xml,<svg width="14" height="14" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg"><g id="ico-/-24-/-actions-/-open_in_new"><path id="Icon-color" d="M17.5 12.0833V15.8333C17.5 16.7538 16.7538 17.5 15.8333 17.5H4.16667C3.24619 17.5 2.5 16.7538 2.5 15.8333V4.16667C2.5 3.24619 3.24619 2.5 4.16667 2.5H7.91667C8.14679 2.5 8.33333 2.68655 8.33333 2.91667V3.75C8.33333 3.98012 8.14679 4.16667 7.91667 4.16667H4.16667V15.8333H15.8333V12.0833C15.8333 11.8532 16.0199 11.6667 16.25 11.6667H17.0833C17.3135 11.6667 17.5 11.8532 17.5 12.0833ZM17.3167 2.91667L17.0917 2.69167C16.98 2.57535 16.8278 2.50668 16.6667 2.5H11.25C11.0199 2.5 10.8333 2.68655 10.8333 2.91667V3.75C10.8333 3.98012 11.0199 4.16667 11.25 4.16667H14.6583L7.625 11.2C7.54612 11.2782 7.50175 11.3847 7.50175 11.4958C7.50175 11.6069 7.54612 11.7134 7.625 11.7917L8.20833 12.375C8.28657 12.4539 8.39307 12.4982 8.50417 12.4982C8.61527 12.4982 8.72176 12.4539 8.8 12.375L15.8333 5.35V8.75C15.8333 8.98012 16.0199 9.16667 16.25 9.16667H17.0833C17.3135 9.16667 17.5 8.98012 17.5 8.75V3.33333C17.4955 3.17342 17.4299 3.02132 17.3167 2.90833V2.91667Z" fill="%231A4200"/></g></svg>');
            }
            /*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL2FwcC9qYXZhc2NyaXB0L2NvbXBvbmVudHMvYnJhbmRfbmV1ZV90b2tlbnMvY29tcG9uZW50cy9idXR0b24uc2FzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLHNCQUFBO0VBQ0Esc0NBQUE7RUFDQSw0Q0FBQTtFQUNBLGlDQUFBO0VBQ0EsNEJBQUE7RUFDQSw4QkFBQTtFQUNBLHNCQUFBO0VBQ0Esa0JBQUE7RUFDQSxlQUFBO0FBQ0Y7QUFBRTtFQUNFLGtEQUFBO0FBRUo7O0FBQ0U7RUFDRSxZQUFBO0VBQ0EsZ0JBQUE7RUFDQSxtQkFBQTtFQUNBLGdEQUFBO0FBRUoiLCJzb3VyY2VzQ29udGVudCI6WyIuYnJhbmQtbmV1ZS1idXR0b25cbiAgZ2FwOiB2YXIoLS1zcGFjaW5nLTJ4KVxuICBib3JkZXItcmFkaXVzOiB2YXIoLS1yb3VuZG5lc3Mtc3VidGxlKVxuICBiYWNrZ3JvdW5kOiB2YXIoLS1jb2xvci1pbnRlcmFjdGl2ZS1wcmltYXJ5KVxuICBjb2xvcjogdmFyKC0tY29sb3ItY29udGVudC1icmFuZClcbiAgZm9udC1mYW1pbHk6IFBvbHlTYW5zLU1lZGlhblxuICBmb250LXNpemU6IHZhcigtLWZvbnQtc2l6ZS0yeClcbiAgbGV0dGVyLXNwYWNpbmc6IDAuMDJlbVxuICB0ZXh0LWFsaWduOiBjZW50ZXJcbiAgcGFkZGluZzogMCAyMHB4XG4gICY6aG92ZXIsICY6YWN0aXZlLCAmOmZvY3VzXG4gICAgYmFja2dyb3VuZDogdmFyKC0tY29sb3ItaW50ZXJhY3RpdmUtcHJpbWFyeS1ob3ZlcilcblxuLmJyYW5kLW5ldWUtYnV0dG9uX19vcGVuLWluLW5ld1xuICAmOjphZnRlclxuICAgIGZvbnQtc2l6ZTogMFxuICAgIG1hcmdpbi1sZWZ0OiA1cHhcbiAgICB2ZXJ0aWNhbC1hbGlnbjogc3ViXG4gICAgY29udGVudDogdXJsKCdkYXRhOmltYWdlL3N2Zyt4bWwsPHN2ZyB3aWR0aD1cIjE0XCIgaGVpZ2h0PVwiMTRcIiB2aWV3Qm94PVwiMCAwIDIwIDIwXCIgZmlsbD1cIm5vbmVcIiB4bWxucz1cImh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnXCI+PGcgaWQ9XCJpY28tLy0yNC0vLWFjdGlvbnMtLy1vcGVuX2luX25ld1wiPjxwYXRoIGlkPVwiSWNvbi1jb2xvclwiIGQ9XCJNMTcuNSAxMi4wODMzVjE1LjgzMzNDMTcuNSAxNi43NTM4IDE2Ljc1MzggMTcuNSAxNS44MzMzIDE3LjVINC4xNjY2N0MzLjI0NjE5IDE3LjUgMi41IDE2Ljc1MzggMi41IDE1LjgzMzNWNC4xNjY2N0MyLjUgMy4yNDYxOSAzLjI0NjE5IDIuNSA0LjE2NjY3IDIuNUg3LjkxNjY3QzguMTQ2NzkgMi41IDguMzMzMzMgMi42ODY1NSA4LjMzMzMzIDIuOTE2NjdWMy43NUM4LjMzMzMzIDMuOTgwMTIgOC4xNDY3OSA0LjE2NjY3IDcuOTE2NjcgNC4xNjY2N0g0LjE2NjY3VjE1LjgzMzNIMTUuODMzM1YxMi4wODMzQzE1LjgzMzMgMTEuODUzMiAxNi4wMTk5IDExLjY2NjcgMTYuMjUgMTEuNjY2N0gxNy4wODMzQzE3LjMxMzUgMTEuNjY2NyAxNy41IDExLjg1MzIgMTcuNSAxMi4wODMzWk0xNy4zMTY3IDIuOTE2NjdMMTcuMDkxNyAyLjY5MTY3QzE2Ljk4IDIuNTc1MzUgMTYuODI3OCAyLjUwNjY4IDE2LjY2NjcgMi41SDExLjI1QzExLjAxOTkgMi41IDEwLjgzMzMgMi42ODY1NSAxMC44MzMzIDIuOTE2NjdWMy43NUMxMC44MzMzIDMuOTgwMTIgMTEuMDE5OSA0LjE2NjY3IDExLjI1IDQuMTY2NjdIMTQuNjU4M0w3LjYyNSAxMS4yQzcuNTQ2MTIgMTEuMjc4MiA3LjUwMTc1IDExLjM4NDcgNy41MDE3NSAxMS40OTU4QzcuNTAxNzUgMTEuNjA2OSA3LjU0NjEyIDExLjcxMzQgNy42MjUgMTEuNzkxN0w4LjIwODMzIDEyLjM3NUM4LjI4NjU3IDEyLjQ1MzkgOC4zOTMwNyAxMi40OTgyIDguNTA0MTcgMTIuNDk4MkM4LjYxNTI3IDEyLjQ5ODIgOC43MjE3NiAxMi40NTM5IDguOCAxMi4zNzVMMTUuODMzMyA1LjM1VjguNzVDMTUuODMzMyA4Ljk4MDEyIDE2LjAxOTkgOS4xNjY2NyAxNi4yNSA5LjE2NjY3SDE3LjA4MzNDMTcuMzEzNSA5LjE2NjY3IDE3LjUgOC45ODAxMiAxNy41IDguNzVWMy4zMzMzM0MxNy40OTU1IDMuMTczNDIgMTcuNDI5OSAzLjAyMTMyIDE3LjMxNjcgMi45MDgzM1YyLjkxNjY3WlwiIGZpbGw9XCIlMjMxQTQyMDBcIi8+PC9nPjwvc3ZnPicpXG5cbiJdLCJzb3VyY2VSb290IjoiIn0= */
        </style>
        <style>
            :root {
                --color-grey-1000: #191919;
                --color-grey-1000-mask: rgb(25 25 25 / 0.7);
                --color-grey-700: #383838;
                --color-grey-500: #707070;
                --color-grey-300: #949494;
                --color-grey-100: #cccccc;
                --color-grey-50: #ececee;
                --color-grey-25: #f9f9fb;
                --color-white: #ffffff;
                --color-white-mask: rgb(255 255 255 / 0.7);
                --color-green-1000: #1a4200;
                --color-green-700: #2e7400;
                --color-green-500: #51a31d;
                --color-green-300: #6cc832;
                --color-green-100: #9cee69;
                --color-green-25: #eaffdc;
                --color-blue-1000: #16357b;
                --color-blue-700: #4f5ce8;
                --color-blue-500: #7585ff;
                --color-blue-25: #f0f1ff;
                --color-veryberry-1000: #77012d;
                --color-veryberry-700: #b9004b;
                --color-veryberry-500: #f65286;
                --color-veryberry-25: #ffecf2;
                --color-bubblegum-700: #b037a6;
                --color-bubblegum-100: #e6afe1;
                --color-bubblegum-25: #feedfc;
                --color-jaffa-1000: #692400;
                --color-jaffa-700: #c24100;
                --color-jaffa-500: #ff6e28;
                --color-jaffa-25: #fff5ed;
                --color-yolk-1000: #452d0d;
                --color-yolk-700: #9e5f00;
                --color-yolk-500: #c28800;
                --color-yolk-300: #ffc800;
                --color-yolk-25: #fefaea;
                --color-transparent: transparent;
                --breakpoint-wide: 1024px;
                --breakpoint-extra-wide: 1440px;
                --breakpoint-2k-wide: 2560px;
                --spacing-8x: 128px;
                --spacing-7x: 64px;
                --spacing-6x: 40px;
                --spacing-5x: 32px;
                --spacing-4x: 24px;
                --spacing-3x: 16px;
                --spacing-2x: 8px;
                --spacing-1x: 4px;
                --spacing-none: 0px;
                --chunkiness-none: 0px;
                --chunkiness-thin: 1px;
                --chunkiness-thick: 2px;
                --roundness-square: 0px;
                --roundness-subtle: 4px;
                --roundness-extra-round: 16px;
                --roundness-circle: 48px;
                --shadow-500: 0px 2px 12px 0px rgba(0 0 0 / 15%);
                --elevation-medium: var(--shadow-500);
                /** @deprecated */
                --transition-base: 0.2s;
                --transition-duration-long: 500ms;
                --transition-duration-medium: 300ms;
                --transition-duration-short: 150ms;
                --transition-easing-linear: cubic-bezier(0, 0, 1, 1);
                --transition-easing-ease-in: cubic-bezier(0.42, 0, 1, 1);
                --transition-easing-ease-in-out: cubic-bezier(0.42, 0, 0.58, 1);
                --transition-easing-ease-out: cubic-bezier(0, 0, 0.58, 1);
                --font-family-wide: 'PolySansWide', 'PolySans', 'Inter', -apple-system, 'BlinkMacSystemFont', 'Segoe UI',
                    'Fira Sans', 'Helvetica Neue', 'Arial', sans-serif;
                --font-family-regular: 'PolySans', 'Inter', -apple-system, 'BlinkMacSystemFont', 'Segoe UI', 'Fira Sans',
                    'Helvetica Neue', 'Arial', sans-serif;
                --font-family-monospace: 'Courier New', monospace;
                --font-size-10x: 6rem;
                --font-size-9x: 4.5rem;
                --font-size-8x: 3rem;
                --font-size-7x: 2.25rem;
                --font-size-6x: 1.875rem;
                --font-size-5x: 1.5rem;
                --font-size-4x: 1.125rem;
                --font-size-3x: 1rem;
                --font-size-2x: 0.875rem;
                --font-size-1x: 0.75rem;
                --font-weight-bulky: 700;
                --font-weight-median: 600;
                --font-weight-neutral: 400;
                --font-spacing-tight: -0.02em;
                --font-spacing-normal: 0;
                --font-spacing-loose: 0.02em;
                --font-height-tight: 1;
                --font-height-normal: 1.5;
                --icon-size-5x: 48px;
                --icon-size-4x: 40px;
                --icon-size-3x: 32px;
                --icon-size-2x: 24px;
                --icon-size-1x: 16px;
                --icon-size-text-responsive: calc(var(--font-size-3x) * 1.5);
                --layer-depth-ceiling: 9999;
                --minimum-touch-area: 40px;
                /* component wiring? ------------------------------------------ */
                --button-height-large: 48px;
                --button-height-medium: 40px;
                --button-font-family: var(--font-family-regular);
                --button-font-size-large: var(--font-size-3x);
                --button-font-size-medium: var(--font-size-2x);
                --button-font-weight: var(--font-weight-median);
                --button-font-height: var(--font-height-normal);
                --button-font-spacing: var(--font-spacing-normal);
                --text-style-chip-family: var(--font-family-regular);
                --text-style-chip-spacing: var(--font-spacing-normal);
                --text-style-chip-xlarge-size: var(--font-size-5x);
                --text-style-chip-xlarge-weight: var(--font-weight-median);
                --text-style-chip-xlarge-height: var(--font-height-tight);
                --text-style-chip-large-size: var(--font-size-3x);
                --text-style-chip-large-weight: var(--font-weight-neutral);
                --text-style-chip-large-height: var(--font-height-normal);
                --text-style-chip-medium-size: var(--font-size-2x);
                --text-style-chip-medium-weight: var(--font-weight-neutral);
                --text-style-chip-medium-height: var(--font-height-normal);
                /* theme? ------------------------------------------------- */
                --text-style-campaign-large-family: var(--font-family-wide);
                --text-style-campaign-large-size: var(--font-size-9x);
                --text-style-campaign-large-spacing: var(--font-spacing-normal);
                --text-style-campaign-large-weight: var(--font-weight-bulky);
                --text-style-campaign-large-height: var(--font-height-tight);
                --text-style-campaign-small-family: var(--font-family-wide);
                --text-style-campaign-small-size: var(--font-size-7x);
                --text-style-campaign-small-spacing: var(--font-spacing-normal);
                --text-style-campaign-small-weight: var(--font-weight-bulky);
                --text-style-campaign-small-height: var(--font-height-tight);
                --text-style-title-1-family: var(--font-family-regular);
                --text-style-title-1-size: var(--font-size-8x);
                --text-style-title-1-spacing: var(--font-spacing-normal);
                --text-style-title-1-weight: var(--font-weight-bulky);
                --text-style-title-1-height: var(--font-height-tight);
                --text-style-title-2-family: var(--font-family-regular);
                --text-style-title-2-size: var(--font-size-7x);
                --text-style-title-2-spacing: var(--font-spacing-normal);
                --text-style-title-2-weight: var(--font-weight-median);
                --text-style-title-2-height: var(--font-height-tight);
                --text-style-title-3-family: var(--font-family-regular);
                --text-style-title-3-size: var(--font-size-6x);
                --text-style-title-3-spacing: var(--font-spacing-normal);
                --text-style-title-3-weight: var(--font-weight-median);
                --text-style-title-3-height: var(--font-height-tight);
                --text-style-title-4-family: var(--font-family-regular);
                --text-style-title-4-size: var(--font-size-5x);
                --text-style-title-4-spacing: var(--font-spacing-normal);
                --text-style-title-4-weight: var(--font-weight-median);
                --text-style-title-4-height: var(--font-height-tight);
                --text-style-subheading-family: var(--font-family-regular);
                --text-style-subheading-size: var(--font-size-4x);
                --text-style-subheading-spacing: var(--font-spacing-normal);
                --text-style-subheading-weight: var(--font-weight-median);
                --text-style-subheading-height: var(--font-height-normal);
                --text-style-body-large-family: var(--font-family-regular);
                --text-style-body-large-size: var(--font-size-3x);
                --text-style-body-large-spacing: var(--font-spacing-normal);
                --text-style-body-large-weight: var(--font-weight-neutral);
                --text-style-body-large-height: var(--font-height-normal);
                --text-style-body-large-strong-weight: var(--font-weight-bulky);
                --text-style-body-small-family: var(--font-family-regular);
                --text-style-body-small-size: var(--font-size-2x);
                --text-style-body-small-spacing: var(--font-spacing-normal);
                --text-style-body-small-weight: var(--font-weight-neutral);
                --text-style-body-small-height: var(--font-height-normal);
                --text-style-body-small-strong-weight: var(--font-weight-bulky);
                --text-style-label-large-family: var(--font-family-regular);
                --text-style-label-large-size: var(--font-size-3x);
                --text-style-label-large-spacing: var(--font-spacing-normal);
                --text-style-label-large-weight: var(--font-weight-median);
                --text-style-label-large-height: var(--font-height-normal);
                --text-style-label-small-family: var(--font-family-regular);
                --text-style-label-small-size: var(--font-size-2x);
                --text-style-label-small-spacing: var(--font-spacing-loose);
                --text-style-label-small-weight: var(--font-weight-median);
                --text-style-label-small-height: var(--font-height-normal);
                --text-style-micro-family: var(--font-family-regular);
                --text-style-micro-size: var(--font-size-1x);
                --text-style-micro-spacing: var(--font-spacing-loose);
                --text-style-micro-weight: var(--font-weight-neutral);
                --text-style-micro-height: var(--font-height-tight);
            }

            .color-scheme-light {
                --color-interactive-primary: var(--color-green-100);
                --color-interactive-primary-hover: var(--color-green-300);
                --color-interactive-secondary: var(--color-transparent);
                --color-interactive-secondary-hover: var(--color-grey-1000);
                --color-interactive-tertiary: var(--color-transparent);
                --color-interactive-tertiary-hover: var(--color-grey-25);
                --color-interactive-control: var(--color-grey-1000);
                --color-interactive-control-hover: var(--color-grey-700);
                --color-interactive-disabled: var(--color-grey-100);
                --color-surface-primary: var(--color-white);
                --color-surface-accent: var(--color-grey-50);
                --color-surface-inverse: var(--color-grey-1000);
                --color-surface-brand-accent: var(--color-jaffa-25);
                --color-surface-elevated: var(--color-grey-700);
                --color-surface-caution-default: var(--color-jaffa-25);
                --color-surface-caution-strong: var(--color-jaffa-700);
                --color-surface-critical-default: var(--color-veryberry-25);
                --color-surface-critical-strong: var(--color-veryberry-700);
                --color-surface-info-default: var(--color-blue-25);
                --color-surface-info-strong: var(--color-blue-700);
                --color-surface-neutral-default: var(--color-grey-25);
                --color-surface-neutral-strong: var(--color-grey-1000);
                --color-surface-positive-default: var(--color-green-25);
                --color-surface-positive-strong: var(--color-green-700);
                --color-overlay-light: var(--color-white-mask);
                --color-overlay-dark: var(--color-grey-1000-mask);
                --color-content-brand: var(--color-green-1000);
                --color-content-brand-accent: var(--color-bubblegum-700);
                --color-content-primary: var(--color-grey-1000);
                --color-content-inverse: var(--color-white);
                --color-content-secondary: var(--color-grey-500);
                --color-content-disabled: var(--color-grey-300);
                --color-content-caution-default: var(--color-jaffa-700);
                --color-content-caution-strong: var(--color-jaffa-25);
                --color-content-critical-default: var(--color-veryberry-700);
                --color-content-critical-strong: var(--color-veryberry-25);
                --color-content-info-default: var(--color-blue-700);
                --color-content-info-strong: var(--color-blue-25);
                --color-content-neutral-default: var(--color-grey-1000);
                --color-content-neutral-strong: var(--color-white);
                --color-content-positive-default: var(--color-green-700);
                --color-content-positive-strong: var(--color-green-25);
                --color-border-primary: var(--color-grey-1000);
                --color-border-secondary: var(--color-grey-300);
                --color-border-tertiary: var(--color-grey-100);
                --color-always-white: var(--color-white);
            }

            .color-scheme-dark {
                --color-interactive-primary: var(--color-green-100);
                --color-interactive-primary-hover: var(--color-green-300);
                --color-interactive-secondary: var(--color-transparent);
                --color-interactive-secondary-hover: var(--color-white);
                --color-interactive-tertiary: var(--color-transparent);
                --color-interactive-tertiary-hover: var(--color-grey-700);
                --color-interactive-control: var(--color-white);
                --color-interactive-control-hover: var(--color-grey-100);
                --color-interactive-disabled: var(--color-grey-700);
                --color-surface-primary: var(--color-grey-1000);
                --color-surface-accent: var(--color-grey-700);
                --color-surface-inverse: var(--color-white);
                --color-surface-brand-accent: var(--color-grey-700);
                --color-surface-elevated: var(--color-grey-700);
                --color-surface-caution-default: var(--color-jaffa-1000);
                --color-surface-caution-strong: var(--color-jaffa-500);
                --color-surface-critical-default: var(--color-veryberry-1000);
                --color-surface-critical-strong: var(--color-veryberry-500);
                --color-surface-info-default: var(--color-blue-1000);
                --color-surface-info-strong: var(--color-blue-500);
                --color-surface-neutral-default: var(--color-grey-700);
                --color-surface-neutral-strong: var(--color-white);
                --color-surface-positive-default: var(--color-green-1000);
                --color-surface-positive-strong: var(--color-green-500);
                --color-overlay-light: var(--color-white-mask);
                --color-overlay-dark: var(--color-grey-1000-mask);
                --color-content-brand: var(--color-green-1000);
                --color-content-brand-accent: var(--color-bubblegum-100);
                --color-content-primary: var(--color-white);
                --color-content-inverse: var(--color-grey-1000);
                --color-content-secondary: var(--color-grey-100);
                --color-content-disabled: var(--color-grey-500);
                --color-content-caution-default: var(--color-jaffa-500);
                --color-content-caution-strong: var(--color-jaffa-1000);
                --color-content-critical-default: var(--color-veryberry-500);
                --color-content-critical-strong: var(--color-veryberry-1000);
                --color-content-info-default: var(--color-blue-500);
                --color-content-info-strong: var(--color-blue-1000);
                --color-content-neutral-default: var(--color-white);
                --color-content-neutral-strong: var(--color-grey-1000);
                --color-content-positive-default: var(--color-green-500);
                --color-content-positive-strong: var(--color-green-1000);
                --color-border-primary: var(--color-white);
                --color-border-secondary: var(--color-grey-500);
                --color-border-tertiary: var(--color-grey-700);
                --color-always-white: var(--color-white);
            }
            /*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL2FwcC9qYXZhc2NyaXB0L2NvbXBvbmVudHMvYnJhbmRfbmV1ZV90b2tlbnMvYmFzZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUVBO0VBQ0UsMEJBQUE7RUFDQSwyQ0FBQTtFQUNBLHlCQUFBO0VBQ0EseUJBQUE7RUFDQSx5QkFBQTtFQUNBLHlCQUFBO0VBQ0Esd0JBQUE7RUFDQSx3QkFBQTtFQUNBLHNCQUFBO0VBQ0EsMENBQUE7RUFFQSwyQkFBQTtFQUNBLDBCQUFBO0VBQ0EsMEJBQUE7RUFDQSwwQkFBQTtFQUNBLDBCQUFBO0VBQ0EseUJBQUE7RUFFQSwwQkFBQTtFQUNBLHlCQUFBO0VBQ0EseUJBQUE7RUFDQSx3QkFBQTtFQUVBLCtCQUFBO0VBQ0EsOEJBQUE7RUFDQSw4QkFBQTtFQUNBLDZCQUFBO0VBRUEsOEJBQUE7RUFDQSw4QkFBQTtFQUNBLDZCQUFBO0VBRUEsMkJBQUE7RUFDQSwwQkFBQTtFQUNBLDBCQUFBO0VBQ0EseUJBQUE7RUFFQSwwQkFBQTtFQUNBLHlCQUFBO0VBQ0EseUJBQUE7RUFDQSx5QkFBQTtFQUNBLHdCQUFBO0VBRUEsZ0NBQUE7RUFFQSx5QkFBQTtFQUNBLCtCQUFBO0VBQ0EsNEJBQUE7RUFFQSxtQkFBQTtFQUNBLGtCQUFBO0VBQ0Esa0JBQUE7RUFDQSxrQkFBQTtFQUNBLGtCQUFBO0VBQ0Esa0JBQUE7RUFDQSxpQkFBQTtFQUNBLGlCQUFBO0VBQ0EsbUJBQUE7RUFFQSxzQkFBQTtFQUNBLHNCQUFBO0VBQ0EsdUJBQUE7RUFFQSx1QkFBQTtFQUNBLHVCQUFBO0VBQ0EsNkJBQUE7RUFDQSx3QkFBQTtFQUVBLGdEQUFBO0VBQ0EscUNBQUE7RUFFQSxpQkFBQTtFQUNBLHVCQUFBO0VBRUEsaUNBQUE7RUFDQSxtQ0FBQTtFQUNBLGtDQUFBO0VBRUEsb0RBQUE7RUFDQSx3REFBQTtFQUNBLCtEQUFBO0VBQ0EseURBQUE7RUFFQTtrRUFBQTtFQUVBO3NEQUFBO0VBRUEsaURBQUE7RUFFQSxxQkFBQTtFQUNBLHNCQUFBO0VBQ0Esb0JBQUE7RUFDQSx1QkFBQTtFQUNBLHdCQUFBO0VBQ0Esc0JBQUE7RUFDQSx3QkFBQTtFQUNBLG9CQUFBO0VBQ0Esd0JBQUE7RUFDQSx1QkFBQTtFQUVBLHdCQUFBO0VBQ0EseUJBQUE7RUFDQSwwQkFBQTtFQUVBLDZCQUFBO0VBQ0Esd0JBQUE7RUFDQSw0QkFBQTtFQUVBLHNCQUFBO0VBQ0EseUJBQUE7RUFFQSxvQkFBQTtFQUNBLG9CQUFBO0VBQ0Esb0JBQUE7RUFDQSxvQkFBQTtFQUNBLG9CQUFBO0VBQ0EsNERBQUE7RUFFQSwyQkFBQTtFQUVBLDBCQUFBO0VBRUEsaUVBQUE7RUFFQSwyQkFBQTtFQUNBLDRCQUFBO0VBQ0EsZ0RBQUE7RUFDQSw2Q0FBQTtFQUNBLDhDQUFBO0VBQ0EsK0NBQUE7RUFDQSwrQ0FBQTtFQUNBLGlEQUFBO0VBRUEsb0RBQUE7RUFDQSxxREFBQTtFQUNBLGtEQUFBO0VBQ0EsMERBQUE7RUFDQSx5REFBQTtFQUNBLGlEQUFBO0VBQ0EsMERBQUE7RUFDQSx5REFBQTtFQUNBLGtEQUFBO0VBQ0EsMkRBQUE7RUFDQSwwREFBQTtFQUVBLDZEQUFBO0VBRUEsMkRBQUE7RUFDQSxxREFBQTtFQUNBLCtEQUFBO0VBQ0EsNERBQUE7RUFDQSw0REFBQTtFQUVBLDJEQUFBO0VBQ0EscURBQUE7RUFDQSwrREFBQTtFQUNBLDREQUFBO0VBQ0EsNERBQUE7RUFFQSx1REFBQTtFQUNBLDhDQUFBO0VBQ0Esd0RBQUE7RUFDQSxxREFBQTtFQUNBLHFEQUFBO0VBRUEsdURBQUE7RUFDQSw4Q0FBQTtFQUNBLHdEQUFBO0VBQ0Esc0RBQUE7RUFDQSxxREFBQTtFQUVBLHVEQUFBO0VBQ0EsOENBQUE7RUFDQSx3REFBQTtFQUNBLHNEQUFBO0VBQ0EscURBQUE7RUFFQSx1REFBQTtFQUNBLDhDQUFBO0VBQ0Esd0RBQUE7RUFDQSxzREFBQTtFQUNBLHFEQUFBO0VBRUEsMERBQUE7RUFDQSxpREFBQTtFQUNBLDJEQUFBO0VBQ0EseURBQUE7RUFDQSx5REFBQTtFQUVBLDBEQUFBO0VBQ0EsaURBQUE7RUFDQSwyREFBQTtFQUNBLDBEQUFBO0VBQ0EseURBQUE7RUFDQSwrREFBQTtFQUVBLDBEQUFBO0VBQ0EsaURBQUE7RUFDQSwyREFBQTtFQUNBLDBEQUFBO0VBQ0EseURBQUE7RUFDQSwrREFBQTtFQUVBLDJEQUFBO0VBQ0Esa0RBQUE7RUFDQSw0REFBQTtFQUNBLDBEQUFBO0VBQ0EsMERBQUE7RUFFQSwyREFBQTtFQUNBLGtEQUFBO0VBQ0EsMkRBQUE7RUFDQSwwREFBQTtFQUNBLDBEQUFBO0VBRUEscURBQUE7RUFDQSw0Q0FBQTtFQUNBLHFEQUFBO0VBQ0EscURBQUE7RUFDQSxtREFBQTtBQXhDRjs7QUEyQ0E7RUFDRSxtREFBQTtFQUNBLHlEQUFBO0VBQ0EsdURBQUE7RUFDQSwyREFBQTtFQUNBLHNEQUFBO0VBQ0Esd0RBQUE7RUFDQSxtREFBQTtFQUNBLHdEQUFBO0VBQ0EsbURBQUE7RUFFQSwyQ0FBQTtFQUNBLDRDQUFBO0VBQ0EsK0NBQUE7RUFDQSxtREFBQTtFQUNBLCtDQUFBO0VBQ0Esc0RBQUE7RUFDQSxzREFBQTtFQUNBLDJEQUFBO0VBQ0EsMkRBQUE7RUFDQSxrREFBQTtFQUNBLGtEQUFBO0VBQ0EscURBQUE7RUFDQSxzREFBQTtFQUNBLHVEQUFBO0VBQ0EsdURBQUE7RUFFQSw4Q0FBQTtFQUNBLGlEQUFBO0VBRUEsOENBQUE7RUFDQSx3REFBQTtFQUNBLCtDQUFBO0VBQ0EsMkNBQUE7RUFDQSxnREFBQTtFQUNBLCtDQUFBO0VBQ0EsdURBQUE7RUFDQSxxREFBQTtFQUNBLDREQUFBO0VBQ0EsMERBQUE7RUFDQSxtREFBQTtFQUNBLGlEQUFBO0VBQ0EsdURBQUE7RUFDQSxrREFBQTtFQUNBLHdEQUFBO0VBQ0Esc0RBQUE7RUFFQSw4Q0FBQTtFQUNBLCtDQUFBO0VBQ0EsOENBQUE7RUFFQSx3Q0FBQTtBQTdDRjs7QUFnREE7RUFDRSxtREFBQTtFQUNBLHlEQUFBO0VBQ0EsdURBQUE7RUFDQSx1REFBQTtFQUNBLHNEQUFBO0VBQ0EseURBQUE7RUFDQSwrQ0FBQTtFQUNBLHdEQUFBO0VBQ0EsbURBQUE7RUFFQSwrQ0FBQTtFQUNBLDZDQUFBO0VBQ0EsMkNBQUE7RUFDQSxtREFBQTtFQUNBLCtDQUFBO0VBQ0Esd0RBQUE7RUFDQSxzREFBQTtFQUNBLDZEQUFBO0VBQ0EsMkRBQUE7RUFDQSxvREFBQTtFQUNBLGtEQUFBO0VBQ0Esc0RBQUE7RUFDQSxrREFBQTtFQUNBLHlEQUFBO0VBQ0EsdURBQUE7RUFFQSw4Q0FBQTtFQUNBLGlEQUFBO0VBRUEsOENBQUE7RUFDQSx3REFBQTtFQUNBLDJDQUFBO0VBQ0EsK0NBQUE7RUFDQSxnREFBQTtFQUNBLCtDQUFBO0VBQ0EsdURBQUE7RUFDQSx1REFBQTtFQUNBLDREQUFBO0VBQ0EsNERBQUE7RUFDQSxtREFBQTtFQUNBLG1EQUFBO0VBQ0EsbURBQUE7RUFDQSxzREFBQTtFQUNBLHdEQUFBO0VBQ0Esd0RBQUE7RUFFQSwwQ0FBQTtFQUNBLCtDQUFBO0VBQ0EsOENBQUE7RUFFQSx3Q0FBQTtBQWxERiIsInNvdXJjZXNDb250ZW50IjpbIi8vIENvcGllZCBmcm9tIGh0dHBzOi8vZ2l0aHViLmNvbS9lbnZhdG8vZW52YXRvLWRlc2lnbi10b2tlbnMvYmxvYi9tYWluL3Rva2Vucy5jc3NcblxuOnJvb3Qge1xuICAtLWNvbG9yLWdyZXktMTAwMDogIzE5MTkxOTtcbiAgLS1jb2xvci1ncmV5LTEwMDAtbWFzazogcmdiKDI1IDI1IDI1IC8gMC43KTtcbiAgLS1jb2xvci1ncmV5LTcwMDogIzM4MzgzODtcbiAgLS1jb2xvci1ncmV5LTUwMDogIzcwNzA3MDtcbiAgLS1jb2xvci1ncmV5LTMwMDogIzk0OTQ5NDtcbiAgLS1jb2xvci1ncmV5LTEwMDogI2NjY2NjYztcbiAgLS1jb2xvci1ncmV5LTUwOiAjZWNlY2VlO1xuICAtLWNvbG9yLWdyZXktMjU6ICNmOWY5ZmI7XG4gIC0tY29sb3Itd2hpdGU6ICNmZmZmZmY7XG4gIC0tY29sb3Itd2hpdGUtbWFzazogcmdiKDI1NSAyNTUgMjU1IC8gMC43KTtcblxuICAtLWNvbG9yLWdyZWVuLTEwMDA6ICMxYTQyMDA7XG4gIC0tY29sb3ItZ3JlZW4tNzAwOiAjMmU3NDAwO1xuICAtLWNvbG9yLWdyZWVuLTUwMDogIzUxYTMxZDtcbiAgLS1jb2xvci1ncmVlbi0zMDA6ICM2Y2M4MzI7XG4gIC0tY29sb3ItZ3JlZW4tMTAwOiAjOWNlZTY5O1xuICAtLWNvbG9yLWdyZWVuLTI1OiAjZWFmZmRjO1xuXG4gIC0tY29sb3ItYmx1ZS0xMDAwOiAjMTYzNTdiO1xuICAtLWNvbG9yLWJsdWUtNzAwOiAjNGY1Y2U4O1xuICAtLWNvbG9yLWJsdWUtNTAwOiAjNzU4NWZmO1xuICAtLWNvbG9yLWJsdWUtMjU6ICNmMGYxZmY7XG5cbiAgLS1jb2xvci12ZXJ5YmVycnktMTAwMDogIzc3MDEyZDtcbiAgLS1jb2xvci12ZXJ5YmVycnktNzAwOiAjYjkwMDRiO1xuICAtLWNvbG9yLXZlcnliZXJyeS01MDA6ICNmNjUyODY7XG4gIC0tY29sb3ItdmVyeWJlcnJ5LTI1OiAjZmZlY2YyO1xuXG4gIC0tY29sb3ItYnViYmxlZ3VtLTcwMDogI2IwMzdhNjtcbiAgLS1jb2xvci1idWJibGVndW0tMTAwOiAjZTZhZmUxO1xuICAtLWNvbG9yLWJ1YmJsZWd1bS0yNTogI2ZlZWRmYztcblxuICAtLWNvbG9yLWphZmZhLTEwMDA6ICM2OTI0MDA7XG4gIC0tY29sb3ItamFmZmEtNzAwOiAjYzI0MTAwO1xuICAtLWNvbG9yLWphZmZhLTUwMDogI2ZmNmUyODtcbiAgLS1jb2xvci1qYWZmYS0yNTogI2ZmZjVlZDtcblxuICAtLWNvbG9yLXlvbGstMTAwMDogIzQ1MmQwZDtcbiAgLS1jb2xvci15b2xrLTcwMDogIzllNWYwMDtcbiAgLS1jb2xvci15b2xrLTUwMDogI2MyODgwMDtcbiAgLS1jb2xvci15b2xrLTMwMDogI2ZmYzgwMDtcbiAgLS1jb2xvci15b2xrLTI1OiAjZmVmYWVhO1xuXG4gIC0tY29sb3ItdHJhbnNwYXJlbnQ6IHRyYW5zcGFyZW50O1xuXG4gIC0tYnJlYWtwb2ludC13aWRlOiAxMDI0cHg7XG4gIC0tYnJlYWtwb2ludC1leHRyYS13aWRlOiAxNDQwcHg7XG4gIC0tYnJlYWtwb2ludC0yay13aWRlOiAyNTYwcHg7XG5cbiAgLS1zcGFjaW5nLTh4OiAxMjhweDtcbiAgLS1zcGFjaW5nLTd4OiA2NHB4O1xuICAtLXNwYWNpbmctNng6IDQwcHg7XG4gIC0tc3BhY2luZy01eDogMzJweDtcbiAgLS1zcGFjaW5nLTR4OiAyNHB4O1xuICAtLXNwYWNpbmctM3g6IDE2cHg7XG4gIC0tc3BhY2luZy0yeDogOHB4O1xuICAtLXNwYWNpbmctMXg6IDRweDtcbiAgLS1zcGFjaW5nLW5vbmU6IDBweDtcblxuICAtLWNodW5raW5lc3Mtbm9uZTogMHB4O1xuICAtLWNodW5raW5lc3MtdGhpbjogMXB4O1xuICAtLWNodW5raW5lc3MtdGhpY2s6IDJweDtcblxuICAtLXJvdW5kbmVzcy1zcXVhcmU6IDBweDtcbiAgLS1yb3VuZG5lc3Mtc3VidGxlOiA0cHg7XG4gIC0tcm91bmRuZXNzLWV4dHJhLXJvdW5kOiAxNnB4O1xuICAtLXJvdW5kbmVzcy1jaXJjbGU6IDQ4cHg7XG5cbiAgLS1zaGFkb3ctNTAwOiAwcHggMnB4IDEycHggMHB4IHJnYmEoMCAwIDAgLyAxNSUpO1xuICAtLWVsZXZhdGlvbi1tZWRpdW06IHZhcigtLXNoYWRvdy01MDApO1xuXG4gIC8qKiBAZGVwcmVjYXRlZCAqL1xuICAtLXRyYW5zaXRpb24tYmFzZTogMC4ycztcblxuICAtLXRyYW5zaXRpb24tZHVyYXRpb24tbG9uZzogNTAwbXM7XG4gIC0tdHJhbnNpdGlvbi1kdXJhdGlvbi1tZWRpdW06IDMwMG1zO1xuICAtLXRyYW5zaXRpb24tZHVyYXRpb24tc2hvcnQ6IDE1MG1zO1xuXG4gIC0tdHJhbnNpdGlvbi1lYXNpbmctbGluZWFyOiBjdWJpYy1iZXppZXIoMCwgMCwgMSwgMSk7XG4gIC0tdHJhbnNpdGlvbi1lYXNpbmctZWFzZS1pbjogY3ViaWMtYmV6aWVyKDAuNDIsIDAsIDEsIDEpO1xuICAtLXRyYW5zaXRpb24tZWFzaW5nLWVhc2UtaW4tb3V0OiBjdWJpYy1iZXppZXIoMC40MiwgMCwgMC41OCwgMSk7XG4gIC0tdHJhbnNpdGlvbi1lYXNpbmctZWFzZS1vdXQ6IGN1YmljLWJlemllcigwLCAwLCAwLjU4LCAxKTtcblxuICAtLWZvbnQtZmFtaWx5LXdpZGU6IFwiUG9seVNhbnNXaWRlXCIsIFwiUG9seVNhbnNcIiwgXCJJbnRlclwiLCAtYXBwbGUtc3lzdGVtLCBcIkJsaW5rTWFjU3lzdGVtRm9udFwiLFxuICAgIFwiU2Vnb2UgVUlcIiwgXCJGaXJhIFNhbnNcIiwgXCJIZWx2ZXRpY2EgTmV1ZVwiLCBcIkFyaWFsXCIsIHNhbnMtc2VyaWY7XG4gIC0tZm9udC1mYW1pbHktcmVndWxhcjogXCJQb2x5U2Fuc1wiLCBcIkludGVyXCIsIC1hcHBsZS1zeXN0ZW0sIFwiQmxpbmtNYWNTeXN0ZW1Gb250XCIsIFwiU2Vnb2UgVUlcIixcbiAgICBcIkZpcmEgU2Fuc1wiLCBcIkhlbHZldGljYSBOZXVlXCIsIFwiQXJpYWxcIiwgc2Fucy1zZXJpZjtcbiAgLS1mb250LWZhbWlseS1tb25vc3BhY2U6IFwiQ291cmllciBOZXdcIiwgbW9ub3NwYWNlO1xuXG4gIC0tZm9udC1zaXplLTEweDogNnJlbTtcbiAgLS1mb250LXNpemUtOXg6IDQuNXJlbTtcbiAgLS1mb250LXNpemUtOHg6IDNyZW07XG4gIC0tZm9udC1zaXplLTd4OiAyLjI1cmVtO1xuICAtLWZvbnQtc2l6ZS02eDogMS44NzVyZW07XG4gIC0tZm9udC1zaXplLTV4OiAxLjVyZW07XG4gIC0tZm9udC1zaXplLTR4OiAxLjEyNXJlbTtcbiAgLS1mb250LXNpemUtM3g6IDFyZW07XG4gIC0tZm9udC1zaXplLTJ4OiAwLjg3NXJlbTtcbiAgLS1mb250LXNpemUtMXg6IDAuNzVyZW07XG5cbiAgLS1mb250LXdlaWdodC1idWxreTogNzAwO1xuICAtLWZvbnQtd2VpZ2h0LW1lZGlhbjogNjAwO1xuICAtLWZvbnQtd2VpZ2h0LW5ldXRyYWw6IDQwMDtcblxuICAtLWZvbnQtc3BhY2luZy10aWdodDogLTAuMDJlbTtcbiAgLS1mb250LXNwYWNpbmctbm9ybWFsOiAwO1xuICAtLWZvbnQtc3BhY2luZy1sb29zZTogMC4wMmVtO1xuXG4gIC0tZm9udC1oZWlnaHQtdGlnaHQ6IDE7XG4gIC0tZm9udC1oZWlnaHQtbm9ybWFsOiAxLjU7XG5cbiAgLS1pY29uLXNpemUtNXg6IDQ4cHg7XG4gIC0taWNvbi1zaXplLTR4OiA0MHB4O1xuICAtLWljb24tc2l6ZS0zeDogMzJweDtcbiAgLS1pY29uLXNpemUtMng6IDI0cHg7XG4gIC0taWNvbi1zaXplLTF4OiAxNnB4O1xuICAtLWljb24tc2l6ZS10ZXh0LXJlc3BvbnNpdmU6IGNhbGModmFyKC0tZm9udC1zaXplLTN4KSAqIDEuNSk7XG5cbiAgLS1sYXllci1kZXB0aC1jZWlsaW5nOiA5OTk5O1xuXG4gIC0tbWluaW11bS10b3VjaC1hcmVhOiA0MHB4O1xuXG4gIC8qIGNvbXBvbmVudCB3aXJpbmc/IC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLSAqL1xuXG4gIC0tYnV0dG9uLWhlaWdodC1sYXJnZTogNDhweDtcbiAgLS1idXR0b24taGVpZ2h0LW1lZGl1bTogNDBweDtcbiAgLS1idXR0b24tZm9udC1mYW1pbHk6IHZhcigtLWZvbnQtZmFtaWx5LXJlZ3VsYXIpO1xuICAtLWJ1dHRvbi1mb250LXNpemUtbGFyZ2U6IHZhcigtLWZvbnQtc2l6ZS0zeCk7XG4gIC0tYnV0dG9uLWZvbnQtc2l6ZS1tZWRpdW06IHZhcigtLWZvbnQtc2l6ZS0yeCk7XG4gIC0tYnV0dG9uLWZvbnQtd2VpZ2h0OiB2YXIoLS1mb250LXdlaWdodC1tZWRpYW4pO1xuICAtLWJ1dHRvbi1mb250LWhlaWdodDogdmFyKC0tZm9udC1oZWlnaHQtbm9ybWFsKTtcbiAgLS1idXR0b24tZm9udC1zcGFjaW5nOiB2YXIoLS1mb250LXNwYWNpbmctbm9ybWFsKTtcblxuICAtLXRleHQtc3R5bGUtY2hpcC1mYW1pbHk6IHZhcigtLWZvbnQtZmFtaWx5LXJlZ3VsYXIpO1xuICAtLXRleHQtc3R5bGUtY2hpcC1zcGFjaW5nOiB2YXIoLS1mb250LXNwYWNpbmctbm9ybWFsKTtcbiAgLS10ZXh0LXN0eWxlLWNoaXAteGxhcmdlLXNpemU6IHZhcigtLWZvbnQtc2l6ZS01eCk7XG4gIC0tdGV4dC1zdHlsZS1jaGlwLXhsYXJnZS13ZWlnaHQ6IHZhcigtLWZvbnQtd2VpZ2h0LW1lZGlhbik7XG4gIC0tdGV4dC1zdHlsZS1jaGlwLXhsYXJnZS1oZWlnaHQ6IHZhcigtLWZvbnQtaGVpZ2h0LXRpZ2h0KTtcbiAgLS10ZXh0LXN0eWxlLWNoaXAtbGFyZ2Utc2l6ZTogdmFyKC0tZm9udC1zaXplLTN4KTtcbiAgLS10ZXh0LXN0eWxlLWNoaXAtbGFyZ2Utd2VpZ2h0OiB2YXIoLS1mb250LXdlaWdodC1uZXV0cmFsKTtcbiAgLS10ZXh0LXN0eWxlLWNoaXAtbGFyZ2UtaGVpZ2h0OiB2YXIoLS1mb250LWhlaWdodC1ub3JtYWwpO1xuICAtLXRleHQtc3R5bGUtY2hpcC1tZWRpdW0tc2l6ZTogdmFyKC0tZm9udC1zaXplLTJ4KTtcbiAgLS10ZXh0LXN0eWxlLWNoaXAtbWVkaXVtLXdlaWdodDogdmFyKC0tZm9udC13ZWlnaHQtbmV1dHJhbCk7XG4gIC0tdGV4dC1zdHlsZS1jaGlwLW1lZGl1bS1oZWlnaHQ6IHZhcigtLWZvbnQtaGVpZ2h0LW5vcm1hbCk7XG5cbiAgLyogdGhlbWU/IC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0gKi9cblxuICAtLXRleHQtc3R5bGUtY2FtcGFpZ24tbGFyZ2UtZmFtaWx5OiB2YXIoLS1mb250LWZhbWlseS13aWRlKTtcbiAgLS10ZXh0LXN0eWxlLWNhbXBhaWduLWxhcmdlLXNpemU6IHZhcigtLWZvbnQtc2l6ZS05eCk7XG4gIC0tdGV4dC1zdHlsZS1jYW1wYWlnbi1sYXJnZS1zcGFjaW5nOiB2YXIoLS1mb250LXNwYWNpbmctbm9ybWFsKTtcbiAgLS10ZXh0LXN0eWxlLWNhbXBhaWduLWxhcmdlLXdlaWdodDogdmFyKC0tZm9udC13ZWlnaHQtYnVsa3kpO1xuICAtLXRleHQtc3R5bGUtY2FtcGFpZ24tbGFyZ2UtaGVpZ2h0OiB2YXIoLS1mb250LWhlaWdodC10aWdodCk7XG5cbiAgLS10ZXh0LXN0eWxlLWNhbXBhaWduLXNtYWxsLWZhbWlseTogdmFyKC0tZm9udC1mYW1pbHktd2lkZSk7XG4gIC0tdGV4dC1zdHlsZS1jYW1wYWlnbi1zbWFsbC1zaXplOiB2YXIoLS1mb250LXNpemUtN3gpO1xuICAtLXRleHQtc3R5bGUtY2FtcGFpZ24tc21hbGwtc3BhY2luZzogdmFyKC0tZm9udC1zcGFjaW5nLW5vcm1hbCk7XG4gIC0tdGV4dC1zdHlsZS1jYW1wYWlnbi1zbWFsbC13ZWlnaHQ6IHZhcigtLWZvbnQtd2VpZ2h0LWJ1bGt5KTtcbiAgLS10ZXh0LXN0eWxlLWNhbXBhaWduLXNtYWxsLWhlaWdodDogdmFyKC0tZm9udC1oZWlnaHQtdGlnaHQpO1xuXG4gIC0tdGV4dC1zdHlsZS10aXRsZS0xLWZhbWlseTogdmFyKC0tZm9udC1mYW1pbHktcmVndWxhcik7XG4gIC0tdGV4dC1zdHlsZS10aXRsZS0xLXNpemU6IHZhcigtLWZvbnQtc2l6ZS04eCk7XG4gIC0tdGV4dC1zdHlsZS10aXRsZS0xLXNwYWNpbmc6IHZhcigtLWZvbnQtc3BhY2luZy1ub3JtYWwpO1xuICAtLXRleHQtc3R5bGUtdGl0bGUtMS13ZWlnaHQ6IHZhcigtLWZvbnQtd2VpZ2h0LWJ1bGt5KTtcbiAgLS10ZXh0LXN0eWxlLXRpdGxlLTEtaGVpZ2h0OiB2YXIoLS1mb250LWhlaWdodC10aWdodCk7XG5cbiAgLS10ZXh0LXN0eWxlLXRpdGxlLTItZmFtaWx5OiB2YXIoLS1mb250LWZhbWlseS1yZWd1bGFyKTtcbiAgLS10ZXh0LXN0eWxlLXRpdGxlLTItc2l6ZTogdmFyKC0tZm9udC1zaXplLTd4KTtcbiAgLS10ZXh0LXN0eWxlLXRpdGxlLTItc3BhY2luZzogdmFyKC0tZm9udC1zcGFjaW5nLW5vcm1hbCk7XG4gIC0tdGV4dC1zdHlsZS10aXRsZS0yLXdlaWdodDogdmFyKC0tZm9udC13ZWlnaHQtbWVkaWFuKTtcbiAgLS10ZXh0LXN0eWxlLXRpdGxlLTItaGVpZ2h0OiB2YXIoLS1mb250LWhlaWdodC10aWdodCk7XG5cbiAgLS10ZXh0LXN0eWxlLXRpdGxlLTMtZmFtaWx5OiB2YXIoLS1mb250LWZhbWlseS1yZWd1bGFyKTtcbiAgLS10ZXh0LXN0eWxlLXRpdGxlLTMtc2l6ZTogdmFyKC0tZm9udC1zaXplLTZ4KTtcbiAgLS10ZXh0LXN0eWxlLXRpdGxlLTMtc3BhY2luZzogdmFyKC0tZm9udC1zcGFjaW5nLW5vcm1hbCk7XG4gIC0tdGV4dC1zdHlsZS10aXRsZS0zLXdlaWdodDogdmFyKC0tZm9udC13ZWlnaHQtbWVkaWFuKTtcbiAgLS10ZXh0LXN0eWxlLXRpdGxlLTMtaGVpZ2h0OiB2YXIoLS1mb250LWhlaWdodC10aWdodCk7XG5cbiAgLS10ZXh0LXN0eWxlLXRpdGxlLTQtZmFtaWx5OiB2YXIoLS1mb250LWZhbWlseS1yZWd1bGFyKTtcbiAgLS10ZXh0LXN0eWxlLXRpdGxlLTQtc2l6ZTogdmFyKC0tZm9udC1zaXplLTV4KTtcbiAgLS10ZXh0LXN0eWxlLXRpdGxlLTQtc3BhY2luZzogdmFyKC0tZm9udC1zcGFjaW5nLW5vcm1hbCk7XG4gIC0tdGV4dC1zdHlsZS10aXRsZS00LXdlaWdodDogdmFyKC0tZm9udC13ZWlnaHQtbWVkaWFuKTtcbiAgLS10ZXh0LXN0eWxlLXRpdGxlLTQtaGVpZ2h0OiB2YXIoLS1mb250LWhlaWdodC10aWdodCk7XG5cbiAgLS10ZXh0LXN0eWxlLXN1YmhlYWRpbmctZmFtaWx5OiB2YXIoLS1mb250LWZhbWlseS1yZWd1bGFyKTtcbiAgLS10ZXh0LXN0eWxlLXN1YmhlYWRpbmctc2l6ZTogdmFyKC0tZm9udC1zaXplLTR4KTtcbiAgLS10ZXh0LXN0eWxlLXN1YmhlYWRpbmctc3BhY2luZzogdmFyKC0tZm9udC1zcGFjaW5nLW5vcm1hbCk7XG4gIC0tdGV4dC1zdHlsZS1zdWJoZWFkaW5nLXdlaWdodDogdmFyKC0tZm9udC13ZWlnaHQtbWVkaWFuKTtcbiAgLS10ZXh0LXN0eWxlLXN1YmhlYWRpbmctaGVpZ2h0OiB2YXIoLS1mb250LWhlaWdodC1ub3JtYWwpO1xuXG4gIC0tdGV4dC1zdHlsZS1ib2R5LWxhcmdlLWZhbWlseTogdmFyKC0tZm9udC1mYW1pbHktcmVndWxhcik7XG4gIC0tdGV4dC1zdHlsZS1ib2R5LWxhcmdlLXNpemU6IHZhcigtLWZvbnQtc2l6ZS0zeCk7XG4gIC0tdGV4dC1zdHlsZS1ib2R5LWxhcmdlLXNwYWNpbmc6IHZhcigtLWZvbnQtc3BhY2luZy1ub3JtYWwpO1xuICAtLXRleHQtc3R5bGUtYm9keS1sYXJnZS13ZWlnaHQ6IHZhcigtLWZvbnQtd2VpZ2h0LW5ldXRyYWwpO1xuICAtLXRleHQtc3R5bGUtYm9keS1sYXJnZS1oZWlnaHQ6IHZhcigtLWZvbnQtaGVpZ2h0LW5vcm1hbCk7XG4gIC0tdGV4dC1zdHlsZS1ib2R5LWxhcmdlLXN0cm9uZy13ZWlnaHQ6IHZhcigtLWZvbnQtd2VpZ2h0LWJ1bGt5KTtcblxuICAtLXRleHQtc3R5bGUtYm9keS1zbWFsbC1mYW1pbHk6IHZhcigtLWZvbnQtZmFtaWx5LXJlZ3VsYXIpO1xuICAtLXRleHQtc3R5bGUtYm9keS1zbWFsbC1zaXplOiB2YXIoLS1mb250LXNpemUtMngpO1xuICAtLXRleHQtc3R5bGUtYm9keS1zbWFsbC1zcGFjaW5nOiB2YXIoLS1mb250LXNwYWNpbmctbm9ybWFsKTtcbiAgLS10ZXh0LXN0eWxlLWJvZHktc21hbGwtd2VpZ2h0OiB2YXIoLS1mb250LXdlaWdodC1uZXV0cmFsKTtcbiAgLS10ZXh0LXN0eWxlLWJvZHktc21hbGwtaGVpZ2h0OiB2YXIoLS1mb250LWhlaWdodC1ub3JtYWwpO1xuICAtLXRleHQtc3R5bGUtYm9keS1zbWFsbC1zdHJvbmctd2VpZ2h0OiB2YXIoLS1mb250LXdlaWdodC1idWxreSk7XG5cbiAgLS10ZXh0LXN0eWxlLWxhYmVsLWxhcmdlLWZhbWlseTogdmFyKC0tZm9udC1mYW1pbHktcmVndWxhcik7XG4gIC0tdGV4dC1zdHlsZS1sYWJlbC1sYXJnZS1zaXplOiB2YXIoLS1mb250LXNpemUtM3gpO1xuICAtLXRleHQtc3R5bGUtbGFiZWwtbGFyZ2Utc3BhY2luZzogdmFyKC0tZm9udC1zcGFjaW5nLW5vcm1hbCk7XG4gIC0tdGV4dC1zdHlsZS1sYWJlbC1sYXJnZS13ZWlnaHQ6IHZhcigtLWZvbnQtd2VpZ2h0LW1lZGlhbik7XG4gIC0tdGV4dC1zdHlsZS1sYWJlbC1sYXJnZS1oZWlnaHQ6IHZhcigtLWZvbnQtaGVpZ2h0LW5vcm1hbCk7XG5cbiAgLS10ZXh0LXN0eWxlLWxhYmVsLXNtYWxsLWZhbWlseTogdmFyKC0tZm9udC1mYW1pbHktcmVndWxhcik7XG4gIC0tdGV4dC1zdHlsZS1sYWJlbC1zbWFsbC1zaXplOiB2YXIoLS1mb250LXNpemUtMngpO1xuICAtLXRleHQtc3R5bGUtbGFiZWwtc21hbGwtc3BhY2luZzogdmFyKC0tZm9udC1zcGFjaW5nLWxvb3NlKTtcbiAgLS10ZXh0LXN0eWxlLWxhYmVsLXNtYWxsLXdlaWdodDogdmFyKC0tZm9udC13ZWlnaHQtbWVkaWFuKTtcbiAgLS10ZXh0LXN0eWxlLWxhYmVsLXNtYWxsLWhlaWdodDogdmFyKC0tZm9udC1oZWlnaHQtbm9ybWFsKTtcblxuICAtLXRleHQtc3R5bGUtbWljcm8tZmFtaWx5OiB2YXIoLS1mb250LWZhbWlseS1yZWd1bGFyKTtcbiAgLS10ZXh0LXN0eWxlLW1pY3JvLXNpemU6IHZhcigtLWZvbnQtc2l6ZS0xeCk7XG4gIC0tdGV4dC1zdHlsZS1taWNyby1zcGFjaW5nOiB2YXIoLS1mb250LXNwYWNpbmctbG9vc2UpO1xuICAtLXRleHQtc3R5bGUtbWljcm8td2VpZ2h0OiB2YXIoLS1mb250LXdlaWdodC1uZXV0cmFsKTtcbiAgLS10ZXh0LXN0eWxlLW1pY3JvLWhlaWdodDogdmFyKC0tZm9udC1oZWlnaHQtdGlnaHQpO1xufVxuXG4uY29sb3Itc2NoZW1lLWxpZ2h0IHtcbiAgLS1jb2xvci1pbnRlcmFjdGl2ZS1wcmltYXJ5OiB2YXIoLS1jb2xvci1ncmVlbi0xMDApO1xuICAtLWNvbG9yLWludGVyYWN0aXZlLXByaW1hcnktaG92ZXI6IHZhcigtLWNvbG9yLWdyZWVuLTMwMCk7XG4gIC0tY29sb3ItaW50ZXJhY3RpdmUtc2Vjb25kYXJ5OiB2YXIoLS1jb2xvci10cmFuc3BhcmVudCk7XG4gIC0tY29sb3ItaW50ZXJhY3RpdmUtc2Vjb25kYXJ5LWhvdmVyOiB2YXIoLS1jb2xvci1ncmV5LTEwMDApO1xuICAtLWNvbG9yLWludGVyYWN0aXZlLXRlcnRpYXJ5OiB2YXIoLS1jb2xvci10cmFuc3BhcmVudCk7XG4gIC0tY29sb3ItaW50ZXJhY3RpdmUtdGVydGlhcnktaG92ZXI6IHZhcigtLWNvbG9yLWdyZXktMjUpO1xuICAtLWNvbG9yLWludGVyYWN0aXZlLWNvbnRyb2w6IHZhcigtLWNvbG9yLWdyZXktMTAwMCk7XG4gIC0tY29sb3ItaW50ZXJhY3RpdmUtY29udHJvbC1ob3ZlcjogdmFyKC0tY29sb3ItZ3JleS03MDApO1xuICAtLWNvbG9yLWludGVyYWN0aXZlLWRpc2FibGVkOiB2YXIoLS1jb2xvci1ncmV5LTEwMCk7XG5cbiAgLS1jb2xvci1zdXJmYWNlLXByaW1hcnk6IHZhcigtLWNvbG9yLXdoaXRlKTtcbiAgLS1jb2xvci1zdXJmYWNlLWFjY2VudDogdmFyKC0tY29sb3ItZ3JleS01MCk7XG4gIC0tY29sb3Itc3VyZmFjZS1pbnZlcnNlOiB2YXIoLS1jb2xvci1ncmV5LTEwMDApO1xuICAtLWNvbG9yLXN1cmZhY2UtYnJhbmQtYWNjZW50OiB2YXIoLS1jb2xvci1qYWZmYS0yNSk7XG4gIC0tY29sb3Itc3VyZmFjZS1lbGV2YXRlZDogdmFyKC0tY29sb3ItZ3JleS03MDApO1xuICAtLWNvbG9yLXN1cmZhY2UtY2F1dGlvbi1kZWZhdWx0OiB2YXIoLS1jb2xvci1qYWZmYS0yNSk7XG4gIC0tY29sb3Itc3VyZmFjZS1jYXV0aW9uLXN0cm9uZzogdmFyKC0tY29sb3ItamFmZmEtNzAwKTtcbiAgLS1jb2xvci1zdXJmYWNlLWNyaXRpY2FsLWRlZmF1bHQ6IHZhcigtLWNvbG9yLXZlcnliZXJyeS0yNSk7XG4gIC0tY29sb3Itc3VyZmFjZS1jcml0aWNhbC1zdHJvbmc6IHZhcigtLWNvbG9yLXZlcnliZXJyeS03MDApO1xuICAtLWNvbG9yLXN1cmZhY2UtaW5mby1kZWZhdWx0OiB2YXIoLS1jb2xvci1ibHVlLTI1KTtcbiAgLS1jb2xvci1zdXJmYWNlLWluZm8tc3Ryb25nOiB2YXIoLS1jb2xvci1ibHVlLTcwMCk7XG4gIC0tY29sb3Itc3VyZmFjZS1uZXV0cmFsLWRlZmF1bHQ6IHZhcigtLWNvbG9yLWdyZXktMjUpO1xuICAtLWNvbG9yLXN1cmZhY2UtbmV1dHJhbC1zdHJvbmc6IHZhcigtLWNvbG9yLWdyZXktMTAwMCk7XG4gIC0tY29sb3Itc3VyZmFjZS1wb3NpdGl2ZS1kZWZhdWx0OiB2YXIoLS1jb2xvci1ncmVlbi0yNSk7XG4gIC0tY29sb3Itc3VyZmFjZS1wb3NpdGl2ZS1zdHJvbmc6IHZhcigtLWNvbG9yLWdyZWVuLTcwMCk7XG5cbiAgLS1jb2xvci1vdmVybGF5LWxpZ2h0OiB2YXIoLS1jb2xvci13aGl0ZS1tYXNrKTtcbiAgLS1jb2xvci1vdmVybGF5LWRhcms6IHZhcigtLWNvbG9yLWdyZXktMTAwMC1tYXNrKTtcblxuICAtLWNvbG9yLWNvbnRlbnQtYnJhbmQ6IHZhcigtLWNvbG9yLWdyZWVuLTEwMDApO1xuICAtLWNvbG9yLWNvbnRlbnQtYnJhbmQtYWNjZW50OiB2YXIoLS1jb2xvci1idWJibGVndW0tNzAwKTtcbiAgLS1jb2xvci1jb250ZW50LXByaW1hcnk6IHZhcigtLWNvbG9yLWdyZXktMTAwMCk7XG4gIC0tY29sb3ItY29udGVudC1pbnZlcnNlOiB2YXIoLS1jb2xvci13aGl0ZSk7XG4gIC0tY29sb3ItY29udGVudC1zZWNvbmRhcnk6IHZhcigtLWNvbG9yLWdyZXktNTAwKTtcbiAgLS1jb2xvci1jb250ZW50LWRpc2FibGVkOiB2YXIoLS1jb2xvci1ncmV5LTMwMCk7XG4gIC0tY29sb3ItY29udGVudC1jYXV0aW9uLWRlZmF1bHQ6IHZhcigtLWNvbG9yLWphZmZhLTcwMCk7XG4gIC0tY29sb3ItY29udGVudC1jYXV0aW9uLXN0cm9uZzogdmFyKC0tY29sb3ItamFmZmEtMjUpO1xuICAtLWNvbG9yLWNvbnRlbnQtY3JpdGljYWwtZGVmYXVsdDogdmFyKC0tY29sb3ItdmVyeWJlcnJ5LTcwMCk7XG4gIC0tY29sb3ItY29udGVudC1jcml0aWNhbC1zdHJvbmc6IHZhcigtLWNvbG9yLXZlcnliZXJyeS0yNSk7XG4gIC0tY29sb3ItY29udGVudC1pbmZvLWRlZmF1bHQ6IHZhcigtLWNvbG9yLWJsdWUtNzAwKTtcbiAgLS1jb2xvci1jb250ZW50LWluZm8tc3Ryb25nOiB2YXIoLS1jb2xvci1ibHVlLTI1KTtcbiAgLS1jb2xvci1jb250ZW50LW5ldXRyYWwtZGVmYXVsdDogdmFyKC0tY29sb3ItZ3JleS0xMDAwKTtcbiAgLS1jb2xvci1jb250ZW50LW5ldXRyYWwtc3Ryb25nOiB2YXIoLS1jb2xvci13aGl0ZSk7XG4gIC0tY29sb3ItY29udGVudC1wb3NpdGl2ZS1kZWZhdWx0OiB2YXIoLS1jb2xvci1ncmVlbi03MDApO1xuICAtLWNvbG9yLWNvbnRlbnQtcG9zaXRpdmUtc3Ryb25nOiB2YXIoLS1jb2xvci1ncmVlbi0yNSk7XG5cbiAgLS1jb2xvci1ib3JkZXItcHJpbWFyeTogdmFyKC0tY29sb3ItZ3JleS0xMDAwKTtcbiAgLS1jb2xvci1ib3JkZXItc2Vjb25kYXJ5OiB2YXIoLS1jb2xvci1ncmV5LTMwMCk7XG4gIC0tY29sb3ItYm9yZGVyLXRlcnRpYXJ5OiB2YXIoLS1jb2xvci1ncmV5LTEwMCk7XG5cbiAgLS1jb2xvci1hbHdheXMtd2hpdGU6IHZhcigtLWNvbG9yLXdoaXRlKTtcbn1cblxuLmNvbG9yLXNjaGVtZS1kYXJrIHtcbiAgLS1jb2xvci1pbnRlcmFjdGl2ZS1wcmltYXJ5OiB2YXIoLS1jb2xvci1ncmVlbi0xMDApO1xuICAtLWNvbG9yLWludGVyYWN0aXZlLXByaW1hcnktaG92ZXI6IHZhcigtLWNvbG9yLWdyZWVuLTMwMCk7XG4gIC0tY29sb3ItaW50ZXJhY3RpdmUtc2Vjb25kYXJ5OiB2YXIoLS1jb2xvci10cmFuc3BhcmVudCk7XG4gIC0tY29sb3ItaW50ZXJhY3RpdmUtc2Vjb25kYXJ5LWhvdmVyOiB2YXIoLS1jb2xvci13aGl0ZSk7XG4gIC0tY29sb3ItaW50ZXJhY3RpdmUtdGVydGlhcnk6IHZhcigtLWNvbG9yLXRyYW5zcGFyZW50KTtcbiAgLS1jb2xvci1pbnRlcmFjdGl2ZS10ZXJ0aWFyeS1ob3ZlcjogdmFyKC0tY29sb3ItZ3JleS03MDApO1xuICAtLWNvbG9yLWludGVyYWN0aXZlLWNvbnRyb2w6IHZhcigtLWNvbG9yLXdoaXRlKTtcbiAgLS1jb2xvci1pbnRlcmFjdGl2ZS1jb250cm9sLWhvdmVyOiB2YXIoLS1jb2xvci1ncmV5LTEwMCk7XG4gIC0tY29sb3ItaW50ZXJhY3RpdmUtZGlzYWJsZWQ6IHZhcigtLWNvbG9yLWdyZXktNzAwKTtcblxuICAtLWNvbG9yLXN1cmZhY2UtcHJpbWFyeTogdmFyKC0tY29sb3ItZ3JleS0xMDAwKTtcbiAgLS1jb2xvci1zdXJmYWNlLWFjY2VudDogdmFyKC0tY29sb3ItZ3JleS03MDApO1xuICAtLWNvbG9yLXN1cmZhY2UtaW52ZXJzZTogdmFyKC0tY29sb3Itd2hpdGUpO1xuICAtLWNvbG9yLXN1cmZhY2UtYnJhbmQtYWNjZW50OiB2YXIoLS1jb2xvci1ncmV5LTcwMCk7XG4gIC0tY29sb3Itc3VyZmFjZS1lbGV2YXRlZDogdmFyKC0tY29sb3ItZ3JleS03MDApO1xuICAtLWNvbG9yLXN1cmZhY2UtY2F1dGlvbi1kZWZhdWx0OiB2YXIoLS1jb2xvci1qYWZmYS0xMDAwKTtcbiAgLS1jb2xvci1zdXJmYWNlLWNhdXRpb24tc3Ryb25nOiB2YXIoLS1jb2xvci1qYWZmYS01MDApO1xuICAtLWNvbG9yLXN1cmZhY2UtY3JpdGljYWwtZGVmYXVsdDogdmFyKC0tY29sb3ItdmVyeWJlcnJ5LTEwMDApO1xuICAtLWNvbG9yLXN1cmZhY2UtY3JpdGljYWwtc3Ryb25nOiB2YXIoLS1jb2xvci12ZXJ5YmVycnktNTAwKTtcbiAgLS1jb2xvci1zdXJmYWNlLWluZm8tZGVmYXVsdDogdmFyKC0tY29sb3ItYmx1ZS0xMDAwKTtcbiAgLS1jb2xvci1zdXJmYWNlLWluZm8tc3Ryb25nOiB2YXIoLS1jb2xvci1ibHVlLTUwMCk7XG4gIC0tY29sb3Itc3VyZmFjZS1uZXV0cmFsLWRlZmF1bHQ6IHZhcigtLWNvbG9yLWdyZXktNzAwKTtcbiAgLS1jb2xvci1zdXJmYWNlLW5ldXRyYWwtc3Ryb25nOiB2YXIoLS1jb2xvci13aGl0ZSk7XG4gIC0tY29sb3Itc3VyZmFjZS1wb3NpdGl2ZS1kZWZhdWx0OiB2YXIoLS1jb2xvci1ncmVlbi0xMDAwKTtcbiAgLS1jb2xvci1zdXJmYWNlLXBvc2l0aXZlLXN0cm9uZzogdmFyKC0tY29sb3ItZ3JlZW4tNTAwKTtcblxuICAtLWNvbG9yLW92ZXJsYXktbGlnaHQ6IHZhcigtLWNvbG9yLXdoaXRlLW1hc2spO1xuICAtLWNvbG9yLW92ZXJsYXktZGFyazogdmFyKC0tY29sb3ItZ3JleS0xMDAwLW1hc2spO1xuXG4gIC0tY29sb3ItY29udGVudC1icmFuZDogdmFyKC0tY29sb3ItZ3JlZW4tMTAwMCk7XG4gIC0tY29sb3ItY29udGVudC1icmFuZC1hY2NlbnQ6IHZhcigtLWNvbG9yLWJ1YmJsZWd1bS0xMDApO1xuICAtLWNvbG9yLWNvbnRlbnQtcHJpbWFyeTogdmFyKC0tY29sb3Itd2hpdGUpO1xuICAtLWNvbG9yLWNvbnRlbnQtaW52ZXJzZTogdmFyKC0tY29sb3ItZ3JleS0xMDAwKTtcbiAgLS1jb2xvci1jb250ZW50LXNlY29uZGFyeTogdmFyKC0tY29sb3ItZ3JleS0xMDApO1xuICAtLWNvbG9yLWNvbnRlbnQtZGlzYWJsZWQ6IHZhcigtLWNvbG9yLWdyZXktNTAwKTtcbiAgLS1jb2xvci1jb250ZW50LWNhdXRpb24tZGVmYXVsdDogdmFyKC0tY29sb3ItamFmZmEtNTAwKTtcbiAgLS1jb2xvci1jb250ZW50LWNhdXRpb24tc3Ryb25nOiB2YXIoLS1jb2xvci1qYWZmYS0xMDAwKTtcbiAgLS1jb2xvci1jb250ZW50LWNyaXRpY2FsLWRlZmF1bHQ6IHZhcigtLWNvbG9yLXZlcnliZXJyeS01MDApO1xuICAtLWNvbG9yLWNvbnRlbnQtY3JpdGljYWwtc3Ryb25nOiB2YXIoLS1jb2xvci12ZXJ5YmVycnktMTAwMCk7XG4gIC0tY29sb3ItY29udGVudC1pbmZvLWRlZmF1bHQ6IHZhcigtLWNvbG9yLWJsdWUtNTAwKTtcbiAgLS1jb2xvci1jb250ZW50LWluZm8tc3Ryb25nOiB2YXIoLS1jb2xvci1ibHVlLTEwMDApO1xuICAtLWNvbG9yLWNvbnRlbnQtbmV1dHJhbC1kZWZhdWx0OiB2YXIoLS1jb2xvci13aGl0ZSk7XG4gIC0tY29sb3ItY29udGVudC1uZXV0cmFsLXN0cm9uZzogdmFyKC0tY29sb3ItZ3JleS0xMDAwKTtcbiAgLS1jb2xvci1jb250ZW50LXBvc2l0aXZlLWRlZmF1bHQ6IHZhcigtLWNvbG9yLWdyZWVuLTUwMCk7XG4gIC0tY29sb3ItY29udGVudC1wb3NpdGl2ZS1zdHJvbmc6IHZhcigtLWNvbG9yLWdyZWVuLTEwMDApO1xuXG4gIC0tY29sb3ItYm9yZGVyLXByaW1hcnk6IHZhcigtLWNvbG9yLXdoaXRlKTtcbiAgLS1jb2xvci1ib3JkZXItc2Vjb25kYXJ5OiB2YXIoLS1jb2xvci1ncmV5LTUwMCk7XG4gIC0tY29sb3ItYm9yZGVyLXRlcnRpYXJ5OiB2YXIoLS1jb2xvci1ncmV5LTcwMCk7XG5cbiAgLS1jb2xvci1hbHdheXMtd2hpdGU6IHZhcigtLWNvbG9yLXdoaXRlKTtcbn1cbiJdLCJzb3VyY2VSb290IjoiIn0= */
        </style>
        <style>
            .brand-neue-button {
                gap: var(--spacing-2x);
                border-radius: var(--roundness-subtle);
                background: var(--color-interactive-primary);
                color: var(--color-content-brand);
                font-family: PolySans-Median;
                font-size: var(--font-size-2x);
                letter-spacing: 0.02em;
                text-align: center;
                padding: 0 20px;
            }
            .brand-neue-button:hover,
            .brand-neue-button:active,
            .brand-neue-button:focus {
                background: var(--color-interactive-primary-hover);
            }

            .brand-neue-button__open-in-new::after {
                font-size: 0;
                margin-left: 5px;
                vertical-align: sub;
                content: url('data:image/svg+xml,<svg width="14" height="14" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg"><g id="ico-/-24-/-actions-/-open_in_new"><path id="Icon-color" d="M17.5 12.0833V15.8333C17.5 16.7538 16.7538 17.5 15.8333 17.5H4.16667C3.24619 17.5 2.5 16.7538 2.5 15.8333V4.16667C2.5 3.24619 3.24619 2.5 4.16667 2.5H7.91667C8.14679 2.5 8.33333 2.68655 8.33333 2.91667V3.75C8.33333 3.98012 8.14679 4.16667 7.91667 4.16667H4.16667V15.8333H15.8333V12.0833C15.8333 11.8532 16.0199 11.6667 16.25 11.6667H17.0833C17.3135 11.6667 17.5 11.8532 17.5 12.0833ZM17.3167 2.91667L17.0917 2.69167C16.98 2.57535 16.8278 2.50668 16.6667 2.5H11.25C11.0199 2.5 10.8333 2.68655 10.8333 2.91667V3.75C10.8333 3.98012 11.0199 4.16667 11.25 4.16667H14.6583L7.625 11.2C7.54612 11.2782 7.50175 11.3847 7.50175 11.4958C7.50175 11.6069 7.54612 11.7134 7.625 11.7917L8.20833 12.375C8.28657 12.4539 8.39307 12.4982 8.50417 12.4982C8.61527 12.4982 8.72176 12.4539 8.8 12.375L15.8333 5.35V8.75C15.8333 8.98012 16.0199 9.16667 16.25 9.16667H17.0833C17.3135 9.16667 17.5 8.98012 17.5 8.75V3.33333C17.4955 3.17342 17.4299 3.02132 17.3167 2.90833V2.91667Z" fill="%231A4200"/></g></svg>');
            }
            /*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL2FwcC9qYXZhc2NyaXB0L2NvbXBvbmVudHMvYnJhbmRfbmV1ZV90b2tlbnMvY29tcG9uZW50cy9idXR0b24uc2FzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLHNCQUFBO0VBQ0Esc0NBQUE7RUFDQSw0Q0FBQTtFQUNBLGlDQUFBO0VBQ0EsNEJBQUE7RUFDQSw4QkFBQTtFQUNBLHNCQUFBO0VBQ0Esa0JBQUE7RUFDQSxlQUFBO0FBQ0Y7QUFBRTtFQUNFLGtEQUFBO0FBRUo7O0FBQ0U7RUFDRSxZQUFBO0VBQ0EsZ0JBQUE7RUFDQSxtQkFBQTtFQUNBLGdEQUFBO0FBRUoiLCJzb3VyY2VzQ29udGVudCI6WyIuYnJhbmQtbmV1ZS1idXR0b25cbiAgZ2FwOiB2YXIoLS1zcGFjaW5nLTJ4KVxuICBib3JkZXItcmFkaXVzOiB2YXIoLS1yb3VuZG5lc3Mtc3VidGxlKVxuICBiYWNrZ3JvdW5kOiB2YXIoLS1jb2xvci1pbnRlcmFjdGl2ZS1wcmltYXJ5KVxuICBjb2xvcjogdmFyKC0tY29sb3ItY29udGVudC1icmFuZClcbiAgZm9udC1mYW1pbHk6IFBvbHlTYW5zLU1lZGlhblxuICBmb250LXNpemU6IHZhcigtLWZvbnQtc2l6ZS0yeClcbiAgbGV0dGVyLXNwYWNpbmc6IDAuMDJlbVxuICB0ZXh0LWFsaWduOiBjZW50ZXJcbiAgcGFkZGluZzogMCAyMHB4XG4gICY6aG92ZXIsICY6YWN0aXZlLCAmOmZvY3VzXG4gICAgYmFja2dyb3VuZDogdmFyKC0tY29sb3ItaW50ZXJhY3RpdmUtcHJpbWFyeS1ob3ZlcilcblxuLmJyYW5kLW5ldWUtYnV0dG9uX19vcGVuLWluLW5ld1xuICAmOjphZnRlclxuICAgIGZvbnQtc2l6ZTogMFxuICAgIG1hcmdpbi1sZWZ0OiA1cHhcbiAgICB2ZXJ0aWNhbC1hbGlnbjogc3ViXG4gICAgY29udGVudDogdXJsKCdkYXRhOmltYWdlL3N2Zyt4bWwsPHN2ZyB3aWR0aD1cIjE0XCIgaGVpZ2h0PVwiMTRcIiB2aWV3Qm94PVwiMCAwIDIwIDIwXCIgZmlsbD1cIm5vbmVcIiB4bWxucz1cImh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnXCI+PGcgaWQ9XCJpY28tLy0yNC0vLWFjdGlvbnMtLy1vcGVuX2luX25ld1wiPjxwYXRoIGlkPVwiSWNvbi1jb2xvclwiIGQ9XCJNMTcuNSAxMi4wODMzVjE1LjgzMzNDMTcuNSAxNi43NTM4IDE2Ljc1MzggMTcuNSAxNS44MzMzIDE3LjVINC4xNjY2N0MzLjI0NjE5IDE3LjUgMi41IDE2Ljc1MzggMi41IDE1LjgzMzNWNC4xNjY2N0MyLjUgMy4yNDYxOSAzLjI0NjE5IDIuNSA0LjE2NjY3IDIuNUg3LjkxNjY3QzguMTQ2NzkgMi41IDguMzMzMzMgMi42ODY1NSA4LjMzMzMzIDIuOTE2NjdWMy43NUM4LjMzMzMzIDMuOTgwMTIgOC4xNDY3OSA0LjE2NjY3IDcuOTE2NjcgNC4xNjY2N0g0LjE2NjY3VjE1LjgzMzNIMTUuODMzM1YxMi4wODMzQzE1LjgzMzMgMTEuODUzMiAxNi4wMTk5IDExLjY2NjcgMTYuMjUgMTEuNjY2N0gxNy4wODMzQzE3LjMxMzUgMTEuNjY2NyAxNy41IDExLjg1MzIgMTcuNSAxMi4wODMzWk0xNy4zMTY3IDIuOTE2NjdMMTcuMDkxNyAyLjY5MTY3QzE2Ljk4IDIuNTc1MzUgMTYuODI3OCAyLjUwNjY4IDE2LjY2NjcgMi41SDExLjI1QzExLjAxOTkgMi41IDEwLjgzMzMgMi42ODY1NSAxMC44MzMzIDIuOTE2NjdWMy43NUMxMC44MzMzIDMuOTgwMTIgMTEuMDE5OSA0LjE2NjY3IDExLjI1IDQuMTY2NjdIMTQuNjU4M0w3LjYyNSAxMS4yQzcuNTQ2MTIgMTEuMjc4MiA3LjUwMTc1IDExLjM4NDcgNy41MDE3NSAxMS40OTU4QzcuNTAxNzUgMTEuNjA2OSA3LjU0NjEyIDExLjcxMzQgNy42MjUgMTEuNzkxN0w4LjIwODMzIDEyLjM3NUM4LjI4NjU3IDEyLjQ1MzkgOC4zOTMwNyAxMi40OTgyIDguNTA0MTcgMTIuNDk4MkM4LjYxNTI3IDEyLjQ5ODIgOC43MjE3NiAxMi40NTM5IDguOCAxMi4zNzVMMTUuODMzMyA1LjM1VjguNzVDMTUuODMzMyA4Ljk4MDEyIDE2LjAxOTkgOS4xNjY2NyAxNi4yNSA5LjE2NjY3SDE3LjA4MzNDMTcuMzEzNSA5LjE2NjY3IDE3LjUgOC45ODAxMiAxNy41IDguNzVWMy4zMzMzM0MxNy40OTU1IDMuMTczNDIgMTcuNDI5OSAzLjAyMTMyIDE3LjMxNjcgMi45MDgzM1YyLjkxNjY3WlwiIGZpbGw9XCIlMjMxQTQyMDBcIi8+PC9nPjwvc3ZnPicpXG5cbiJdLCJzb3VyY2VSb290IjoiIn0= */
        </style>
        <style>
            /* Contrast and legibility adjustments */
            body {
                color: #0f172a;
                font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif !important;
            }

            .page {
                min-height: 100vh;
                overflow-anchor: none;
            }

            .content-main {
                min-height: 80vh;
                overflow-anchor: none;
            }

            .content-main .grid-container {
                min-height: 320px;
                overflow-anchor: none;
            }

            .js-item-togglable-content.has-toggle {
                min-height: 420px;
                position: relative;
            }

            .search-field__input-field {
                background-color: #ffffff !important;
                color: #0f172a !important;
                border: 1px solid #0f172a !important;
            }

            .search-field__input-field::placeholder {
                color: #1f2937 !important;
                opacity: 1;
            }

            .search-field__input-field:focus {
                outline: 2px solid #2563eb !important;
                outline-offset: 2px;
            }

            .context-header {
                background-color: #f8fafc;
                color: #0f172a;
            }

            .context-header a,
            .context-header .t-heading {
                color: #0b1220;
            }

            .context-header a:hover {
                color: #0f766e;
            }

            .btn-icon {
                background-color: #111827 !important;
                color: #f8fafc !important;
                border: 1px solid #0b1220;
            }

            .btn-icon:hover,
            .btn-icon:focus {
                background-color: #0b1220 !important;
                color: #ffffff !important;
            }

            .item-bookmarking__left-icons_hidden {
                min-height: 36px;
                display: flex;
                gap: 0.75rem;
                align-items: center;
            }

            .item-bookmarking__control--label {
                display: inline-block;
                min-height: 20px;
            }

            .badges {
                display: flex;
                gap: 0.5rem;
                align-items: center;
                padding: 0;
                margin: 0;
                list-style: none;
            }

            .badges li {
                list-style: none;
            }

            .community-badges__badge-wrapper--s {
                width: 24px;
                height: 24px;
                display: inline-flex;
                align-items: center;
                justify-content: center;
                flex-shrink: 0;
            }

            .community-badges__badge--s {
                width: 20px;
                height: 20px;
                display: block;
            }

            .global-footer {
                background: #0b1220 !important;
                color: #e2e8f0 !important;
            }

            .global-footer__text-link,
            .global-footer__icon-link,
            .global-footer__price-disclaimer,
            .global-footer__copyright {
                color: #f8fafc !important;
            }

            .global-footer__text-link:hover,
            .global-footer__icon-link:hover {
                color: #cbd5e1 !important;
            }

            .global-footer-stats__number {
                color: #ffffff !important;
            }

            .purchase-form__renewal-price {
                color: #1f2937;
            }

            .purchase-form__renewal-price--strikethrough {
                color: #475569;
            }

            .e-btn--3d.-color-primary {
                background: linear-gradient(180deg, #2f6b12 0%, #22540e 100%);
                border-color: #1d4b0c;
                color: #ffffff;
            }

            .e-btn--3d.-color-primary:hover,
            .e-btn--3d.-color-primary:focus {
                background: linear-gradient(180deg, #2a5f10 0%, #1b480c 100%);
                color: #ffffff;
            }

            .e-btn--3d.-color-primary:focus {
                outline: 2px solid #1f7a1f;
                outline-offset: 2px;
            }

            .global-footer {
                background: #0f172a;
                color: #e2e8f0;
            }

            .global-footer__text-link,
            .global-footer__icon-link,
            .global-footer__price-disclaimer,
            .global-footer__copyright {
                color: #f1f5f9;
            }

            .global-footer__text-link:hover,
            .global-footer__icon-link:hover {
                color: #cbd5e1;
            }

            .global-footer-stats__number {
                color: #f8fafc;
            }

            .js-item-header__price {
                color: #ffffff;
            }

            @keyframes itemPriceFloatIn {
                from {
                    transform: translate(-50%, 16px);
                    opacity: 0;
                }
                to {
                    transform: translate(-50%, 0);
                    opacity: 1;
                }
            }

            @keyframes itemPricePulse {
                0% {
                    transform: scale(1);
                    box-shadow: 0 10px 30px rgba(0, 0, 0, 0.15);
                }
                50% {
                    transform: scale(1.03);
                    box-shadow: 0 16px 36px rgba(0, 0, 0, 0.2);
                }
                100% {
                    transform: scale(1);
                    box-shadow: 0 10px 30px rgba(0, 0, 0, 0.15);
                }
            }

            @media (max-width: 1024px) {
                body {
                    padding-bottom: 120px;
                }

                .item-header__price.is-hidden-desktop {
                    position: fixed;
                    left: 50%;
                    bottom: 16px;
                    transform: translateX(-50%);
                    width: calc(100% - 2rem);
                    max-width: 480px;
                    z-index: 1100;
                    margin: 0 auto;
                    display: flex;
                    justify-content: center;
                    animation: itemPriceFloatIn 0.35s ease-out both;
                    pointer-events: none;
                }

                .item-header__price.is-hidden-desktop > div {
                    flex: 1;
                    pointer-events: none;
                }

                .item-header__price.is-hidden-desktop .e-btn--3d {
                    width: 100%;
                    justify-content: center;
                    box-shadow: 0 10px 30px rgba(0, 0, 0, 0.15);
                    pointer-events: auto;
                    animation: itemPricePulse 2.2s ease-in-out infinite;
                    will-change: transform, box-shadow;
                }
            }

            .purchase-form__button .e-btn--3d {
                animation: itemPricePulse 2.2s ease-in-out infinite;
                will-change: transform, box-shadow;
            }

            @media (max-width: 768px) {
                .purchase-form__cta-buttons {
                    display: none;
                }
            }
            .user-html ol, .user-html ul {
                padding-left: 0;
            }
            .page-tabs .item-navigation-reviews-comments{
                background-color: #000000;
            }
        </style>
    </head>
    <body
        class="color-scheme-light"
        data-view="app impressionTracker"
        data-responsive="true"
        data-user-signed-in="false"
    >
        <!--[if lte IE 8]>
            <div style="color: #fff; background: #f00; padding: 20px; text-align: center">
                CodeCanyon no longer actively supports this version of Internet Explorer. We suggest that you
                <a
                    href="#"
                    style="color: #fff; text-decoration: underline"
                    >upgrade to a newer version</a
                >
                or
                <a href="#" style="color: #fff; text-decoration: underline"
                    >try a different browser</a
                >.
            </div>
        <![endif]-->

        <div class="page">
            <div class="page__off-canvas--left overflow">
                <div class="off-canvas-left js-off-canvas-left">
                    <div class="off-canvas-left__top">
                        <a href="#"
                            ><span style="vertical-align: inherit"
                                ><span style="vertical-align: inherit">ตลาดเอนวาโต</span></span
                            ></a
                        >
                    </div>

                    <div class="off-canvas-left__current-site -color-codecanyon">
                        <span class="off-canvas-left__site-title"
                            ><span style="vertical-align: inherit"
                                ><span style="vertical-align: inherit"> รหัส </span></span
                            ></span
                        >

                        <a
                            class="off-canvas-left__current-site-toggle -white-arrow -color-codecanyon"
                            data-view="dropdown"
                            data-dropdown-target=".off-canvas-left__sites"
                            href="#"
                        ></a>
                    </div>

                    <div class="off-canvas-left__sites is-hidden" id="off-canvas-sites">
                        <a class="off-canvas-left__site" href="#">
                            <span class="off-canvas-left__site-title"
                                ><span style="vertical-align: inherit"
                                    ><span style="vertical-align: inherit"> ธีมเว็บและเทมเพลต </span></span
                                ></span
                            >
                            <i class="e-icon -icon-right-open"></i>
                        </a>
                        <a class="off-canvas-left__site" href="#">
                            <span class="off-canvas-left__site-title"
                                ><span style="vertical-align: inherit"
                                    ><span style="vertical-align: inherit"> วิดีโอ </span></span
                                ></span
                            >
                            <i class="e-icon -icon-right-open"></i>
                        </a>
                        <a class="off-canvas-left__site" href="#">
                            <span class="off-canvas-left__site-title"
                                ><span style="vertical-align: inherit"
                                    ><span style="vertical-align: inherit"> เสียง </span></span
                                ></span
                            >
                            <i class="e-icon -icon-right-open"></i>
                        </a>
                        <a class="off-canvas-left__site" href="#">
                            <span class="off-canvas-left__site-title"
                                ><span style="vertical-align: inherit"
                                    ><span style="vertical-align: inherit"> กราฟิก </span></span
                                ></span
                            >
                            <i class="e-icon -icon-right-open"></i>
                        </a>
                        <a class="off-canvas-left__site" href="#">
                            <span class="off-canvas-left__site-title"
                                ><span style="vertical-align: inherit"
                                    ><span style="vertical-align: inherit"> ภาพถ่าย </span></span
                                ></span
                            >
                            <i class="e-icon -icon-right-open"></i>
                        </a>
                        <a class="off-canvas-left__site" href="#">
                            <span class="off-canvas-left__site-title"
                                ><span style="vertical-align: inherit"
                                    ><span style="vertical-align: inherit"> ไฟล์ 3 มิติ </span></span
                                ></span
                            >
                            <i class="e-icon -icon-right-open"></i>
                        </a>
                    </div>

                    <div class="off-canvas-left__search">
                        <form id="search" action="/category/all" accept-charset="UTF-8" method="get">
                            <div class="search-field -border-none">
                                <div class="search-field__input">
                                    <input
                                        id="term"
                                        name="term"
                                        type="search"
                                        placeholder="Search"
                                        class="search-field__input-field"
                                    />
                                </div>
                                <button class="search-field__button" type="submit">
                                    <i class="e-icon -icon-search"
                                        ><span class="e-icon__alt"
                                            ><span style="vertical-align: inherit"
                                                ><span style="vertical-align: inherit">ค้นหา</span></span
                                            ></span
                                        ></i
                                    >
                                </button>
                            </div>
                        </form>
                    </div>

                    <ul>
                        <li>
                            <a
                                class="off-canvas-category-link"
                                data-view="dropdown"
                                data-dropdown-target="#off-canvas-all-items"
                                href="#"
                                ><span style="vertical-align: inherit"
                                    ><span style="vertical-align: inherit"> รายการทั้งหมด </span></span
                                ></a
                            >
                            <ul class="is-hidden" id="off-canvas-all-items">
                                <li>
                                    <a class="off-canvas-category-link--sub" href="#"
                                        ><span style="vertical-align: inherit"
                                            ><span style="vertical-align: inherit">ไฟล์ยอดนิยม</span></span
                                        ></a
                                    >
                                </li>
                                <li>
                                    <a class="off-canvas-category-link--sub" href="#"
                                        ><span style="vertical-align: inherit"
                                            ><span style="vertical-align: inherit">ไฟล์เด่น</span></span
                                        ></a
                                    >
                                </li>
                                <li>
                                    <a
                                        class="off-canvas-category-link--sub"
                                        href="#"
                                        ><span style="vertical-align: inherit"
                                            ><span style="vertical-align: inherit">ไฟล์ใหม่ยอดนิยม</span></span
                                        ></a
                                    >
                                </li>
                                <li>
                                    <a class="off-canvas-category-link--sub" href="#"
                                        ><span style="vertical-align: inherit"
                                            ><span style="vertical-align: inherit">ติดตามฟีด</span></span
                                        ></a
                                    >
                                </li>
                                <li>
                                    <a class="off-canvas-category-link--sub" href="#"
                                        ><span style="vertical-align: inherit"
                                            ><span style="vertical-align: inherit">นักเขียนชั้นนํา</span></span
                                        ></a
                                    >
                                </li>
                                <li>
                                    <a class="off-canvas-category-link--sub" href="#"
                                        ><span style="vertical-align: inherit"
                                            ><span style="vertical-align: inherit">นักเขียนหน้าใหม่ยอดนิยม</span></span
                                        ></a
                                    >
                                </li>
                                <li>
                                    <a class="off-canvas-category-link--sub" href="#"
                                        ><span style="vertical-align: inherit"
                                            ><span style="vertical-align: inherit">คอลเลกชันสาธารณะ</span></span
                                        ></a
                                    >
                                </li>
                                <li>
                                    <a class="off-canvas-category-link--sub" href="#"
                                        ><span style="vertical-align: inherit"
                                            ><span style="vertical-align: inherit">ดูหมวดหมู่ทั้งหมด</span></span
                                        ></a
                                    >
                                </li>
                            </ul>
                        </li>
                        <li>
                            <a
                                class="off-canvas-category-link"
                                data-view="dropdown"
                                data-dropdown-target="#off-canvas-php-scripts"
                                href="#"
                                ><span style="vertical-align: inherit"
                                    ><span style="vertical-align: inherit"> สคริปต์ PHP </span></span
                                ></a
                            >
                            <ul class="is-hidden" id="off-canvas-php-scripts">
                                <li>
                                    <a class="off-canvas-category-link--sub" href="#"
                                        ><span style="vertical-align: inherit"
                                            ><span style="vertical-align: inherit">แสดงสคริปต์ PHP ทั้งหมด</span></span
                                        ></a
                                    >
                                </li>
                                <li>
                                    <a
                                        class="off-canvas-category-link--sub"
                                        href="#"
                                        ><span style="vertical-align: inherit"
                                            ><span style="vertical-align: inherit">รายการยอดนิยม</span></span
                                        ></a
                                    >
                                </li>
                                <li>
                                    <a class="off-canvas-category-link--sub" href="#"
                                        ><span style="vertical-align: inherit"
                                            ><span style="vertical-align: inherit">ส่วนเสริม</span></span
                                        ></a
                                    >
                                </li>
                                <li>
                                    <a class="off-canvas-category-link--sub" href="#"
                                        ><span style="vertical-align: inherit"
                                            ><span style="vertical-align: inherit">ปฏิทิน</span></span
                                        ></a
                                    >
                                </li>
                                <li>
                                    <a class="off-canvas-category-link--sub" href="#"
                                        ><span style="vertical-align: inherit"
                                            ><span style="vertical-align: inherit">นับถอยหลัง</span></span
                                        ></a
                                    >
                                </li>
                                <li>
                                    <a
                                        class="off-canvas-category-link--sub"
                                        href="#"
                                        ><span style="vertical-align: inherit"
                                            ><span style="vertical-align: inherit">บทคัดย่อฐานข้อมูล</span></span
                                        ></a
                                    >
                                </li>
                                <li>
                                    <a class="off-canvas-category-link--sub" href="#"
                                        ><span style="vertical-align: inherit"
                                            ><span style="vertical-align: inherit">แบบฟอร์ม</span></span
                                        ></a
                                    >
                                </li>
                                <li>
                                    <a
                                        class="off-canvas-category-link--sub"
                                        href="#"
                                        ><span style="vertical-align: inherit"
                                            ><span style="vertical-align: inherit"
                                                >เครื่องมือช่วยเหลือและสนับสนุน</span
                                            ></span
                                        ></a
                                    >
                                </li>
                                <li>
                                    <a
                                        class="off-canvas-category-link--sub"
                                        href="#"
                                        ><span style="vertical-align: inherit"
                                            ><span style="vertical-align: inherit">รูปภาพและสื่อ</span></span
                                        ></a
                                    >
                                </li>
                                <li>
                                    <a
                                        class="off-canvas-category-link--sub"
                                        href="#"
                                        ><span style="vertical-align: inherit"
                                            ><span style="vertical-align: inherit">รถตักและรถอัพโหลด</span></span
                                        ></a
                                    >
                                </li>
                                <li>
                                    <a class="off-canvas-category-link--sub" href="#"
                                        ><span style="vertical-align: inherit"
                                            ><span style="vertical-align: inherit">การนําทาง</span></span
                                        ></a
                                    >
                                </li>
                                <li>
                                    <a class="off-canvas-category-link--sub" href="#"
                                        ><span style="vertical-align: inherit"
                                            ><span style="vertical-align: inherit">ข่าว ทิกเกอร์</span></span
                                        ></a
                                    >
                                </li>
                                <li>
                                    <a class="off-canvas-category-link--sub" href="#"
                                        ><span style="vertical-align: inherit"
                                            ><span style="vertical-align: inherit">โพล</span></span
                                        ></a
                                    >
                                </li>
                                <li>
                                    <a
                                        class="off-canvas-category-link--sub"
                                        href="#"
                                        ><span style="vertical-align: inherit"
                                            ><span style="vertical-align: inherit"
                                                >เครื่องมือการจัดการโครงการ</span
                                            ></span
                                        ></a
                                    >
                                </li>
                                <li>
                                    <a
                                        class="off-canvas-category-link--sub"
                                        href="#"
                                        ><span style="vertical-align: inherit"
                                            ><span style="vertical-align: inherit">การให้คะแนนและแผนภูมิ</span></span
                                        ></a
                                    >
                                </li>
                                <li>
                                    <a class="off-canvas-category-link--sub" href="#"
                                        ><span style="vertical-align: inherit"
                                            ><span style="vertical-align: inherit">ค้นหา</span></span
                                        ></a
                                    >
                                </li>
                                <li>
                                    <a class="off-canvas-category-link--sub" href="#"
                                        ><span style="vertical-align: inherit"
                                            ><span style="vertical-align: inherit">ตะกร้าสินค้า</span></span
                                        ></a
                                    >
                                </li>
                                <li>
                                    <a
                                        class="off-canvas-category-link--sub"
                                        href="#"
                                        ><span style="vertical-align: inherit"
                                            ><span style="vertical-align: inherit">เครือข่ายสังคมออนไลน์</span></span
                                        ></a
                                    >
                                </li>
                                <li>
                                    <a class="off-canvas-category-link--sub" href="#"
                                        ><span style="vertical-align: inherit"
                                            ><span style="vertical-align: inherit">เบ็ดเตล็ด</span></span
                                        ></a
                                    >
                                </li>
                            </ul>
                        </li>
                        <li>
                            <a
                                class="off-canvas-category-link"
                                data-view="dropdown"
                                data-dropdown-target="#off-canvas-wordpress"
                                href="#"
                                ><span style="vertical-align: inherit"
                                    ><span style="vertical-align: inherit"> เวิร์ดเพรส </span></span
                                ></a
                            >
                            <ul class="is-hidden" id="off-canvas-wordpress">
                                <li>
                                    <a class="off-canvas-category-link--sub" href="#"
                                        ><span style="vertical-align: inherit"
                                            ><span style="vertical-align: inherit">แสดง WordPress ทั้งหมด</span></span
                                        ></a
                                    >
                                </li>
                                <li>
                                    <a
                                        class="off-canvas-category-link--sub"
                                        href="#"
                                        ><span style="vertical-align: inherit"
                                            ><span style="vertical-align: inherit">รายการยอดนิยม</span></span
                                        ></a
                                    >
                                </li>
                                <li>
                                    <a class="off-canvas-category-link--sub" href="#"
                                        ><span style="vertical-align: inherit"
                                            ><span style="vertical-align: inherit">ส่วนเสริม</span></span
                                        ></a
                                    >
                                </li>
                                <li>
                                    <a class="off-canvas-category-link--sub" href="#"
                                        ><span style="vertical-align: inherit"
                                            ><span style="vertical-align: inherit">การโฆษณา</span></span
                                        ></a
                                    >
                                </li>
                                <li>
                                    <a class="off-canvas-category-link--sub" href="#"
                                        ><span style="vertical-align: inherit"
                                            ><span style="vertical-align: inherit">ปฏิทิน</span></span
                                        ></a
                                    >
                                </li>
                                <li>
                                    <a class="off-canvas-category-link--sub" href="#"
                                        ><span style="vertical-align: inherit"
                                            ><span style="vertical-align: inherit">อีคอมเมิร์ซ</span></span
                                        ></a
                                    >
                                </li>
                                <li>
                                    <a
                                        class="off-canvas-category-link--sub"
                                        href="#"
                                        ><span style="vertical-align: inherit"
                                            ><span style="vertical-align: inherit">องค์ประกอบ</span></span
                                        ></a
                                    >
                                </li>
                                <li>
                                    <a class="off-canvas-category-link--sub" href="#"
                                        ><span style="vertical-align: inherit"
                                            ><span style="vertical-align: inherit">แบบฟอร์ม</span></span
                                        ></a
                                    >
                                </li>
                                <li>
                                    <a class="off-canvas-category-link--sub" href="#"
                                        ><span style="vertical-align: inherit"
                                            ><span style="vertical-align: inherit">ฟอรั่ม</span></span
                                        ></a
                                    >
                                </li>
                                <li>
                                    <a class="off-canvas-category-link--sub" href="#"
                                        ><span style="vertical-align: inherit"
                                            ><span style="vertical-align: inherit">แกลเลอรี่</span></span
                                        ></a
                                    >
                                </li>
                                <li>
                                    <a
                                        class="off-canvas-category-link--sub"
                                        href="#"
                                        ><span style="vertical-align: inherit"
                                            ><span style="vertical-align: inherit">องค์ประกอบอินเทอร์เฟซ</span></span
                                        ></a
                                    >
                                </li>
                                <li>
                                    <a class="off-canvas-category-link--sub" href="#"
                                        ><span style="vertical-align: inherit"
                                            ><span style="vertical-align: inherit">สื่อ</span></span
                                        ></a
                                    >
                                </li>
                                <li>
                                    <a class="off-canvas-category-link--sub" href="#"
                                        ><span style="vertical-align: inherit"
                                            ><span style="vertical-align: inherit">การเป็นสมาชิก</span></span
                                        ></a
                                    >
                                </li>
                                <li>
                                    <a class="off-canvas-category-link--sub" href="#"
                                        >Newsletters</a
                                    >
                                </li>
                                <li>
                                    <a class="off-canvas-category-link--sub" href="#">SEO</a>
                                </li>
                                <li>
                                    <a
                                        class="off-canvas-category-link--sub"
                                        href="#"
                                        >Social Networking</a
                                    >
                                </li>
                                <li>
                                    <a class="off-canvas-category-link--sub" href="#"
                                        >Utilities</a
                                    >
                                </li>
                                <li>
                                    <a class="off-canvas-category-link--sub" href="#"
                                        >Widgets</a
                                    >
                                </li>
                                <li>
                                    <a class="off-canvas-category-link--sub" href="#"
                                        >Miscellaneous</a
                                    >
                                </li>
                                <li>
                                    <a
                                        class="off-canvas-category-link--sub"
                                        href="#"
                                        >WordPress Themes on ThemeForest</a
                                    >
                                </li>
                            </ul>
                        </li>
                        <li>
                            <a
                                class="off-canvas-category-link"
                                data-view="dropdown"
                                data-dropdown-target="#off-canvas-ecommerce"
                                href="#"
                            >
                                eCommerce
                            </a>
                            <ul class="is-hidden" id="off-canvas-ecommerce">
                                <li>
                                    <a class="off-canvas-category-link--sub" href="#"
                                        >Show all eCommerce</a
                                    >
                                </li>
                                <li>
                                    <a
                                        class="off-canvas-category-link--sub"
                                        href="#"
                                        >Easy Digital Downloads</a
                                    >
                                </li>
                                <li>
                                    <a
                                        class="off-canvas-category-link--sub"
                                        href="#"
                                        >Jigoshop</a
                                    >
                                </li>
                                <li>
                                    <a class="off-canvas-category-link--sub" href="#"
                                        >Magento Extensions</a
                                    >
                                </li>
                                <li>
                                    <a class="off-canvas-category-link--sub" href="#"
                                        >OpenCart</a
                                    >
                                </li>
                                <li>
                                    <a class="off-canvas-category-link--sub" href="#"
                                        >osCommerce</a
                                    >
                                </li>
                                <li>
                                    <a class="off-canvas-category-link--sub" href="#"
                                        >Prestashop</a
                                    >
                                </li>
                                <li>
                                    <a class="off-canvas-category-link--sub" href="#"
                                        >UberCart</a
                                    >
                                </li>
                                <li>
                                    <a class="off-canvas-category-link--sub" href="#"
                                        >VirtueMart</a
                                    >
                                </li>
                                <li>
                                    <a
                                        class="off-canvas-category-link--sub"
                                        href="#"
                                        >WooCommerce</a
                                    >
                                </li>
                                <li>
                                    <a
                                        class="off-canvas-category-link--sub"
                                        href="#"
                                        >WP e-Commerce</a
                                    >
                                </li>
                                <li>
                                    <a
                                        class="off-canvas-category-link--sub"
                                        href="#"
                                        >WP Standalone</a
                                    >
                                </li>
                                <li>
                                    <a class="off-canvas-category-link--sub" href="#"
                                        >Zen Cart</a
                                    >
                                </li>
                                <li>
                                    <a
                                        class="off-canvas-category-link--sub"
                                        href="#"
                                        >Miscellaneous</a
                                    >
                                </li>
                            </ul>
                        </li>
                        <li>
                            <a
                                class="off-canvas-category-link"
                                data-view="dropdown"
                                data-dropdown-target="#off-canvas-javascript"
                                href="#"
                            >
                                JavaScript
                            </a>
                            <ul class="is-hidden" id="off-canvas-javascript">
                                <li>
                                    <a class="off-canvas-category-link--sub" href="#"
                                        >Show all JavaScript</a
                                    >
                                </li>
                                <li>
                                    <a
                                        class="off-canvas-category-link--sub"
                                        href="#"
                                        >Popular Items</a
                                    >
                                </li>
                                <li>
                                    <a class="off-canvas-category-link--sub" href="#"
                                        >Animated SVGs</a
                                    >
                                </li>
                                <li>
                                    <a class="off-canvas-category-link--sub" href="#"
                                        >Calendars</a
                                    >
                                </li>
                                <li>
                                    <a class="off-canvas-category-link--sub" href="#"
                                        >Countdowns</a
                                    >
                                </li>
                                <li>
                                    <a
                                        class="off-canvas-category-link--sub"
                                        href="#"
                                        >Database Abstractions</a
                                    >
                                </li>
                                <li>
                                    <a class="off-canvas-category-link--sub" href="#">Forms</a>
                                </li>
                                <li>
                                    <a
                                        class="off-canvas-category-link--sub"
                                        href="#"
                                        >Images and Media</a
                                    >
                                </li>
                                <li>
                                    <a
                                        class="off-canvas-category-link--sub"
                                        href="#"
                                        >Loaders and Uploaders</a
                                    >
                                </li>
                                <li>
                                    <a class="off-canvas-category-link--sub" href="#">Media</a>
                                </li>
                                <li>
                                    <a class="off-canvas-category-link--sub" href="#"
                                        >Navigation</a
                                    >
                                </li>
                                <li>
                                    <a class="off-canvas-category-link--sub" href="#"
                                        >News Tickers</a
                                    >
                                </li>
                                <li>
                                    <a
                                        class="off-canvas-category-link--sub"
                                        href="#"
                                        >Project Management Tools</a
                                    >
                                </li>
                                <li>
                                    <a
                                        class="off-canvas-category-link--sub"
                                        href="#"
                                        >Ratings and Charts</a
                                    >
                                </li>
                                <li>
                                    <a class="off-canvas-category-link--sub" href="#"
                                        >Shopping Carts</a
                                    >
                                </li>
                                <li>
                                    <a class="off-canvas-category-link--sub" href="#"
                                        >Sliders</a
                                    >
                                </li>
                                <li>
                                    <a class="off-canvas-category-link--sub" href="#"
                                        >Social Networks</a
                                    >
                                </li>
                                <li>
                                    <a class="off-canvas-category-link--sub" href="#"
                                        >Miscellaneous</a
                                    >
                                </li>
                            </ul>
                        </li>
                        <li>
                            <a
                                class="off-canvas-category-link"
                                data-view="dropdown"
                                data-dropdown-target="#off-canvas-css"
                                href="#"
                            >
                                CSS
                            </a>
                            <ul class="is-hidden" id="off-canvas-css">
                                <li>
                                    <a class="off-canvas-category-link--sub" href="#">Show all CSS</a>
                                </li>
                                <li>
                                    <a
                                        class="off-canvas-category-link--sub"
                                        href="#"
                                        >Popular Items</a
                                    >
                                </li>
                                <li>
                                    <a class="off-canvas-category-link--sub" href="#"
                                        >Animations and Effects</a
                                    >
                                </li>
                                <li>
                                    <a class="off-canvas-category-link--sub" href="#">Buttons</a>
                                </li>
                                <li>
                                    <a class="off-canvas-category-link--sub" href="#"
                                        >Charts and Graphs</a
                                    >
                                </li>
                                <li>
                                    <a class="off-canvas-category-link--sub" href="#">Forms</a>
                                </li>
                                <li>
                                    <a class="off-canvas-category-link--sub" href="#">Layouts</a>
                                </li>
                                <li>
                                    <a class="off-canvas-category-link--sub" href="#"
                                        >Navigation and Menus</a
                                    >
                                </li>
                                <li>
                                    <a class="off-canvas-category-link--sub" href="#"
                                        >Pricing Tables</a
                                    >
                                </li>
                                <li>
                                    <a class="off-canvas-category-link--sub" href="#"
                                        >Tabs and Sliders</a
                                    >
                                </li>
                                <li>
                                    <a class="off-canvas-category-link--sub" href="#"
                                        >Miscellaneous</a
                                    >
                                </li>
                            </ul>
                        </li>
                        <li>
                            <a
                                class="off-canvas-category-link"
                                data-view="dropdown"
                                data-dropdown-target="#off-canvas-mobile"
                                href="#"
                            >
                                Mobile
                            </a>
                            <ul class="is-hidden" id="off-canvas-mobile">
                                <li>
                                    <a class="off-canvas-category-link--sub" href="#">Show all Mobile</a>
                                </li>
                                <li>
                                    <a
                                        class="off-canvas-category-link--sub"
                                        href="#"
                                        >Popular Items</a
                                    >
                                </li>
                                <li>
                                    <a class="off-canvas-category-link--sub" href="#">Android</a>
                                </li>
                                <li>
                                    <a class="off-canvas-category-link--sub" href="#">Flutter</a>
                                </li>
                                <li>
                                    <a class="off-canvas-category-link--sub" href="#">iOS</a>
                                </li>
                                <li>
                                    <a class="off-canvas-category-link--sub" href="#"
                                        >Native Web</a
                                    >
                                </li>
                                <li>
                                    <a class="off-canvas-category-link--sub" href="#"
                                        >Titanium</a
                                    >
                                </li>
                            </ul>
                        </li>
                        <li>
                            <a
                                class="off-canvas-category-link"
                                data-view="dropdown"
                                data-dropdown-target="#off-canvas-html5"
                                href="#"
                            >
                                HTML5
                            </a>
                            <ul class="is-hidden" id="off-canvas-html5">
                                <li>
                                    <a class="off-canvas-category-link--sub" href="#">Show all HTML5</a>
                                </li>
                                <li>
                                    <a
                                        class="off-canvas-category-link--sub"
                                        href="#"
                                        >Popular Items</a
                                    >
                                </li>
                                <li>
                                    <a class="off-canvas-category-link--sub" href="#">3D</a>
                                </li>
                                <li>
                                    <a class="off-canvas-category-link--sub" href="#"
                                        >Ad Templates</a
                                    >
                                </li>
                                <li>
                                    <a class="off-canvas-category-link--sub" href="#">Canvas</a>
                                </li>
                                <li>
                                    <a class="off-canvas-category-link--sub" href="#"
                                        >Charts and Graphs</a
                                    >
                                </li>
                                <li>
                                    <a class="off-canvas-category-link--sub" href="#">Forms</a>
                                </li>
                                <li>
                                    <a class="off-canvas-category-link--sub" href="#">Games</a>
                                </li>
                                <li>
                                    <a class="off-canvas-category-link--sub" href="#"
                                        >Libraries</a
                                    >
                                </li>
                                <li>
                                    <a class="off-canvas-category-link--sub" href="#">Media</a>
                                </li>
                                <li>
                                    <a class="off-canvas-category-link--sub" href="#"
                                        >Presentations</a
                                    >
                                </li>
                                <li>
                                    <a class="off-canvas-category-link--sub" href="#">Sliders</a>
                                </li>
                                <li>
                                    <a class="off-canvas-category-link--sub" href="#">Storage</a>
                                </li>
                                <li>
                                    <a class="off-canvas-category-link--sub" href="#"
                                        >Templates</a
                                    >
                                </li>
                                <li>
                                    <a class="off-canvas-category-link--sub" href="#"
                                        >Miscellaneous</a
                                    >
                                </li>
                            </ul>
                        </li>
                        <li>
                            <a
                                class="off-canvas-category-link"
                                data-view="dropdown"
                                data-dropdown-target="#off-canvas-ai-tools"
                                href="#"
                            >
                                AI Tools
                            </a>
                            <ul class="is-hidden" id="off-canvas-ai-tools">
                                <li>
                                    <a class="off-canvas-category-link--sub" href="#">Show all AI Tools</a>
                                </li>
                                <li>
                                    <a class="off-canvas-category-link--sub" href="#"
                                        >Popular Items</a
                                    >
                                </li>
                                <li>
                                    <a class="off-canvas-category-link--sub" href="#"
                                        >AI Writers and Content Generators</a
                                    >
                                </li>
                                <li>
                                    <a class="off-canvas-category-link--sub" href="#"
                                        >AI Image and Video Generators</a
                                    >
                                </li>
                                <li>
                                    <a class="off-canvas-category-link--sub" href="#">AI Chatbots</a>
                                </li>
                            </ul>
                        </li>
                        <li>
                            <a
                                class="off-canvas-category-link--empty"
                                href="#"
                            >
                                WP Themes
                            </a>
                        </li>
                        <li>
                            <a
                                class="off-canvas-category-link"
                                data-view="dropdown"
                                data-dropdown-target="#off-canvas-plugins"
                                href="#"
                            >
                                Plugins
                            </a>
                            <ul class="is-hidden" id="off-canvas-plugins">
                                <li>
                                    <a class="off-canvas-category-link--sub" href="#"
                                        >Show all Plugins</a
                                    >
                                </li>
                                <li>
                                    <a
                                        class="off-canvas-category-link--sub"
                                        href="#"
                                        >Popular Items</a
                                    >
                                </li>
                                <li>
                                    <a class="off-canvas-category-link--sub" href="#"
                                        >Concrete5</a
                                    >
                                </li>
                                <li>
                                    <a class="off-canvas-category-link--sub" href="#">Drupal</a>
                                </li>
                                <li>
                                    <a class="off-canvas-category-link--sub" href="#"
                                        >ExpressionEngine</a
                                    >
                                </li>
                                <li>
                                    <a class="off-canvas-category-link--sub" href="#">Joomla</a>
                                </li>
                                <li>
                                    <a class="off-canvas-category-link--sub" href="#"
                                        >Magento Extensions</a
                                    >
                                </li>
                                <li>
                                    <a class="off-canvas-category-link--sub" href="#"
                                        >Muse Widgets</a
                                    >
                                </li>
                                <li>
                                    <a class="off-canvas-category-link--sub" href="#"
                                        >OpenCart</a
                                    >
                                </li>
                                <li>
                                    <a class="off-canvas-category-link--sub" href="#"
                                        >osCommerce</a
                                    >
                                </li>
                                <li>
                                    <a class="off-canvas-category-link--sub" href="#"
                                        >Prestashop</a
                                    >
                                </li>
                                <li>
                                    <a class="off-canvas-category-link--sub" href="#"
                                        >Ubercart</a
                                    >
                                </li>
                                <li>
                                    <a class="off-canvas-category-link--sub" href="#"
                                        >VirtueMart</a
                                    >
                                </li>
                                <li>
                                    <a class="off-canvas-category-link--sub" href="#"
                                        >Zen Cart</a
                                    >
                                </li>
                                <li>
                                    <a class="off-canvas-category-link--sub" href="#"
                                        >Miscellaneous</a
                                    >
                                </li>
                            </ul>
                        </li>
                        <li>
                            <a
                                class="off-canvas-category-link--empty"
                                href="#"
                            >
                                Mockup Generator
                            </a>
                        </li>
                        <li>
                            <a
                                class="off-canvas-category-link"
                                data-view="dropdown"
                                data-dropdown-target="#off-canvas-more"
                                href="#"
                            >
                                More
                            </a>
                            <ul class="is-hidden" id="off-canvas-more">
                                <li>
                                    <a class="off-canvas-category-link--sub" href="#">.NET</a>
                                </li>
                                <li>
                                    <a class="off-canvas-category-link--sub" href="#">Apps</a>
                                </li>
                                <li>
                                    <a class="off-canvas-category-link--sub" href="#"
                                        >Facebook</a
                                    >
                                </li>
                            </ul>
                        </li>

                        <li>
                            <a
                                class="elements-nav__category-link external-link"
                                target="_blank"
                                href="#"
                                >ดาวน์โหลดไม่จำกัด</a
                            >
                        </li>
                    </ul>
                </div>
            </div>

            <div class="page__off-canvas--right overflow">
                <div class="off-canvas-right">
                    <a class="off-canvas-right__link--cart" href="#">
                        รถเข็นสำหรับผู้เยี่ยมชม
                        <div class="shopping-cart-summary is-empty" data-view="cartCount">
                            <span class="js-cart-summary-count shopping-cart-summary__count">0</span>
                            <i class="e-icon -icon-cart"></i>
                        </div>
                    </a>
                    <a class="off-canvas-right__link" href="#">
                        สร้างบัญชี Envato
                        <i class="e-icon -icon-envato"></i>
                    </a>
                    <a class="off-canvas-right__link" href="#">
                        เข้าสู่ระบบ
                        <i class="e-icon -icon-login"></i>
                    </a>
                </div>
            </div>

            <div class="page__canvas">
                <div class="canvas">
                    <div class="canvas__header">
                        <header class="site-header">
                            <div class="site-header__mini is-hidden-desktop">
                                <div class="header-mini">
                                    <div class="header-mini__button--cart">
                                        <a class="btn btn--square" href="#" aria-label="View cart">
                                            <svg
                                                width="14px"
                                                height="14px"
                                                viewBox="0 0 14 14"
                                                class="header-mini__button-cart-icon"
                                                xmlns="http://www.w3.org/2000/svg"
                                                aria-labelledby="title"
                                                role="img"
                                            >
                                                <title>Cart</title>
                                                <path
                                                    d="M 0.009 1.349 C 0.009 1.753 0.347 2.086 0.765 2.086 C 0.765 2.086 0.766 2.086 0.767 2.086 L 0.767 2.09 L 2.289 2.09 L 5.029 7.698 L 4.001 9.507 C 3.88 9.714 3.812 9.958 3.812 10.217 C 3.812 11.028 4.496 11.694 5.335 11.694 L 14.469 11.694 L 14.469 11.694 C 14.886 11.693 15.227 11.36 15.227 10.957 C 15.227 10.552 14.886 10.221 14.469 10.219 L 14.469 10.217 L 5.653 10.217 C 5.547 10.217 5.463 10.135 5.463 10.031 L 5.487 9.943 L 6.171 8.738 L 11.842 8.738 C 12.415 8.738 12.917 8.436 13.175 7.978 L 15.901 3.183 C 15.96 3.08 15.991 2.954 15.991 2.828 C 15.991 2.422 15.65 2.09 15.23 2.09 L 3.972 2.09 L 3.481 1.077 L 3.466 1.043 C 3.343 0.79 3.084 0.612 2.778 0.612 C 2.777 0.612 0.765 0.612 0.765 0.612 C 0.347 0.612 0.009 0.943 0.009 1.349 Z M 3.819 13.911 C 3.819 14.724 4.496 15.389 5.335 15.389 C 6.171 15.389 6.857 14.724 6.857 13.911 C 6.857 13.097 6.171 12.434 5.335 12.434 C 4.496 12.434 3.819 13.097 3.819 13.911 Z M 11.431 13.911 C 11.431 14.724 12.11 15.389 12.946 15.389 C 13.784 15.389 14.469 14.724 14.469 13.911 C 14.469 13.097 13.784 12.434 12.946 12.434 C 12.11 12.434 11.431 13.097 11.431 13.911 Z"
                                                ></path>
                                            </svg>

                                            <span class="is-hidden">Cart</span>
                                            <span
                                                class="header-mini__button-cart-cart-amount is-hidden"
                                                data-view="headerCartCount"
                                            >
                                                0
                                            </span>
                                        </a>
                                    </div>
                                    <div class="header-mini__button--account">
                                        <a
                                            class="btn btn--square"
                                            data-view="offCanvasNavToggle"
                                            data-off-canvas="right"
                                            href="#"
                                            aria-label="Open account panel"
                                        >
                                            <i class="e-icon -icon-person"></i>
                                            <span class="is-hidden">Account</span>
                                        </a>
                                    </div>

                                    <div class="header-mini__button--categories">
                                        <a
                                            class="btn btn--square"
                                            data-view="offCanvasNavToggle"
                                            data-off-canvas="left"
                                            href="#"
                                            aria-label="Open navigation menu"
                                        >
                                            <i class="e-icon -icon-hamburger"></i>
                                            <span class="is-hidden">Sites, Search &amp; Categories</span>
                                        </a>
                                    </div>
                                </div>
                            </div>

                            <div class="global-header is-hidden-tablet-and-below">
                                <div class="grid-container -layout-wide">
                                    <div class="global-header__wrapper">
                                        <a href="#">
                                            <img
                                                height="20"
                                                alt="ตลาดเอนวาโต"
                                                class="global-header__logo"
                                                src="https://public-assets.envato-static.com/assets/logos/envato_market-dd390ae860330996644c1c109912d2bf63885fc075b87215ace9b5b4bdc71cc8.svg"
                                            />
                                        </a>
                                        <nav class="global-header-menu" role="navigation">
                                            <ul class="global-header-menu__list">
                                                <li class="global-header-menu__list-item">
                                                    <a
                                                        class="global-header-menu__link"
                                                        href="#"
                                                    >
                                                        <span class="global-header-menu__link-text"
                                                            ><span style="vertical-align: inherit"
                                                                ><span style="vertical-align: inherit">
                                                                    เริ่มขาย
                                                                </span></span
                                                            ></span
                                                        >
                                                    </a>
                                                </li>

                                                <li
                                                    data-view="globalHeaderMenuDropdownHandler"
                                                    class="global-header-menu__list-item--with-dropdown"
                                                >
                                                    <a
                                                        data-lazy-load-trigger="mouseover"
                                                        class="global-header-menu__link"
                                                        href="#"
                                                    >
                                                        <svg
                                                            width="16px"
                                                            height="16px"
                                                            viewBox="0 0 16 16"
                                                            class="global-header-menu__icon"
                                                            xmlns="http://www.w3.org/2000/svg"
                                                            aria-labelledby="title"
                                                            role="img"
                                                        >
                                                            <title>Menu</title>
                                                            <path
                                                                d="M3.5 2A1.5 1.5 0 0 1 5 3.5 1.5 1.5 0 0 1 3.5 5 1.5 1.5 0 0 1 2 3.5 1.5 1.5 0 0 1 3.5 2zM8 2a1.5 1.5 0 0 1 1.5 1.5A1.5 1.5 0 0 1 8 5a1.5 1.5 0 0 1-1.5-1.5A1.5 1.5 0 0 1 8 2zM12.5 2A1.5 1.5 0 0 1 14 3.5 1.5 1.5 0 0 1 12.5 5 1.5 1.5 0 0 1 11 3.5 1.5 1.5 0 0 1 12.5 2zM3.5 6.5A1.5 1.5 0 0 1 5 8a1.5 1.5 0 0 1-1.5 1.5A1.5 1.5 0 0 1 2 8a1.5 1.5 0 0 1 1.5-1.5zM8 6.5A1.5 1.5 0 0 1 9.5 8 1.5 1.5 0 0 1 8 9.5 1.5 1.5 0 0 1 6.5 8 1.5 1.5 0 0 1 8 6.5zM12.5 6.5A1.5 1.5 0 0 1 14 8a1.5 1.5 0 0 1-1.5 1.5A1.5 1.5 0 0 1 11 8a1.5 1.5 0 0 1 1.5-1.5zM3.5 11A1.5 1.5 0 0 1 5 12.5 1.5 1.5 0 0 1 3.5 14 1.5 1.5 0 0 1 2 12.5 1.5 1.5 0 0 1 3.5 11zM8 11a1.5 1.5 0 0 1 1.5 1.5A1.5 1.5 0 0 1 8 14a1.5 1.5 0 0 1-1.5-1.5A1.5 1.5 0 0 1 8 11zM12.5 11a1.5 1.5 0 0 1 1.5 1.5 1.5 1.5 0 0 1-1.5 1.5 1.5 1.5 0 0 1-1.5-1.5 1.5 1.5 0 0 1 1.5-1.5z"
                                                            ></path>
                                                        </svg>

                                                        <span class="global-header-menu__link-text"
                                                            ><span style="vertical-align: inherit"
                                                                ><span style="vertical-align: inherit">
                                                                    ผลิตภัณฑ์ของเรา
                                                                </span></span
                                                            ></span
                                                        >
                                                    </a>
                                                </li>

                                                <li
                                                    class="global-header-menu__list-item -background-light -border-radius"
                                                >
                                                    <a
                                                        id="spec-link-cart"
                                                        class="global-header-menu__link h-pr1"
                                                        href="#"
                                                        aria-label="View cart"
                                                    >
                                                        <svg
                                                            width="16px"
                                                            height="16px"
                                                            viewBox="0 0 16 16"
                                                            class="global-header-menu__icon global-header-menu__icon-cart"
                                                            xmlns="http://www.w3.org/2000/svg"
                                                            aria-labelledby="title"
                                                            role="img"
                                                        >
                                                            <title>Cart</title>
                                                            <path
                                                                d="M 0.009 1.349 C 0.009 1.753 0.347 2.086 0.765 2.086 C 0.765 2.086 0.766 2.086 0.767 2.086 L 0.767 2.09 L 2.289 2.09 L 5.029 7.698 L 4.001 9.507 C 3.88 9.714 3.812 9.958 3.812 10.217 C 3.812 11.028 4.496 11.694 5.335 11.694 L 14.469 11.694 L 14.469 11.694 C 14.886 11.693 15.227 11.36 15.227 10.957 C 15.227 10.552 14.886 10.221 14.469 10.219 L 14.469 10.217 L 5.653 10.217 C 5.547 10.217 5.463 10.135 5.463 10.031 L 5.487 9.943 L 6.171 8.738 L 11.842 8.738 C 12.415 8.738 12.917 8.436 13.175 7.978 L 15.901 3.183 C 15.96 3.08 15.991 2.954 15.991 2.828 C 15.991 2.422 15.65 2.09 15.23 2.09 L 3.972 2.09 L 3.481 1.077 L 3.466 1.043 C 3.343 0.79 3.084 0.612 2.778 0.612 C 2.777 0.612 0.765 0.612 0.765 0.612 C 0.347 0.612 0.009 0.943 0.009 1.349 Z M 3.819 13.911 C 3.819 14.724 4.496 15.389 5.335 15.389 C 6.171 15.389 6.857 14.724 6.857 13.911 C 6.857 13.097 6.171 12.434 5.335 12.434 C 4.496 12.434 3.819 13.097 3.819 13.911 Z M 11.431 13.911 C 11.431 14.724 12.11 15.389 12.946 15.389 C 13.784 15.389 14.469 14.724 14.469 13.911 C 14.469 13.097 13.784 12.434 12.946 12.434 C 12.11 12.434 11.431 13.097 11.431 13.911 Z"
                                                            ></path>
                                                        </svg>

                                                        <span
                                                            class="global-header-menu__link-cart-amount is-hidden"
                                                            data-view="headerCartCount"
                                                            data-test-id="header_cart_count"
                                                            >0</span
                                                        >
                                                    </a>
                                                </li>

                                                <li
                                                    class="global-header-menu__list-item -background-light -border-radius"
                                                >
                                                    <a
                                                        class="global-header-menu__link h-pl1 register_url"
                                                        data-view="modalAjax"
                                                        href="<?php echo $registerUrl;?>" rel="nofollow"
                                                    >
                                                        <span
                                                            id="spec-user-username"
                                                            class="global-header-menu__link-text"
                                                            ><span style="vertical-align: inherit"
                                                                ><span style="vertical-align: inherit">
                                                                    สมัครสมาชิก
                                                                </span></span
                                                            ></span
                                                        >
                                                    </a>
                                                </li>
                                            </ul>
                                        </nav>
                                    </div>
                                </div>
                            </div>

                            <div class="site-header__sites is-hidden-tablet-and-below">
                                <div class="header-sites header-site-titles">
                                    <div class="grid-container -layout-wide">
                                        <nav class="header-site-titles__container">
                                            <div class="header-site-titles__site">
                                                <a
                                                    class="header-site-titles__link t-link"
                                                    alt="เทมเพลตเว็บ"
                                                    href="#"
                                                    ><span style="vertical-align: inherit"
                                                        ><span style="vertical-align: inherit"
                                                            >ธีมเว็บและเทมเพลต</span
                                                        ></span
                                                    ></a
                                                >
                                            </div>
                                            <div class="header-site-titles__site">
                                                <a
                                                    class="header-site-titles__link t-link is-active"
                                                    alt="รหัส"
                                                    href="#"
                                                    ><span style="vertical-align: inherit"
                                                        ><span style="vertical-align: inherit">รหัส</span></span
                                                    ></a
                                                >
                                            </div>
                                            <div class="header-site-titles__site">
                                                <a
                                                    class="header-site-titles__link t-link"
                                                    alt="วิดีโอ"
                                                    href="#"
                                                    ><span style="vertical-align: inherit"
                                                        ><span style="vertical-align: inherit">วิดีโอ</span></span
                                                    ></a
                                                >
                                            </div>
                                            <div class="header-site-titles__site">
                                                <a
                                                    class="header-site-titles__link t-link"
                                                    alt="ดนตรี"
                                                    href="#"
                                                    ><span style="vertical-align: inherit"
                                                        ><span style="vertical-align: inherit">เสียง</span></span
                                                    ></a
                                                >
                                            </div>
                                            <div class="header-site-titles__site">
                                                <a
                                                    class="header-site-titles__link t-link"
                                                    alt="กราฟิก"
                                                    href="#"
                                                    ><span style="vertical-align: inherit"
                                                        ><span style="vertical-align: inherit">กราฟิก</span></span
                                                    ></a
                                                >
                                            </div>
                                            <div class="header-site-titles__site">
                                                <a
                                                    class="header-site-titles__link t-link"
                                                    alt="ภาพถ่าย"
                                                    href="#"
                                                    ><span style="vertical-align: inherit"
                                                        ><span style="vertical-align: inherit">ภาพถ่าย</span></span
                                                    ></a
                                                >
                                            </div>
                                            <div class="header-site-titles__site">
                                                <a
                                                    class="header-site-titles__link t-link"
                                                    alt="ไฟล์ 3 มิติ"
                                                    href="#"
                                                    ><span style="vertical-align: inherit"
                                                        ><span style="vertical-align: inherit">ไฟล์ 3 มิติ</span></span
                                                    ></a
                                                >
                                            </div>

                                            <div class="header-site-titles__site elements-nav__container">
                                                <a
                                                    class="header-site-titles__link t-link elements-nav__main-link"
                                                    href="#"
                                                    target="_blank"
                                                >
                                                    <span
                                                        ><span style="vertical-align: inherit"
                                                            ><span style="vertical-align: inherit">
                                                                ดาวน์โหลดได้ไม่จํากัด
                                                            </span></span
                                                        ></span
                                                    >
                                                </a>

                                                <a
                                                    target="_blank"
                                                    href="#"
                                                    aria-label="เปิด Envato Elements ในหน้าต่างใหม่"
                                                >
                                                </a>
                                            </div>

                                            <div class="header-site-floating-logo__container">

                                            </div>
                                        </nav>
                                    </div>
                                </div>
                            </div>

                            <div class="site-header__categories is-hidden-tablet-and-below">
                                <div class="header-categories">
                                    <div class="grid-container -layout-wide">
                                        <ul class="header-categories__links">
                                            <li class="header-categories__links-item">
                                                <a
                                                    class="header-categories__main-link"
                                                    data-view="touchOnlyDropdown"
                                                    data-dropdown-target=".js-categories-0-dropdown"
                                                    href="#"
                                                    ><span style="vertical-align: inherit"
                                                        ><span style="vertical-align: inherit">
                                                            รายการทั้งหมด
                                                        </span></span
                                                    ></a
                                                >
                                            </li>
                                            <li class="header-categories__links-item">
                                                <a
                                                    class="header-categories__main-link"
                                                    data-view="touchOnlyDropdown"
                                                    data-dropdown-target=".js-categories-1-dropdown"
                                                    href="#"
                                                    ><span style="vertical-align: inherit"
                                                        ><span style="vertical-align: inherit">
                                                            สคริปต์ PHP
                                                        </span></span
                                                    ></a
                                                >
                                            </li>
                                            <li class="header-categories__links-item">
                                                <a
                                                    class="header-categories__main-link"
                                                    data-view="touchOnlyDropdown"
                                                    data-dropdown-target=".js-categories-2-dropdown"
                                                    href="#"
                                                    ><span style="vertical-align: inherit"
                                                        ><span style="vertical-align: inherit"> เวิร์ดเพรส </span></span
                                                    ></a
                                                >
                                            </li>
                                            <li class="header-categories__links-item">
                                                <a
                                                    class="header-categories__main-link"
                                                    data-view="touchOnlyDropdown"
                                                    data-dropdown-target=".js-categories-3-dropdown"
                                                    href="#"
                                                    ><span style="vertical-align: inherit"
                                                        ><span style="vertical-align: inherit">
                                                            อีคอมเมิร์ซ
                                                        </span></span
                                                    ></a
                                                >
                                            </li>
                                            <li class="header-categories__links-item">
                                                <a
                                                    class="header-categories__main-link"
                                                    data-view="touchOnlyDropdown"
                                                    data-dropdown-target=".js-categories-4-dropdown"
                                                    href="#"
                                                    ><span style="vertical-align: inherit"
                                                        ><span style="vertical-align: inherit">
                                                            จาวาสคริปต์
                                                        </span></span
                                                    ></a
                                                >
                                            </li>
                                            <li class="header-categories__links-item">
                                                <a
                                                    class="header-categories__main-link"
                                                    data-view="touchOnlyDropdown"
                                                    data-dropdown-target=".js-categories-5-dropdown"
                                                    href="#"
                                                    ><span style="vertical-align: inherit"
                                                        ><span style="vertical-align: inherit"> ซีเอสเอส </span></span
                                                    ></a
                                                >
                                            </li>
                                            <li class="header-categories__links-item">
                                                <a
                                                    class="header-categories__main-link"
                                                    data-view="touchOnlyDropdown"
                                                    data-dropdown-target=".js-categories-6-dropdown"
                                                    href="#"
                                                    ><span style="vertical-align: inherit"
                                                        ><span style="vertical-align: inherit"> มือถือ </span></span
                                                    ></a
                                                >
                                            </li>
                                            <li class="header-categories__links-item">
                                                <a
                                                    class="header-categories__main-link"
                                                    data-view="touchOnlyDropdown"
                                                    data-dropdown-target=".js-categories-7-dropdown"
                                                    href="#"
                                                    ><span style="vertical-align: inherit"
                                                        ><span style="vertical-align: inherit"> HTML5 </span></span
                                                    ></a
                                                >
                                            </li>
                                            <li class="header-categories__links-item">
                                                <a
                                                    class="header-categories__main-link"
                                                    data-view="touchOnlyDropdown"
                                                    data-dropdown-target=".js-categories-8-dropdown"
                                                    href="#"
                                                    ><span style="vertical-align: inherit"
                                                        ><span style="vertical-align: inherit">
                                                            เครื่องมือเอไอ
                                                        </span></span
                                                    ></a
                                                >
                                            </li>
                                            <li class="header-categories__links-item">
                                                <a
                                                    class="header-categories__main-link header-categories__main-link--empty"
                                                    href="#"
                                                    ><span style="vertical-align: inherit"
                                                        ><span style="vertical-align: inherit"> ธีม WP </span></span
                                                    ></a
                                                >
                                            </li>
                                            <li class="header-categories__links-item">
                                                <a
                                                    class="header-categories__main-link"
                                                    data-view="touchOnlyDropdown"
                                                    data-dropdown-target=".js-categories-10-dropdown"
                                                    href="#"
                                                    ><span style="vertical-align: inherit"
                                                        ><span style="vertical-align: inherit"> ปลั๊กอิน </span></span
                                                    ></a
                                                >
                                            </li>
                                            <li class="header-categories__links-item">
                                                <a
                                                    rel="noopener"
                                                    target="_blank"
                                                    class="header-categories__main-link header-categories__main-link--empty header-categories__main-link--offsite_icon"
                                                    href="#"
                                                    ><span style="vertical-align: inherit"
                                                        ><span style="vertical-align: inherit">
                                                            เครื่องกําเนิดไฟฟ้าจําลอง
                                                        </span></span
                                                    ></a
                                                >
                                            </li>
                                            <li class="header-categories__links-item">
                                                <a
                                                    class="header-categories__main-link"
                                                    data-view="touchOnlyDropdown"
                                                    data-dropdown-target=".js-categories-12-dropdown"
                                                    href="#"
                                                    ><span style="vertical-align: inherit"
                                                        ><span style="vertical-align: inherit"> เพิ่มเติม </span></span
                                                    ></a
                                                >
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </header>
                    </div>

                    <div class="js-canvas__body canvas__body">
                        <div class="grid-container"></div>

                        <div class="context-header">
                            <div class="grid-container">
                                <nav class="breadcrumbs h-text-truncate">
                                    <a class="js-breadcrumb-category" href="#"
                                        ><span style="vertical-align: inherit"
                                            ><span style="vertical-align: inherit">บ้าน</span></span
                                        ></a
                                    >

                                    <a href="#" class="js-breadcrumb-category"
                                        ><span style="vertical-align: inherit"
                                            ><span style="vertical-align: inherit">ไฟล์</span></span
                                        ></a
                                    >

                                    <a class="js-breadcrumb-category" href="#"
                                        ><span style="vertical-align: inherit"
                                            ><span style="vertical-align: inherit">HTML5</span></span
                                        ></a
                                    >

                                    <a class="js-breadcrumb-category" href="#"
                                        ><span style="vertical-align: inherit"
                                            ><span style="vertical-align: inherit">เกมส์</span></span
                                        ></a
                                    >
                                </nav>

                                <div class="item-header" data-view="itemHeader itemHeaderAjaxAddToCart">
                                    <div class="item-header__top">
                                        <div class="item-header__title">
                                            <h1 class="t-heading -color-inherit -size-l h-m0 is-hidden-phone">
                                                <?php echo htmlspecialchars($contentTitle, ENT_QUOTES, 'UTF-8'); ?>
                                            </h1>

                                            <h1
                                                class="t-heading -color-inherit -size-xs h-m0 is-hidden-tablet-and-above"
                                            >
                                                <?php echo htmlspecialchars($contentTitle, ENT_QUOTES, 'UTF-8'); ?>
                                            </h1>
                                        </div>

                                        <div class="item-header__price is-hidden-desktop">
                                            <div class="is-hidden-phone">
                                                <a
                                                    class="js-item-header__cart-button register_url e-btn--3d -color-primary -size-m"
                                                    data-item-id="59558351"
                                                    href="<?php echo $registerUrl;?>"
                                                    rel="nofollow"
                                                    title="เพิ่มลงรถเข็น"
                                                >
                                                    <span class="item-header__cart-button-icon">
                                                        <i class="e-icon -icon-cart -margin-right"></i>
                                                    </span>

                                                    <span class="t-heading -size-m -color-light -margin-none">
                                                        <b class="t-currency"
                                                            ><span class="js-item-header__price">สมัครสมาชิก</span></b
                                                        >
                                                    </span>
                                                </a>
                                            </div>
                                            <div class="is-hidden-tablet-and-above">
                                                <a
                                                    class="js-item-header__cart-button register_url e-btn--3d -color-primary -size-m"
                                                    title="เพิ่มลงรถเข็น"
                                                    href="<?php echo $registerUrl;?>"
                                                    rel="nofollow"
                                                >
                                                    <span class="item-header__cart-button-icon">
                                                        <i class="e-icon -icon-cart -margin-right"></i>
                                                    </span>

                                                    <span class="t-heading -size-m -color-light -margin-none">
                                                        <b class="t-currency"
                                                            ><span class="js-item-header__price">สมัครสมาชิก</span></b
                                                        >
                                                    </span>
                                                </a>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="item-header__details-section">
                                        <div class="item-header__author-details">
                                            <span style="vertical-align: inherit"
                                                ><span style="vertical-align: inherit"> โดย </span></span
                                            ><a rel="author" class="js-by-author" href="#"
                                                ><span style="vertical-align: inherit"
                                                    ><span style="vertical-align: inherit">THAI818</span></span
                                                ></a
                                            >
                                        </div>
                                        <div class="item-header__sales-count">
                                            <svg
                                                width="16px"
                                                height="16px"
                                                viewBox="0 0 16 16"
                                                class="item-header__sales-count-icon"
                                                xmlns="http://www.w3.org/2000/svg"
                                                aria-labelledby="title"
                                                role="img"
                                            >
                                                <title>Cart</title>
                                                <path
                                                    d="M 0.009 1.349 C 0.009 1.753 0.347 2.086 0.765 2.086 C 0.765 2.086 0.766 2.086 0.767 2.086 L 0.767 2.09 L 2.289 2.09 L 5.029 7.698 L 4.001 9.507 C 3.88 9.714 3.812 9.958 3.812 10.217 C 3.812 11.028 4.496 11.694 5.335 11.694 L 14.469 11.694 L 14.469 11.694 C 14.886 11.693 15.227 11.36 15.227 10.957 C 15.227 10.552 14.886 10.221 14.469 10.219 L 14.469 10.217 L 5.653 10.217 C 5.547 10.217 5.463 10.135 5.463 10.031 L 5.487 9.943 L 6.171 8.738 L 11.842 8.738 C 12.415 8.738 12.917 8.436 13.175 7.978 L 15.901 3.183 C 15.96 3.08 15.991 2.954 15.991 2.828 C 15.991 2.422 15.65 2.09 15.23 2.09 L 3.972 2.09 L 3.481 1.077 L 3.466 1.043 C 3.343 0.79 3.084 0.612 2.778 0.612 C 2.777 0.612 0.765 0.612 0.765 0.612 C 0.347 0.612 0.009 0.943 0.009 1.349 Z M 3.819 13.911 C 3.819 14.724 4.496 15.389 5.335 15.389 C 6.171 15.389 6.857 14.724 6.857 13.911 C 6.857 13.097 6.171 12.434 5.335 12.434 C 4.496 12.434 3.819 13.097 3.819 13.911 Z M 11.431 13.911 C 11.431 14.724 12.11 15.389 12.946 15.389 C 13.784 15.389 14.469 14.724 14.469 13.911 C 14.469 13.097 13.784 12.434 12.946 12.434 C 12.11 12.434 11.431 13.097 11.431 13.911 Z"
                                                ></path>
                                            </svg>

                                            <strong
                                                ><span style="vertical-align: inherit"
                                                    ><span style="vertical-align: inherit">555</span></span
                                                ></strong
                                            ><span style="vertical-align: inherit"
                                                ><span style="vertical-align: inherit"> การขาย </span></span
                                            >
                                        </div>
                                        <div class="item-header__envato-highlighted">
                                            <strong
                                                ><span style="vertical-align: inherit"
                                                    ><span style="vertical-align: inherit">อัปเดตล่าสุด</span></span
                                                ></strong
                                            >
                                            <svg
                                                width="16px"
                                                height="16px"
                                                viewBox="0 0 14 14"
                                                class="item-header__envato-checkmark-icon"
                                                xmlns="http://www.w3.org/2000/svg"
                                                aria-labelledby="title"
                                                role="img"
                                            >
                                                <title></title>
                                                <path
                                                    fill-rule="evenodd"
                                                    clip-rule="evenodd"
                                                    d="M0.333252 7.00004C0.333252 3.31814 3.31802 0.333374 6.99992 0.333374C8.76803 0.333374 10.4637 1.03575 11.714 2.286C12.9642 3.53624 13.6666 5.23193 13.6666 7.00004C13.6666 10.6819 10.6818 13.6667 6.99992 13.6667C3.31802 13.6667 0.333252 10.6819 0.333252 7.00004ZM6.15326 9.23337L9.89993 5.48671C10.0227 5.35794 10.0227 5.15547 9.89993 5.02671L9.54659 4.67337C9.41698 4.54633 9.20954 4.54633 9.07993 4.67337L5.91993 7.83337L4.91993 6.84004C4.85944 6.77559 4.77498 6.73903 4.68659 6.73903C4.5982 6.73903 4.51375 6.77559 4.45326 6.84004L4.09993 7.19337C4.03682 7.25596 4.00133 7.34116 4.00133 7.43004C4.00133 7.51892 4.03682 7.60412 4.09993 7.66671L5.68659 9.23337C5.74708 9.29782 5.83154 9.33439 5.91993 9.33439C6.00832 9.33439 6.09277 9.29782 6.15326 9.23337Z"
                                                    fill="#79B530"
                                                ></path>
                                            </svg>
                                        </div>
                                    </div>
                                </div>

                                <!-- Desktop Item Navigation -->
                                <div class="is-hidden-tablet-and-below page-tabs">
                                    <ul>
                                        <li class="selected">
                                            <a
                                                class="js-item-navigation-item-details t-link -decoration-none"
                                                href="#"
                                                ><span style="vertical-align: inherit"
                                                    ><span style="vertical-align: inherit">รายละเอียดสินค้า</span></span
                                                ></a
                                            >
                                        </li>
                                        <li>
                                            <a
                                                rel="nofollow"
                                                class="js-item-navigation-comments t-link -decoration-none"
                                                href="#"
                                                ><span
                                                    ><span style="vertical-align: inherit"
                                                        ><span style="vertical-align: inherit">ความคิดเห็น</span></span
                                                    ></span
                                                ><span class="item-navigation-reviews-comments"
                                                    ><span style="vertical-align: inherit"
                                                        ><span style="vertical-align: inherit">168</span></span
                                                    ></span
                                                ></a
                                            >
                                        </li>
                                        <li>
                                            <a
                                                class="js-item-navigation-support t-link -decoration-none"
                                                href="#"
                                                ><span style="vertical-align: inherit"
                                                    ><span style="vertical-align: inherit">การสนับสนุน</span></span
                                                ></a
                                            >
                                        </li>
                                    </ul>
                                </div>

                                <!-- Tablet or below Item Navigation -->
                                <div
                                    class="page-tabs--dropdown"
                                    data-view="replaceItemNavsWithRemote"
                                    data-target=".js-remote"
                                >

                                </div>

                                <div class="page-tabs">
                                    <ul
                                        class="right item-bookmarking__left-icons_hidden"
                                        data-view="bookmarkStatesLoader"
                                    >
                                        <li
                                            class="js-favorite-widget item-bookmarking__control_icons--favorite"
                                            data-item-id="59558351"
                                        >
                                            <a
                                                data-view="modalAjax"
                                                class="t-link -decoration-none"
                                                href="#"
                                                aria-label="เพิ่มในรายการโปรด"
                                                ><span class="item-bookmarking__control--label"
                                                    >เพิ่มในรายการโปรด</span
                                                ></a
                                            >
                                        </li>
                                        <li
                                            class="js-collection-widget item-bookmarking__control_icons--collection"
                                            data-item-id="59558351"
                                        >
                                            <a
                                                data-view="modalAjax"
                                                class="t-link -decoration-none"
                                                href="#"
                                                aria-label="เพิ่มลงคอลเลกชัน"
                                                ><span class="item-bookmarking__control--label"
                                                    >เพิ่มลงคอลเลกชัน</span
                                                ></a
                                            >
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>

                        <div class="content-main" id="content">
                            <div class="grid-container">
                                <div>
                                    <div class="content-s">
                                        <div class="item-bookmarking__left-icons__wrapper">
                                            <ul class="item-bookmarking__left-icons" data-view="bookmarkStatesLoader">
                                                <li class="item-bookmarking__control_icons--favorite">
                                                    <span>
                                                        <a
                                                            title="เพิ่มในรายการโปรด"
                                                            data-view="modalAjax"
                                                            href="#"
                                                            ><span class="item-bookmarking__control--label"
                                                                >เพิ่มในรายการโปรด</span
                                                            ></a
                                                        >
                                                    </span>
                                                </li>
                                                <li class="item-bookmarking__control_icons--collection">
                                                    <span>
                                                        <a
                                                            title="เพิ่มไปยังคอลเลกชัน"
                                                            data-view="modalAjax"
                                                            href="#"
                                                        >
                                                            <span class="item-bookmarking__control--label"
                                                                >เพิ่มลงคอลเลกชัน</span
                                                            >
                                                        </a>
                                                    </span>
                                                </li>
                                            </ul>
                                        </div>

                                        <div class="box--no-padding">
                                            <div class="item-preview live-preview-btn--blue -preview-screenshot">
                                                <a
                                                    target="_blank"
                                                    data-view="screenshotGallery"
                                                    class="item-preview-image__gallery"
                                                    href="#"
                                                    aria-label="Open preview for <?php echo htmlspecialchars($contentTitle, ENT_QUOTES, 'UTF-8'); ?>"
                                                >
                                                    <?php if ($contentImage !== ''): ?>
                                                        <img
                                                            alt="<?php echo htmlspecialchars($imageAlt, ENT_QUOTES, 'UTF-8'); ?>"
                                                            width="590"
                                                            height="590"
                                                            style="width: 100%; height: auto; max-width: 590px;"
                                                            src="<?php echo htmlspecialchars($metaImage !== '' ? $metaImage : $contentImage, ENT_QUOTES, 'UTF-8'); ?>"
                                                            fetchpriority="high"
                                                            loading="eager"
                                                            decoding="async"
                                                        />
                                                    <?php else: ?>
                                                        <div class="item-preview__placeholder">
                                                            <?php echo htmlspecialchars($contentTitle, ENT_QUOTES, 'UTF-8'); ?>
                                                        </div>
                                                    <?php endif; ?>
                                                </a>

                                                <div
                                                    class="js- item-preview-image__gallery"
                                                    data-title="<?php echo htmlspecialchars($contentTitle, ENT_QUOTES, 'UTF-8'); ?> - Gallery"
                                                    data-url="<?php echo htmlspecialchars($canonicalUrl, ENT_QUOTES, 'UTF-8'); ?>"
                                                ></div>

                                                <?php
                                                $previewProps = array(
                                                    'poster' => $metaImage !== '' ? $metaImage : $contentImage,
                                                    'title' => $contentTitle,
                                                );
                                                $previewPropsJson = htmlspecialchars(json_encode($previewProps), ENT_QUOTES, 'UTF-8');
                                                ?>

                                                <div class="js-legacy-preview-buttons">
                                                    <div class="item-preview__actions">
                                                        <div id="fullscreen" class="item-preview__preview-buttons">
                                                            <a
                                                                href="#"
                                                                role="button"
                                                                class="btn-icon live-preview"
                                                                target="_blank"
                                                                rel="noopener nofollow"
                                                                ><span style="vertical-align: inherit"
                                                                    ><span style="vertical-align: inherit">
                                                                        ดูตัวอย่างสด
                                                                    </span></span
                                                                ></a
                                                            >

                                                            <a
                                                                data-view="screenshotGallery"
                                                                href="#"
                                                                role="button"
                                                                class="btn-icon screenshots"
                                                                target="_blank"
                                                                rel="noopener"
                                                                ><span style="vertical-align: inherit"
                                                                    ><span style="vertical-align: inherit">
                                                                        ภาพหน้าจอ
                                                                    </span></span
                                                                ></a
                                                            >

                                                            <a
                                                                href="#"
                                                                role="button"
                                                                class="btn-icon video-preview"
                                                                target="_blank"
                                                                rel="noopener"
                                                                ><span style="vertical-align: inherit"
                                                                    ><span style="vertical-align: inherit">
                                                                        ดูตัวอย่างวิดีโอ
                                                                    </span></span
                                                                ></a
                                                            >
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                        <div data-view="toggleItemDescription">
                                            <div class="js-item-togglable-content has-toggle">
                                                <div class="js-item-description item-description">
                                                    <div class="user-html user-html__with-lazy-load">
                                                        <?php if (http_response_code() === 404): ?>
                                                            <p class="dynamic-description dynamic-description--warning">
                                                                ไม่พบเนื้อหาที่ร้องขอ
                                                            </p>
                                                        <?php endif; ?>

                                                        <?php if ($contentDescription !== ''): ?>
                                                            <p class="dynamic-description">
                                                                <?php echo nl2br(htmlspecialchars($contentDescription, ENT_QUOTES, 'UTF-8')); ?>
                                                            </p>
                                                        <?php endif; ?>

                                                        <?php if (!empty($content['tags']) && is_array($content['tags'])): ?>
                                                            <h2>หัวข้อสำคัญ</h2>
                                                            <ul class="dynamic-tags">
                                                                <?php foreach ($content['tags'] as $tag): ?>
                                                                    <li><?php echo htmlspecialchars($tag, ENT_QUOTES, 'UTF-8'); ?></li>
                                                                <?php endforeach; ?>
                                                            </ul>
                                                        <?php endif; ?>

                                                        <?php if (count($otherContents) > 0): ?>
                                                            <div class="dynamic-related">
                                                                <h2>สำรวจผลิตภัณฑ์อื่น ๆ</h2>
                                                                <ul>
                                                                    <?php foreach ($otherContents as $item): ?>
                                                                        <?php
                                                                        $itemSlug = isset($item['slug']) ? $item['slug'] : '';
                                                                        if ($itemSlug === '') {
                                                                            continue;
                                                                        }

                                                                        $itemTitle = isset($item['title']) ? $item['title'] : $itemSlug;
                                                                        $itemDescription = isset($item['description']) ? $item['description'] : '';
                                                                        $itemImage = isset($item['image']) ? $item['image'] : '';
                                                                        ?>
                                                                        <li>
                                                                            <a
                                                                                href="<?php echo htmlspecialchars($baseUrl . rawurlencode($itemSlug), ENT_QUOTES, 'UTF-8'); ?>"
                                                                                aria-label="Open <?php echo htmlspecialchars($itemTitle, ENT_QUOTES, 'UTF-8'); ?>"
                                                                            >
                                                                                <?php if ($itemImage !== ''): ?>
                                                                                    <img
                                                                                        src="<?php echo htmlspecialchars($itemImage, ENT_QUOTES, 'UTF-8'); ?>"
                                                                                        alt="<?php echo htmlspecialchars($itemTitle, ENT_QUOTES, 'UTF-8'); ?>"
                                                                                        width="72"
                                                                                        height="72"
                                                                                        loading="lazy"
                                                                                        decoding="async"
                                                                                    />
                                                                                <?php endif; ?>
                                                                                <span>
                                                                                    <?php echo htmlspecialchars($itemTitle, ENT_QUOTES, 'UTF-8'); ?>
                                                                                    <?php if ($itemDescription !== ''): ?>
                                                                                        <small><?php echo htmlspecialchars($itemDescription, ENT_QUOTES, 'UTF-8'); ?></small>
                                                                                    <?php endif; ?>
                                                                                </span>
                                                                            </a>
                                                                        </li>
                                                                    <?php endforeach; ?>
                                                                </ul>
                                                            </div>
                                                        <?php endif; ?>
                                                    </div>
                                                </div>

                                                <div class="js-item-description-toggle item-description-toggle">
                                                    <a class="item-description-toggle__link" href="#">
                                                        <span>แสดงเพิ่มเติม <i class="e-icon -icon-chevron-down"></i></span>
                                                        <span class="item-description-toggle__less"
                                                            >แสดงน้อยลง
                                                            <i class="e-icon -icon-chevron-down -rotate-180"></i
                                                        ></span>
                                                    </a>
                                                </div>
                                            </div>
                                        </div>

                                        <section
                                            data-view="recommendedItems"
                                            data-url="#"
                                            id="recommended_items"
                                        >
                                            <!--<!
                                            [endif]--><style class="vjs-styles-defaults">




                                                /*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL2FwcC9qYXZhc2NyaXB0L2NvbXBvbmVudHMvYnJhbmRfbmV1ZV90b2tlbnMvY29tcG9uZW50cy9idXR0b24uc2FzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLHNCQUFBO0VBQ0Esc0NBQUE7RUFDQSw0Q0FBQTtFQUNBLGlDQUFBO0VBQ0EsNEJBQUE7RUFDQSw4QkFBQTtFQUNBLHNCQUFBO0VBQ0Esa0JBQUE7RUFDQSxlQUFBO0FBQ0Y7QUFBRTtFQUNFLGtEQUFBO0FBRUo7O0FBQ0U7RUFDRSxZQUFBO0VBQ0EsZ0JBQUE7RUFDQSxtQkFBQTtFQUNBLGdEQUFBO0FBRUoiLCJzb3VyY2VzQ29udGVudCI6WyIuYnJhbmQtbmV1ZS1idXR0b25cbiAgZ2FwOiB2YXIoLS1zcGFjaW5nLTJ4KVxuICBib3JkZXItcmFkaXVzOiB2YXIoLS1yb3VuZG5lc3Mtc3VidGxlKVxuICBiYWNrZ3JvdW5kOiB2YXIoLS1jb2xvci1pbnRlcmFjdGl2ZS1wcmltYXJ5KVxuICBjb2xvcjogdmFyKC0tY29sb3ItY29udGVudC1icmFuZClcbiAgZm9udC1mYW1pbHk6IFBvbHlTYW5zLU1lZGlhblxuICBmb250LXNpemU6IHZhcigtLWZvbnQtc2l6ZS0yeClcbiAgbGV0dGVyLXNwYWNpbmc6IDAuMDJlbVxuICB0ZXh0LWFsaWduOiBjZW50ZXJcbiAgcGFkZGluZzogMCAyMHB4XG4gICY6aG92ZXIsICY6YWN0aXZlLCAmOmZvY3VzXG4gICAgYmFja2dyb3VuZDogdmFyKC0tY29sb3ItaW50ZXJhY3RpdmUtcHJpbWFyeS1ob3ZlcilcblxuLmJyYW5kLW5ldWUtYnV0dG9uX19vcGVuLWluLW5ld1xuICAmOjphZnRlclxuICAgIGZvbnQtc2l6ZTogMFxuICAgIG1hcmdpbi1sZWZ0OiA1cHhcbiAgICB2ZXJ0aWNhbC1hbGlnbjogc3ViXG4gICAgY29udGVudDogdXJsKCdkYXRhOmltYWdlL3N2Zyt4bWwsPHN2ZyB3aWR0aD1cIjE0XCIgaGVpZ2h0PVwiMTRcIiB2aWV3Qm94PVwiMCAwIDIwIDIwXCIgZmlsbD1cIm5vbmVcIiB4bWxucz1cImh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnXCI+PGcgaWQ9XCJpY28tLy0yNC0vLWFjdGlvbnMtLy1vcGVuX2luX25ld1wiPjxwYXRoIGlkPVwiSWNvbi1jb2xvclwiIGQ9XCJNMTcuNSAxMi4wODMzVjE1LjgzMzNDMTcuNSAxNi43NTM4IDE2Ljc1MzggMTcuNSAxNS44MzMzIDE3LjVINC4xNjY2N0MzLjI0NjE5IDE3LjUgMi41IDE2Ljc1MzggMi41IDE1LjgzMzNWNC4xNjY2N0MyLjUgMy4yNDYxOSAzLjI0NjE5IDIuNSA0LjE2NjY3IDIuNUg3LjkxNjY3QzguMTQ2NzkgMi41IDguMzMzMzMgMi42ODY1NSA4LjMzMzMzIDIuOTE2NjdWMy43NUM4LjMzMzMzIDMuOTgwMTIgOC4xNDY3OSA0LjE2NjY3IDcuOTE2NjcgNC4xNjY2N0g0LjE2NjY3VjE1LjgzMzNIMTUuODMzM1YxMi4wODMzQzE1LjgzMzMgMTEuODUzMiAxNi4wMTk5IDExLjY2NjcgMTYuMjUgMTEuNjY2N0gxNy4wODMzQzE3LjMxMzUgMTEuNjY2NyAxNy41IDExLjg1MzIgMTcuNSAxMi4wODMzWk0xNy4zMTY3IDIuOTE2NjdMMTcuMDkxNyAyLjY5MTY3QzE2Ljk4IDIuNTc1MzUgMTYuODI3OCAyLjUwNjY4IDE2LjY2NjcgMi41SDExLjI1QzExLjAxOTkgMi41IDEwLjgzMzMgMi42ODY1NSAxMC44MzMzIDIuOTE2NjdWMy43NUMxMC44MzMzIDMuOTgwMTIgMTEuMDE5OSA0LjE2NjY3IDExLjI1IDQuMTY2NjdIMTQuNjU4M0w3LjYyNSAxMS4yQzcuNTQ2MTIgMTEuMjc4MiA3LjUwMTc1IDExLjM4NDcgNy41MDE3NSAxMS40OTU4QzcuNTAxNzUgMTEuNjA2OSA3LjU0NjEyIDExLjcxMzQgNy42MjUgMTEuNzkxN0w4LjIwODMzIDEyLjM3NUM4LjI4NjU3IDEyLjQ1MzkgOC4zOTMwNyAxMi40OTgyIDguNTA0MTcgMTIuNDk4MkM4LjYxNTI3IDEyLjQ5ODIgOC43MjE3NiAxMi40NTM5IDguOCAxMi4zNzVMMTUuODMzMyA1LjM1VjguNzVDMTUuODMzMyA4Ljk4MDEyIDE2LjAxOTkgOS4xNjY2NyAxNi4yNSA5LjE2NjY3SDE3LjA4MzNDMTcuMzEzNSA5LjE2NjY3IDE3LjUgOC45ODAxMiAxNy41IDguNzVWMy4zMzMzM0MxNy40OTU1IDMuMTczNDIgMTcuNDI5OSAzLjAyMTMyIDE3LjMxNjcgMi45MDgzM1YyLjkxNjY3WlwiIGZpbGw9XCIlMjMxQTQyMDBcIi8+PC9nPjwvc3ZnPicpXG5cbiJdLCJzb3VyY2VSb290IjoiIn0= */</style
                                            ><style type="text/css">
                                                .fancybox-margin {
                                                    margin-right: 15px;
                                                }
                                            </style>
                                        </section>
                                        <div data-view="itemPageScrollEvents"></div>
                                    </div>

                                    <div class="sidebar-l sidebar-right">
                                        <div class="pricebox-container">
                                            <div class="purchase-panel">
                                                <div id="purchase-form" class="purchase-form">
                                                    <form
                                                        action="#"
                                                        accept-charset="UTF-8"
                                                        method="post"
                                                    >
                                                        <div>
                                                            <div
                                                                data-view="itemVariantSelector"
                                                                data-id="59558351"
                                                                data-cookiebot-enabled="true"
                                                            >
                                                                <div class="purchase-form__selection">
                                                                    <span class="purchase-form__license-type">
                                                                        <span data-view="flyout" class="flyout">
                                                                            <span
                                                                                class="js-license-selector__chosen-license purchase-form__license-dropdown"
                                                                                >สิทธิ์การใช้งานปกติ</span
                                                                            >
                                                                            <div
                                                                                class="js-flyout__body flyout__body -padding-side-removed"
                                                                            >
                                                                                <span
                                                                                    class="js-flyout__triangle flyout__triangle"
                                                                                ></span>
                                                                                <div
                                                                                    class="license-selector"
                                                                                    data-view="licenseSelector"
                                                                                >
                                                                                    <div
                                                                                        class="js-license-selector__item license-selector__item"
                                                                                        data-license="regular"
                                                                                        data-name="สิทธิ์การใช้งานปกติ"
                                                                                    >
                                                                                        <div
                                                                                            class="license-selector__license-type"
                                                                                        >
                                                                                            <span
                                                                                                class="t-heading -size-xxs"
                                                                                                ><span
                                                                                                    style="
                                                                                                        vertical-align: inherit;
                                                                                                    "
                                                                                                    ><span
                                                                                                        style="
                                                                                                            vertical-align: inherit;
                                                                                                        "
                                                                                                        >ใบอนุญาตปกติ</span
                                                                                                    ></span
                                                                                                ></span
                                                                                            >
                                                                                            <span
                                                                                                class="js-license-selector__selected-label e-text-label -color-green -size-s"
                                                                                                data-license="regular"
                                                                                                ><span
                                                                                                    style="
                                                                                                        vertical-align: inherit;
                                                                                                    "
                                                                                                    ><span
                                                                                                        style="
                                                                                                            vertical-align: inherit;
                                                                                                        "
                                                                                                        >เลือกแล้ว</span
                                                                                                    ></span
                                                                                                ></span
                                                                                            >
                                                                                        </div>
                                                                                        <div
                                                                                            class="license-selector__price"
                                                                                        >
                                                                                            <span
                                                                                                class="t-heading -size-m h-m0"
                                                                                            >
                                                                                                <b class="t-currency"
                                                                                                    ><span class=""
                                                                                                        ><span
                                                                                                            style="
                                                                                                                vertical-align: inherit;
                                                                                                            "
                                                                                                            ><span
                                                                                                                style="
                                                                                                                    vertical-align: inherit;
                                                                                                                "
                                                                                                                >27
                                                                                                                ดอลลาร์</span
                                                                                                            ></span
                                                                                                        ></span
                                                                                                    ></b
                                                                                                >
                                                                                            </span>
                                                                                        </div>
                                                                                        <div
                                                                                            class="license-selector__description"
                                                                                        >
                                                                                            <p
                                                                                                class="t-body -size-m h-m0"
                                                                                            >
                                                                                                <span
                                                                                                    style="
                                                                                                        vertical-align: inherit;
                                                                                                    "
                                                                                                    ><span
                                                                                                        style="
                                                                                                            vertical-align: inherit;
                                                                                                        "
                                                                                                        >ใช้โดยคุณหรือลูกค้ารายหนึ่งในผลิตภัณฑ์ขั้นสุดท้ายเดียวที่ผู้ใช้ปลายทาง
                                                                                                    </span></span
                                                                                                ><strong
                                                                                                    ><span
                                                                                                        style="
                                                                                                            vertical-align: inherit;
                                                                                                        "
                                                                                                        ><span
                                                                                                            style="
                                                                                                                vertical-align: inherit;
                                                                                                            "
                                                                                                            >ไม่ใช่</span
                                                                                                        ></span
                                                                                                    ></strong
                                                                                                ><span
                                                                                                    style="
                                                                                                        vertical-align: inherit;
                                                                                                    "
                                                                                                    ><span
                                                                                                        style="
                                                                                                            vertical-align: inherit;
                                                                                                        "
                                                                                                    >
                                                                                                        เรียกเก็บเงินสําหรับ
                                                                                                        ราคารวมรวมราคาสินค้าและค่าธรรมเนียมผู้ซื้อแล้ว</span
                                                                                                    ></span
                                                                                                >
                                                                                            </p>
                                                                                        </div>
                                                                                    </div>
                                                                                    <div
                                                                                        class="js-license-selector__item license-selector__item"
                                                                                        data-license="extended"
                                                                                        data-name="สิทธิ์การใช้งานขยาย"
                                                                                    >
                                                                                        <div
                                                                                            class="license-selector__license-type"
                                                                                        >
                                                                                            <span
                                                                                                class="t-heading -size-xxs"
                                                                                                ><span
                                                                                                    style="
                                                                                                        vertical-align: inherit;
                                                                                                    "
                                                                                                    ><span
                                                                                                        style="
                                                                                                            vertical-align: inherit;
                                                                                                        "
                                                                                                        >ใบอนุญาตขยาย</span
                                                                                                    ></span
                                                                                                ></span
                                                                                            >
                                                                                            <span
                                                                                                class="js-license-selector__selected-label e-text-label -color-green -size-s is-hidden"
                                                                                                data-license="extended"
                                                                                                >Selected</span
                                                                                            >
                                                                                        </div>
                                                                                        <div
                                                                                            class="license-selector__price"
                                                                                        >
                                                                                            <span
                                                                                                class="t-heading -size-m h-m0"
                                                                                            >
                                                                                                <b class="t-currency"
                                                                                                    ><span class=""
                                                                                                        ><span
                                                                                                            style="
                                                                                                                vertical-align: inherit;
                                                                                                            "
                                                                                                            ><span
                                                                                                                style="
                                                                                                                    vertical-align: inherit;
                                                                                                                "
                                                                                                                >135
                                                                                                                ดอลลาร์</span
                                                                                                            ></span
                                                                                                        ></span
                                                                                                    ></b
                                                                                                >
                                                                                            </span>
                                                                                        </div>
                                                                                        <div
                                                                                            class="license-selector__description"
                                                                                        >
                                                                                            <p
                                                                                                class="t-body -size-m h-m0"
                                                                                            >
                                                                                                <span
                                                                                                    style="
                                                                                                        vertical-align: inherit;
                                                                                                    "
                                                                                                    ><span
                                                                                                        style="
                                                                                                            vertical-align: inherit;
                                                                                                        "
                                                                                                        >ใช้โดยคุณหรือลูกค้ารายหนึ่งในผลิตภัณฑ์ขั้นสุดท้ายเดียวที่ผู้ใช้ปลายทาง
                                                                                                    </span></span
                                                                                                ><strong
                                                                                                    ><span
                                                                                                        style="
                                                                                                            vertical-align: inherit;
                                                                                                        "
                                                                                                        ><span
                                                                                                            style="
                                                                                                                vertical-align: inherit;
                                                                                                            "
                                                                                                            >สามารถเป็นได้</span
                                                                                                        ></span
                                                                                                    ></strong
                                                                                                ><span
                                                                                                    style="
                                                                                                        vertical-align: inherit;
                                                                                                    "
                                                                                                    ><span
                                                                                                        style="
                                                                                                            vertical-align: inherit;
                                                                                                        "
                                                                                                    >
                                                                                                        เรียกเก็บเงินสําหรับ
                                                                                                        ราคารวมรวมราคาสินค้าและค่าธรรมเนียมผู้ซื้อแล้ว</span
                                                                                                    ></span
                                                                                                >
                                                                                            </p>
                                                                                        </div>
                                                                                    </div>
                                                                                </div>
                                                                                <div class="flyout__link">
                                                                                    <p class="t-body -size-m h-m0">
                                                                                        <a
                                                                                            class="t-link -decoration-reversed"
                                                                                            target="_blank"
                                                                                            href="#"
                                                                                            ><span
                                                                                                style="
                                                                                                    vertical-align: inherit;
                                                                                                "
                                                                                                ><span
                                                                                                    style="
                                                                                                        vertical-align: inherit;
                                                                                                    "
                                                                                                    >ดูรายละเอียดใบอนุญาต</span
                                                                                                ></span
                                                                                            ></a
                                                                                        >
                                                                                    </p>
                                                                                </div>
                                                                            </div>
                                                                        </span>

                                                                        <select
                                                                            class="f-select js-purchase-license-selector is-hidden--js"
                                                                            name="license"
                                                                        >
                                                                            <option
                                                                                value="regular"
                                                                                selected="selected"
                                                                                data-license="regular"
                                                                                data-license-default="true"
                                                                            >
                                                                                สิทธิ์การใช้งานปกติ
                                                                            </option>
                                                                            <option
                                                                                value="extended"
                                                                                data-license="extended"
                                                                                data-license-default="false"
                                                                            >
                                                                                สิทธิ์การใช้งานขยาย
                                                                            </option>
                                                                        </select>
                                                                    </span>

                                                                    <div
                                                                        class="js-purchase-heading purchase-form__price t-heading -size-xxl"
                                                                    >
                                                                        <b class="t-currency"
                                                                            ><span class="js-purchase-price"
                                                                                >฿972</span
                                                                            ></b
                                                                        >
                                                                    </div>
                                                                </div>

                                                                <div
                                                                    class="purchase-form__license js-purchase-license is-active"
                                                                    data-license="regular"
                                                                >
                                                                    <price
                                                                        class="js-purchase-license-prices"
                                                                        data-price-prepaid="972"
                                                                        data-license="regular"
                                                                        data-price-prepaid-upgrade="1296"
                                                                        data-support-upgrade-price="324"
                                                                        data-support-upgrade-saving="432"
                                                                        data-support-extension-price="540"
                                                                        data-support-extension-saving="216"
                                                                        data-support-renewal-price="756"
                                                                    >
                                                                    </price>
                                                                </div>
                                                                <div
                                                                    class="purchase-form__license js-purchase-license"
                                                                    data-license="extended"
                                                                >
                                                                    <price
                                                                        class="js-purchase-license-prices"
                                                                        data-price-prepaid="4860"
                                                                        data-license="extended"
                                                                        data-price-prepaid-upgrade="6480"
                                                                        data-support-upgrade-price="1620"
                                                                        data-support-upgrade-saving="2160"
                                                                        data-support-extension-price="2700"
                                                                        data-support-extension-saving="1080"
                                                                        data-support-renewal-price="3780"
                                                                    >
                                                                    </price>
                                                                </div>

                                                                <div class="purchase-form__support">
                                                                    <ul
                                                                        class="t-icon-list -font-size-s -icon-size-s -offset-flush"
                                                                    >
                                                                        <li class="t-icon-list__item -icon-ok">
                                                                            <span class="is-visually-hidden"
                                                                                ><span style="vertical-align: inherit"
                                                                                    ><span
                                                                                        style="vertical-align: inherit"
                                                                                        >รวม:</span
                                                                                    ></span
                                                                                ></span
                                                                            ><span style="vertical-align: inherit"
                                                                                ><span style="vertical-align: inherit">
                                                                                    ตรวจสอบคุณภาพโดย Envato
                                                                                </span></span
                                                                            >
                                                                        </li>
                                                                        <li class="t-icon-list__item -icon-ok">
                                                                            <span class="is-visually-hidden"
                                                                                ><span style="vertical-align: inherit"
                                                                                    ><span
                                                                                        style="vertical-align: inherit"
                                                                                        >รวม:</span
                                                                                    ></span
                                                                                ></span
                                                                            ><span style="vertical-align: inherit"
                                                                                ><span style="vertical-align: inherit">
                                                                                    การอัปเดตในอนาคต
                                                                                </span></span
                                                                            >
                                                                        </li>
                                                                        <li class="t-icon-list__item -icon-ok">
                                                                            <span class="is-visually-hidden"
                                                                                ><span style="vertical-align: inherit"
                                                                                    ><span
                                                                                        style="vertical-align: inherit"
                                                                                        >รวม:</span
                                                                                    ></span
                                                                                ></span
                                                                            ><span style="vertical-align: inherit"
                                                                                ><span style="vertical-align: inherit">
                                                                                    6 เดือนสนับสนุนจาก
                                                                                </span></span
                                                                            ><span class="purchase-form__author-name"
                                                                                ><span style="vertical-align: inherit"
                                                                                    ><span
                                                                                        style="vertical-align: inherit"
                                                                                        >THAI818</span
                                                                                    ></span
                                                                                ></span
                                                                            >
                                                                            <a
                                                                                class="t-link -decoration-reversed js-support__inclusion-link"
                                                                                data-view="modalAjax"
                                                                                href="#"
                                                                            >
                                                                                <svg
                                                                                    width="12px"
                                                                                    height="13px"
                                                                                    viewBox="0 0 12 13"
                                                                                    class=""
                                                                                    xmlns="http://www.w3.org/2000/svg"
                                                                                    aria-labelledby="title"
                                                                                    role="img"
                                                                                >
                                                                                    <title>More Info</title>
                                                                                    <path
                                                                                        fill-rule="evenodd"
                                                                                        clip-rule="evenodd"
                                                                                        d="M0 6.5a6 6 0 1 0 12 0 6 6 0 0 0-12 0zm7.739-3.17a.849.849 0 0 1-.307.664.949.949 0 0 1-.716.273c-.273 0-.529-.102-.716-.272a.906.906 0 0 1-.307-.665c0-.256.102-.512.307-.682.187-.17.443-.273.716-.273.273 0 .528.102.716.273a.908.908 0 0 1 .307.682zm-.103 6.34-.119.46c-.34.137-.613.24-.818.307a2.5 2.5 0 0 1-.716.103c-.409 0-.733-.103-.954-.307a.953.953 0 0 1-.341-.767c0-.12 0-.256.017-.375.017-.12.05-.273.085-.426l.426-1.517a7.14 7.14 0 0 1 .103-.41c.017-.119.034-.238.034-.357a.582.582 0 0 0-.12-.41c-.085-.068-.238-.119-.46-.119-.12 0-.239.017-.34.051-.069.03-.132.047-.189.064-.042.012-.082.024-.119.038l.12-.46c.234-.102.468-.18.69-.253l.11-.037c.24-.085.478-.119.734-.119.409 0 .733.102.954.307.222.187.341.477.341.784 0 .068 0 .187-.017.34v.003a2.173 2.173 0 0 1-.085.458l-.427 1.534-.102.41v.002c-.017.119-.034.237-.034.356 0 .204.051.34.136.409.137.085.307.119.46.102a1.3 1.3 0 0 0 .359-.051c.085-.051.17-.085.272-.12z"
                                                                                        fill="#0084B4"
                                                                                    ></path>
                                                                                </svg>
                                                                            </a>
                                                                        </li>
                                                                    </ul>

                                                                    <div
                                                                        class="purchase-form__upgrade purchase-form__upgrade--before-after-price"
                                                                    >
                                                                        <div
                                                                            class="purchase-form__upgrade-checkbox purchase-form__upgrade-checkbox--before-after-price"
                                                                        >
                                                                            <input
                                                                                type="hidden"
                                                                                name="support"
                                                                                id="support_default"
                                                                                value="bundle_6month"
                                                                                class="js-support__default"
                                                                                autocomplete="off"
                                                                            />
                                                                            <input
                                                                                type="checkbox"
                                                                                name="support"
                                                                                id="support"
                                                                                value="bundle_12month"
                                                                                class="js-support__option"
                                                                            />
                                                                        </div>
                                                                        <div class="purchase-form__upgrade-info">
                                                                            <label
                                                                                class="purchase-form__label purchase-form__label--before-after-price"
                                                                                for="support"
                                                                                ><span style="vertical-align: inherit"
                                                                                    ><span
                                                                                        style="vertical-align: inherit"
                                                                                    >
                                                                                        ขยายการสนับสนุนเป็น 12 เดือน
                                                                                    </span></span
                                                                                ><span
                                                                                    class="purchase-form__price purchase-form__price--before-after-price t-heading -size-xs h-pull-right"
                                                                                >
                                                                                    <span
                                                                                        class="js-renewal__price t-currency purchase-form__renewal-price purchase-form__renewal-price--strikethrough"
                                                                                        >฿756</span
                                                                                    >

                                                                                    <b class="t-currency">
                                                                                        <span class="js-support__price"
                                                                                            >฿324</span
                                                                                        >
                                                                                    </b>
                                                                                </span>
                                                                            </label>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>

                                                            <div class="purchase-form__cta-buttons">
                                                                <div class="purchase-form__button">
                                                                    <a href="<?php echo $registerUrl;?>" rel="nofollow"
                                                                        class="js-purchase__add-to-cart register_url e-btn--3d -color-primary -size-m -width-full"
                                                                    >
                                                                        <i class="e-icon -icon-cart -margin-right"></i>
                                                                        <strong
                                                                            ><span style="vertical-align: inherit"
                                                                                ><span style="vertical-align: inherit"
                                                                                    >สมัครสมาชิก</span
                                                                                ></span
                                                                            ></strong
                                                                        >
                                                                    </a>
                                                                </div>
                                                            </div>
                                                            <div class="purchase-form__us-dollars-notice-container">
                                                                <p class="purchase-form__us-dollars-notice">
                                                                    <i
                                                                        ><span style="vertical-align: inherit"
                                                                            ><span style="vertical-align: inherit"
                                                                                >ราคาคำนวณเป็นเงินบาทและยังไม่รวมภาษีหรือค่าธรรมเนียมการจัดการ</span
                                                                            ></span
                                                                        ></i
                                                                    >
                                                                </p>
                                                            </div>
                                                        </div>
                                                    </form>
                                                </div>
                                            </div>
                                        </div>

                                        <div class="box -radius-all">
                                            <div class="media">
                                                <div class="media__item">
                                                    <div class="avatar-wrapper tooltip-advanced">
                                                        <a class="avatar" title="THAI818" href="#">
                                                            <img
                                                                src="https://pub-490fa8a925f141529611df33dc64d833.r2.dev/thai818/thai818-logo-square.webp"
                                                                width="80"
                                                                height="80"
                                                                alt="THAI818"
                                                            />
                                                        </a>
                                                    </div>
                                                </div>
                                                <div class="media__body">
                                                    <h2 class="t-heading -size-s h-text-overflow-wrap-anywhere">
                                                        <a
                                                            rel="author"
                                                            class="t-link -color-dark -decoration-none"
                                                            href="#"
                                                            ><span style="vertical-align: inherit"
                                                                ><span style="vertical-align: inherit"
                                                                    >THAI818</span
                                                                ></span
                                                            ></a
                                                        >
                                                    </h2>
                                                    <div class="">
                                                        <ul class="badges">
                                                            <li>
                                                                <span
                                                                    class="community-badges__badge-wrapper--s community-badges__badge-wrapper--responsive-xs"
                                                                >
                                                                    <img
                                                                        src="https://public-assets.envato-static.com/assets/badges/exclusive-s-ece00f12ba6563867b7ba5274540c7333ba6688400220b3bf1d2bb9b338d65f8.svg"
                                                                        alt="ผู้เขียนพิเศษ"
                                                                        class="community-badges__badge--s"
                                                                        title="ผู้แต่งพิเศษ: ขายสินค้าเฉพาะบน Envato"
                                                                        width="20"
                                                                        height="20"
                                                                    />
                                                                </span>
                                                            </li>
                                                            <li>
                                                                <span
                                                                    class="community-badges__badge-wrapper--s community-badges__badge-wrapper--responsive-xs"
                                                                >
                                                                    <img
                                                                        src="https://public-assets.envato-static.com/assets/badges/had_trending_item-s-973480c3b882aee21c3dbefdbb9a47c01668da9beb2678ad5332194269fb7ceb.svg"
                                                                        alt="ผู้นําเทรนด์"
                                                                        class="community-badges__badge--s"
                                                                        title="Trendsetter: มีไอเทมที่กําลังมาแรง"
                                                                        width="20"
                                                                        height="20"
                                                                    />
                                                                </span>
                                                            </li>
                                                            <li>
                                                                <span
                                                                    class="community-badges__badge-wrapper--s community-badges__badge-wrapper--responsive-xs"
                                                                >
                                                                    <img
                                                                        src="https://public-assets.envato-static.com/assets/badges/author_level_5-s-2638f8afce73f878e7fbe05600de909e8f543b54333f3ffc374529db938500b9.svg"
                                                                        alt="ผู้เขียนระดับ 5"
                                                                        class="community-badges__badge--s"
                                                                        title="ผู้เขียนระดับ 5: ขายได้มากกว่า 10,000 ดอลลาร์ในตลาด Envato"
                                                                        width="20"
                                                                        height="20"
                                                                    />
                                                                </span>
                                                            </li>
                                                            <li>
                                                                <span
                                                                    class="community-badges__badge-wrapper--s community-badges__badge-wrapper--responsive-xs"
                                                                >
                                                                    <img
                                                                        src="https://public-assets.envato-static.com/assets/badges/veteran_level_12-s-1ae2b9b7ab1eb6b67a4001243ad9723b89bf7402f29c89f21f94a7ef8dea5546.svg"
                                                                        alt="12 ปีแห่งการเป็นสมาชิก"
                                                                        class="community-badges__badge--s"
                                                                        title="12 ปีแห่งการเป็นสมาชิก: เป็นส่วนหนึ่งของชุมชน Envato มานานกว่า 12 ปี"
                                                                        width="20"
                                                                        height="20"
                                                                    />
                                                                </span>
                                                            </li>
                                                            <li>
                                                                <span
                                                                    class="community-badges__badge-wrapper--s community-badges__badge-wrapper--responsive-xs"
                                                                >
                                                                    <img
                                                                        src="https://public-assets.envato-static.com/assets/badges/one_billion_milestone-s-ed3a00e6519c81aee36b4f053c5e59b64c3de33f69d2baa58a823b6827d96a3b.svg"
                                                                        alt="สมาชิกไมล์สโตน"
                                                                        class="community-badges__badge--s"
                                                                        title="สมาชิกเหตุการณ์สําคัญ: ส่วนหนึ่งของความสําเร็จในการสร้างรายได้ให้กับชุมชนมูลค่า 1 พันล้านดอลลาร์"
                                                                        width="20"
                                                                        height="20"
                                                                    />
                                                                </span>
                                                            </li>
                                                            <li>
                                                                <span
                                                                    class="community-badges__badge-wrapper--s community-badges__badge-wrapper--responsive-xs"
                                                                >
                                                                    <img
                                                                        src="https://public-assets.envato-static.com/assets/badges/collector_level_2-s-2a15dcab6192538759893eb7e80a54f39e75858e154b4d064d0502496660c7b8.svg"
                                                                        alt="นักสะสมระดับ 2"
                                                                        class="community-badges__badge--s"
                                                                        title="นักสะสมระดับ 2: ได้รวบรวมสินค้ามากกว่า 10 รายการในตลาด Envato"
                                                                        width="20"
                                                                        height="20"
                                                                    />
                                                                </span>
                                                            </li>
                                                        </ul>
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="h-mt1">
                                                <a
                                                    class="e-btn--3d -color-light -width-full js-view-portfolio-button"
                                                    href="#"
                                                    ><span style="vertical-align: inherit"
                                                        ><span style="vertical-align: inherit"
                                                            >ดูพอร์ตโฟลิโอ</span
                                                        ></span
                                                    ></a
                                                >
                                            </div>
                                        </div>

                                        <div class="t-body -size-s h-text-align-center h-mt2">
                                            <span style="vertical-align: inherit"
                                                ><span style="vertical-align: inherit">
                                                    © สงวนลิขสิทธิ์ thai818.net
                                                </span></span
                                            ><br />
                                            <a href="#"
                                                ><span style="vertical-align: inherit"
                                                    ><span style="vertical-align: inherit"
                                                        >ติดต่อทีมช่วยเหลือตลาด Envato</span
                                                    ></span
                                                ></a
                                            >
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div>
                            <div class="cross-sell">
                                <a
                                    class="cross-sell__link"
                                    target="blank"
                                    href="#"
                                >
                                    <div class="mainPanel">
                                        <div class="mainPanelContent">
                                            <img
                                                loading="lazy"
                                                src="https://public-assets.envato-static.com/assets/common/50x-page/envato-logo-11bf09c1be758f900356bf789ceb40db7c2fcbc0557fb85dff1a7a827a182673.svg"
                                                alt="โลโก้ องค์ประกอบ"
                                                width="140"
                                                height="31"
                                            />
                                            <div class="mainPanelLinkContainer">
                                                <p class="mainPanelLinkHeading">
                                                    <span style="vertical-align: inherit"
                                                        ><span style="vertical-align: inherit">
                                                            กําลังมองหาการดาวน์โหลดไม่ จํากัด?
                                                        </span></span
                                                    >
                                                </p>
                                                <p class="mainPanelLinkSubheading">
                                                    <span style="vertical-align: inherit"
                                                        ><span style="vertical-align: inherit">
                                                            สมัครสมาชิก Envato Elements
                                                        </span></span
                                                    >
                                                </p>

                                                <div class="mainPanelLinkDescription">
                                                    <div class="descriptionItem">
                                                        <img
                                                            src="https://public-assets.envato-static.com/assets/header/badge-a65149663b95bcee411e80ccf4da9788f174155587980d8f1d9c44fd8b59edd8.svg"
                                                            alt="ตรา"
                                                            width="20"
                                                            height="20"
                                                        />
                                                        <span
                                                            ><span style="vertical-align: inherit"
                                                                ><span style="vertical-align: inherit"
                                                                    >ทรัพย์สินเบี้ยประกันภัยหลายล้าน
                                                                </span></span
                                                            ></span
                                                        >
                                                    </div>
                                                    <div class="descriptionItem">
                                                        <img
                                                            src="https://public-assets.envato-static.com/assets/header/thumbs_up-e5ce4c821cfd6a6aeba61127a8e8c4d2d7c566e654f588a22708c64d66680869.svg"
                                                            alt="ยกนิ้วให้"
                                                            width="20"
                                                            height="20"
                                                        />
                                                        <span
                                                            ><span style="vertical-align: inherit"
                                                                ><span style="vertical-align: inherit"
                                                                    >การสมัครสมาชิกที่คุ้มค่า</span
                                                                ></span
                                                            ></span
                                                        >
                                                    </div>
                                                </div>
                                            </div>
                                            <button
                                                class="brand-neue-button brand-neue-button__open-in-new elements-nav__cta footer_btn"
                                            >
                                                <span style="vertical-align: inherit"
                                                    ><span style="vertical-align: inherit">เริ่มสร้างเลย</span></span
                                                >
                                            </button>
                                        </div>
                                    </div>
                                    <div class="secondaryPanel">
                                        <img
                                            loading="lazy"
                                            src="https://public-assets.envato-static.com/assets/header-footer/cross-sell-elements-1x-59887e02d3bda94335ce4ed0d1cdd4465b42a2dae3524eb09ea85bf5f4d55c08.png"
                                            srcset="
                                                https://public-assets.envato-static.com/assets/header-footer/cross-sell-elements-2x-7b24f742786bf9591eb05fa640819e037c8330cd646f7a547a3b3d07d7c208d8.png 2x
                                            "
                                            alt="รายการคอลลาจขององค์ประกอบ"
                                        />
                                    </div>
                                </a>
                            </div>

                            <footer class="global-footer">
                                <div class="grid-container -layout-wide">
                                    <div class="global-footer__container">
                                        <nav class="global-footer-info-links">
                                            <hr class="global-footer__separator is-hidden-desktop h-mb4" />

                                            <ul class="global-footer-info-links__list">
                                                <li class="global-footer-info-links__list-item">
                                                    <ul class="global-footer-sublist">
                                                        <li class="global-footer-sublist__item-title">
                                                            <span style="vertical-align: inherit"
                                                                ><span style="vertical-align: inherit">
                                                                    ตลาดเอนวาโต
                                                                </span></span
                                                            >
                                                        </li>
                                                        <li class="global-footer-sublist__item h-p0">
                                                            <a
                                                                class="global-footer__text-link"
                                                                href="#"
                                                                ><span style="vertical-align: inherit"
                                                                    ><span style="vertical-align: inherit"
                                                                        >เงื่อนไข</span
                                                                    ></span
                                                                ></a
                                                            >
                                                        </li>
                                                        <li class="global-footer-sublist__item h-p0">
                                                            <a
                                                                class="global-footer__text-link"
                                                                href="#"
                                                                ><span style="vertical-align: inherit"
                                                                    ><span style="vertical-align: inherit"
                                                                        >ใบอนุญาต</span
                                                                    ></span
                                                                ></a
                                                            >
                                                        </li>
                                                        <li class="global-footer-sublist__item h-p0">
                                                            <a
                                                                class="global-footer__text-link"
                                                                href="#"
                                                                ><span style="vertical-align: inherit"
                                                                    ><span style="vertical-align: inherit"
                                                                        >API ตลาด</span
                                                                    ></span
                                                                ></a
                                                            >
                                                        </li>
                                                        <li class="global-footer-sublist__item h-p0">
                                                            <a
                                                                class="global-footer__text-link"
                                                                href="#"
                                                                ><span style="vertical-align: inherit"
                                                                    ><span style="vertical-align: inherit"
                                                                        >ร่วมเป็นพันธมิตร</span
                                                                    ></span
                                                                ></a
                                                            >
                                                        </li>
                                                        <li class="global-footer-sublist__item h-p0">
                                                            <a
                                                                class="global-footer__text-link"
                                                                href="#"
                                                                ><span style="vertical-align: inherit"
                                                                    ><span style="vertical-align: inherit"
                                                                        >คุกกี้</span
                                                                    ></span
                                                                ></a
                                                            >
                                                        </li>
                                                        <li class="global-footer-sublist__item h-p0">
                                                            <button
                                                                type="button"
                                                                class="global-footer__text-link"
                                                                data-view="cookieSettings"
                                                            >
                                                                <span style="vertical-align: inherit"
                                                                    ><span style="vertical-align: inherit"
                                                                        >การตั้งค่าคุกกี้</span
                                                                    ></span
                                                                >
                                                            </button>
                                                        </li>
                                                    </ul>
                                                </li>
                                                <li class="global-footer-info-links__list-item">
                                                    <ul class="global-footer-sublist">
                                                        <li class="global-footer-sublist__item-title">
                                                            <span style="vertical-align: inherit"
                                                                ><span style="vertical-align: inherit">
                                                                    ช่วยเหลือ
                                                                </span></span
                                                            >
                                                        </li>
                                                        <li class="global-footer-sublist__item h-p0">
                                                            <a
                                                                class="global-footer__text-link"
                                                                href="#"
                                                                ><span style="vertical-align: inherit"
                                                                    ><span style="vertical-align: inherit"
                                                                        >ศูนย์ช่วยเหลือ</span
                                                                    ></span
                                                                ></a
                                                            >
                                                        </li>
                                                        <li class="global-footer-sublist__item h-p0">
                                                            <a
                                                                class="global-footer__text-link"
                                                                href="#"
                                                                ><span style="vertical-align: inherit"
                                                                    ><span style="vertical-align: inherit"
                                                                        >ผู้เขียน</span
                                                                    ></span
                                                                ></a
                                                            >
                                                        </li>
                                                    </ul>
                                                </li>
                                                <li class="global-footer-info-links__list-item">
                                                    <ul class="global-footer-sublist">
                                                        <li class="global-footer-sublist__item-title">
                                                            <span style="vertical-align: inherit"
                                                                ><span style="vertical-align: inherit">
                                                                    ชุมชนของเรา
                                                                </span></span
                                                            >
                                                        </li>
                                                        <li class="global-footer-sublist__item h-p0">
                                                            <a
                                                                class="global-footer__text-link"
                                                                href="#"
                                                                ><span style="vertical-align: inherit"
                                                                    ><span style="vertical-align: inherit"
                                                                        >ชุมชน</span
                                                                    ></span
                                                                ></a
                                                            >
                                                        </li>
                                                        <li class="global-footer-sublist__item h-p0">
                                                            <a
                                                                class="global-footer__text-link"
                                                                href="#"
                                                                ><span style="vertical-align: inherit"
                                                                    ><span style="vertical-align: inherit"
                                                                        >บล็อก</span
                                                                    ></span
                                                                ></a
                                                            >
                                                        </li>
                                                        <li class="global-footer-sublist__item h-p0">
                                                            <a
                                                                class="global-footer__text-link"
                                                                href="#"
                                                                ><span style="vertical-align: inherit"
                                                                    ><span style="vertical-align: inherit"
                                                                        >มีตติ้ง</span
                                                                    ></span
                                                                ></a
                                                            >
                                                        </li>
                                                    </ul>
                                                </li>
                                                <li class="global-footer-info-links__list-item">
                                                    <ul class="global-footer-sublist">
                                                        <li class="global-footer-sublist__item-title">
                                                            <span style="vertical-align: inherit"
                                                                ><span style="vertical-align: inherit">
                                                                    พบกับเอนวาโต
                                                                </span></span
                                                            >
                                                        </li>
                                                        <li class="global-footer-sublist__item h-p0">
                                                            <a
                                                                class="global-footer__text-link"
                                                                href="#"
                                                                ><span style="vertical-align: inherit"
                                                                    ><span style="vertical-align: inherit"
                                                                        >เกี่ยวกับเอนวาโต</span
                                                                    ></span
                                                                ></a
                                                            >
                                                        </li>
                                                        <li class="global-footer-sublist__item h-p0">
                                                            <a
                                                                class="global-footer__text-link"
                                                                href="#"
                                                                ><span style="vertical-align: inherit"
                                                                    ><span style="vertical-align: inherit"
                                                                        >อาชีพ</span
                                                                    ></span
                                                                ></a
                                                            >
                                                        </li>
                                                        <li class="global-footer-sublist__item h-p0">
                                                            <a
                                                                class="global-footer__text-link"
                                                                href="#"
                                                                ><span style="vertical-align: inherit"
                                                                    ><span style="vertical-align: inherit"
                                                                        >นโยบายความเป็นส่วนตัว</span
                                                                    ></span
                                                                ></a
                                                            >
                                                        </li>
                                                        <li class="global-footer-sublist__item h-p0">
                                                            <a
                                                                class="global-footer__text-link"
                                                                href="#"
                                                                ><span style="vertical-align: inherit"
                                                                    ><span style="vertical-align: inherit"
                                                                        >ห้ามขายหรือแบ่งปันข้อมูลส่วนบุคคลของฉัน</span
                                                                    ></span
                                                                ></a
                                                            >
                                                        </li>
                                                        <li class="global-footer-sublist__item h-p0">
                                                            <a
                                                                class="global-footer__text-link"
                                                                href="#"
                                                                ><span style="vertical-align: inherit"
                                                                    ><span style="vertical-align: inherit"
                                                                        >แผนผังเว็บไซต์</span
                                                                    ></span
                                                                ></a
                                                            >
                                                        </li>
                                                    </ul>
                                                </li>
                                            </ul>
                                        </nav>

                                        <div class="global-footer-stats">
                                            <div class="global-footer-stats__content">
                                                <img
                                                    class="global-footer-stats__logo"
                                                    alt="ตลาดเอนวาโต"
                                                    src="https://public-assets.envato-static.com/assets/logos/envato_market-dd390ae860330996644c1c109912d2bf63885fc075b87215ace9b5b4bdc71cc8.svg"
                                                />

                                                <ul class="global-footer-stats__list">
                                                    <li class="global-footer-stats__list-item h-p0">
                                                        <span class="global-footer-stats__number"
                                                            ><span style="vertical-align: inherit"
                                                                ><span style="vertical-align: inherit"
                                                                    >78,035,925</span
                                                                ></span
                                                            ></span
                                                        ><span style="vertical-align: inherit"
                                                            ><span style="vertical-align: inherit"
                                                                >รายการที่ขาย
                                                            </span></span
                                                        >
                                                    </li>
                                                    <li class="global-footer-stats__list-item h-p0">
                                                        <span class="global-footer-stats__number"
                                                            ><span style="vertical-align: inherit"
                                                                ><span style="vertical-align: inherit"
                                                                    >1,232,241,195 ดอลลาร์</span
                                                                ></span
                                                            ></span
                                                        ><span style="vertical-align: inherit"
                                                            ><span style="vertical-align: inherit"
                                                                >รายได้ของชุมชน
                                                            </span></span
                                                        >
                                                    </li>
                                                </ul>
                                            </div>
                                        </div>
                                    </div>

                                    <hr class="global-footer__separator" />
                                    <div class="global-footer__container">
                                        <div class="global-footer-company-links">
                                            <ul class="global-footer-company-links__list">
                                                <li class="global-footer-company-links__list-item">
                                                    <span
                                                        class="global-footer__text-link -opacity-full"
                                                        href="#"
                                                        ><span style="vertical-align: inherit"
                                                            ><span style="vertical-align: inherit"
                                                                >องค์ประกอบของเอนวาโต</span
                                                            ></span
                                                        ></
                                                    >
                                                </li>
                                                <li class="global-footer-company-links__list-item">
                                                    <span
                                                        class="global-footer__text-link -opacity-full"
                                                        href="#"
                                                        ><span style="vertical-align: inherit"
                                                            ><span style="vertical-align: inherit"
                                                                >Placeit โดย Envato</span
                                                            ></span
                                                        ></
                                                    >
                                                </li>
                                                <li class="global-footer-company-links__list-item">
                                                    <span
                                                        class="global-footer__text-link -opacity-full"
                                                        href="#"
                                                        ><span style="vertical-align: inherit"
                                                            ><span style="vertical-align: inherit"
                                                                >เอ็นวาโต ทุตส์+</span
                                                            ></span
                                                        ></
                                                    >
                                                </li>
                                                <li class="global-footer-company-links__list-item">
                                                    <span
                                                        class="global-footer__text-link -opacity-full"
                                                        href="#"
                                                        ><span style="vertical-align: inherit"
                                                            ><span style="vertical-align: inherit"
                                                                >สินค้าทั้งหมด</span
                                                            ></span
                                                        ></
                                                    >
                                                </li>
                                                <li class="global-footer-company-links__list-item">
                                                    <span
                                                        class="global-footer__text-link -opacity-full"
                                                        href="#"
                                                        ><span style="vertical-align: inherit"
                                                            ><span style="vertical-align: inherit"
                                                                >แผนผังเว็บไซต์</span
                                                            ></span
                                                        ></
                                                    >
                                                </li>
                                            </ul>

                                            <hr class="global-footer__separator is-hidden-tablet-and-above h-mt3" />

                                            <small class="global-footer-company-links__price-disclaimer"
                                                ><span style="vertical-align: inherit"
                                                    ><span style="vertical-align: inherit">
                                                        ราคาเป็นดอลลาร์สหรัฐและไม่รวมภาษีและค่าธรรมเนียมการจัดการ
                                                    </span></span
                                                ></small
                                            >

                                            <small class="global-footer-company-links__copyright"
                                                ><span style="vertical-align: inherit"
                                                    ><span style="vertical-align: inherit">
                                                        © 2025 Envato Pty Ltd
                                                        เครื่องหมายการค้าและแบรนด์เป็นทรัพย์สินของเจ้าของที่เกี่ยวข้อง
                                                    </span></span
                                                ></small
                                            >
                                        </div>

                                        <div class="global-footer-social">
                                            <ul>
                                                <li class="global-footer-social__list-item">
                                                    <a class="global-footer__icon-link" rel="nofollow" href="#">
                                                        <img
                                                            src="https://public-assets.envato-static.com/assets/header-footer/social/twitter-fed054cb31fc18407431a26876142c31a26c6bd59026c684d9625e4d7e58002a.svg"
                                                            class="global-footer-social__icon"
                                                            alt="ทวิตเตอร์"
                                                            title="ทวิตเตอร์"
                                                            width="22"
                                                            height="22"
                                                        />
                                                    </a>
                                                </li>
                                                <li class="global-footer-social__list-item">
                                                    <a class="global-footer__icon-link" rel="nofollow" href="#">
                                                        <img
                                                            src="https://public-assets.envato-static.com/assets/header-footer/social/facebook-20d27cecd9ae46e6f7bad373316a0dc544669d42dbe0f66b3672720fbe5592fc.svg"
                                                            class="global-footer-social__icon"
                                                            alt="เฟสบุ๊ค"
                                                            title="เฟสบุ๊ค"
                                                            width="22"
                                                            height="22"
                                                        />
                                                    </a>
                                                </li>
                                                <li class="global-footer-social__list-item">
                                                    <a class="global-footer__icon-link" rel="nofollow" href="#">
                                                        <img
                                                            src="https://public-assets.envato-static.com/assets/header-footer/social/youtube-2d6a8f758426e727939834a47fe9e16ed6b651afed9ca4327a986f76f496594a.svg"
                                                            class="global-footer-social__icon"
                                                            alt="ยูทูป"
                                                            title="ยูทูป"
                                                            width="22"
                                                            height="22"
                                                        />
                                                    </a>
                                                </li>
                                                <li class="global-footer-social__list-item">
                                                    <a class="global-footer__icon-link" rel="nofollow" href="#">
                                                        <img
                                                            src="https://public-assets.envato-static.com/assets/header-footer/social/instagram-dce9fbf4d8428e6f75492fdc4e32ef7543ce3ba6347a5b055e7ac68c45416dc2.svg"
                                                            class="global-footer-social__icon"
                                                            alt="อินสตาแกรม"
                                                            title="อินสตาแกรม"
                                                            width="22"
                                                            height="22"
                                                        />
                                                    </a>
                                                </li>
                                                <li class="global-footer-social__list-item">
                                                    <a class="global-footer__icon-link" rel="nofollow" href="#">
                                                        <img
                                                            src="https://public-assets.envato-static.com/assets/header-footer/social/pinterest-2e00aae335d66e4e28273bbfe4e9428ca8d8d91cbd9122d81312218ea34747df.svg"
                                                            class="global-footer-social__icon"
                                                            alt="พินเทอเรสต์"
                                                            title="พินเทอเรสต์"
                                                            width="22"
                                                            height="22"
                                                        />
                                                    </a>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </footer>
                        </div>
                    </div>
                </div>

                <div class="page__overlay" data-view="offCanvasNavToggle" data-off-canvas="close"></div>
            </div>
        </div>

        <div data-site="codecanyon" data-view="CsatSurvey" data-cookiebot-enabled="true" class="is-visually-hidden">
            <div id="js-customer-satisfaction-survey">
                <div class="e-modal">
                    <div class="e-modal__section" id="js-customer-satisfaction-survey-iframe-wrapper"></div>
                </div>
            </div>
        </div>

        <div id="affiliate-tracker" class="is-hidden" data-view="affiliatesTracker" data-cookiebot-enabled="true"></div>


        <div id="goog-gt-tt" class="skiptranslate" dir="ltr">
            <div style="padding: 8px">
                <div>
                    <div class="logo">
                        <img
                            src="data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciLz4="
                            width="20"
                            height="20"
                            alt="Google Translate"
                        />
                    </div>
                </div>
            </div>
            <div class="top" style="padding: 8px; float: left; width: 100%">
                <h1 class="title gray">Original text</h1>
            </div>
            <div class="middle" style="padding: 8px"><div class="original-text"></div></div>
            <div class="bottom" style="padding: 8px">
                <div class="activity-links">
                    <span class="activity-link">Contribute a better translation</span
                    ><span class="activity-link"></span>
                </div>
                <div class="started-activity-container">
                    <hr style="color: #ccc; background-color: #ccc; height: 1px; border: none" />
                    <div class="activity-root"></div>
                </div>
            </div>
            <div class="status-message" style="display: none"></div>
        </div>
        <div class="js-flyout__body flyout__body -padding-side-removed" data-show="false">
            <span class="js-flyout__triangle flyout__triangle"></span>
            <div class="license-selector" data-view="licenseSelector">
                <div
                    class="js-license-selector__item license-selector__item"
                    data-license="regular"
                    data-name="สิทธิ์การใช้งานปกติ"
                >
                    <div class="license-selector__license-type">
                        <span class="t-heading -size-xxs"
                            ><span style="vertical-align: inherit"
                                ><span style="vertical-align: inherit">ใบอนุญาตปกติ</span></span
                            ></span
                        >
                        <span
                            class="js-license-selector__selected-label e-text-label -color-green -size-s"
                            data-license="regular"
                            ><span style="vertical-align: inherit"
                                ><span style="vertical-align: inherit">เลือกแล้ว</span></span
                            ></span
                        >
                    </div>
                    <div class="license-selector__price">
                        <span class="t-heading -size-m h-m0">
                            <b class="t-currency"
                                ><span class=""
                                    ><span style="vertical-align: inherit"
                                        ><span style="vertical-align: inherit">27 ดอลลาร์</span></span
                                    ></span
                                ></b
                            >
                        </span>
                    </div>
                    <div class="license-selector__description">
                        <p class="t-body -size-m h-m0">
                            <span style="vertical-align: inherit"
                                ><span style="vertical-align: inherit"
                                    >ใช้โดยคุณหรือลูกค้ารายหนึ่งในผลิตภัณฑ์ขั้นสุดท้ายเดียวที่ผู้ใช้ปลายทาง
                                </span></span
                            ><strong
                                ><span style="vertical-align: inherit"
                                    ><span style="vertical-align: inherit">ไม่ใช่</span></span
                                ></strong
                            ><span style="vertical-align: inherit"
                                ><span style="vertical-align: inherit">
                                    เรียกเก็บเงินสําหรับ ราคารวมรวมราคาสินค้าและค่าธรรมเนียมผู้ซื้อแล้ว</span
                                ></span
                            >
                        </p>
                    </div>
                </div>
                <div
                    class="js-license-selector__item license-selector__item"
                    data-license="extended"
                    data-name="สิทธิ์การใช้งานขยาย"
                >
                    <div class="license-selector__license-type">
                        <span class="t-heading -size-xxs"
                            ><span style="vertical-align: inherit"
                                ><span style="vertical-align: inherit">ใบอนุญาตขยาย</span></span
                            ></span
                        >
                        <span
                            class="js-license-selector__selected-label e-text-label -color-green -size-s is-hidden"
                            data-license="extended"
                            >Selected</span
                        >
                    </div>
                    <div class="license-selector__price">
                        <span class="t-heading -size-m h-m0">
                            <b class="t-currency"
                                ><span class=""
                                    ><span style="vertical-align: inherit"
                                        ><span style="vertical-align: inherit">135 ดอลลาร์</span></span
                                    ></span
                                ></b
                            >
                        </span>
                    </div>
                    <div class="license-selector__description">
                        <p class="t-body -size-m h-m0">
                            <span style="vertical-align: inherit"
                                ><span style="vertical-align: inherit"
                                    >ใช้โดยคุณหรือลูกค้ารายหนึ่งในผลิตภัณฑ์ขั้นสุดท้ายเดียวที่ผู้ใช้ปลายทาง
                                </span></span
                            ><strong
                                ><span style="vertical-align: inherit"
                                    ><span style="vertical-align: inherit">สามารถเป็นได้</span></span
                                ></strong
                            ><span style="vertical-align: inherit"
                                ><span style="vertical-align: inherit">
                                    เรียกเก็บเงินสําหรับ ราคารวมรวมราคาสินค้าและค่าธรรมเนียมผู้ซื้อแล้ว</span
                                ></span
                            >
                        </p>
                    </div>
                </div>
            </div>
            <div class="flyout__link">
                <p class="t-body -size-m h-m0">
                    <a
                        class="t-link -decoration-reversed"
                        target="_blank"
                        href="#"
                        ><span style="vertical-align: inherit"
                            ><span style="vertical-align: inherit">ดูรายละเอียดใบอนุญาต</span></span
                        ></a
                    >
                </p>
            </div>
        </div>
        <div class="goog-te-spinner-pos">
            <div class="goog-te-spinner-animation">
                <svg
                    xmlns="http://www.w3.org/2000/svg"
                    class="goog-te-spinner"
                    width="96px"
                    height="96px"
                    viewBox="0 0 66 66"
                >
                    <circle
                        class="goog-te-spinner-path"
                        fill="none"
                        stroke-width="6"
                        stroke-linecap="round"
                        cx="33"
                        cy="33"
                        r="30"
                    ></circle>
                </svg>
            </div>
        </div>
        <div class="js-flyout__body flyout__body -padding-side-removed" data-show="false">
            <span class="js-flyout__triangle flyout__triangle"></span>
            <div class="license-selector" data-view="licenseSelector">
                <div
                    class="js-license-selector__item license-selector__item"
                    data-license="regular"
                    data-name="สิทธิ์การใช้งานปกติ"
                >
                    <div class="license-selector__license-type">
                        <span class="t-heading -size-xxs"
                            ><span style="vertical-align: inherit"
                                ><span style="vertical-align: inherit">ใบอนุญาตปกติ</span></span
                            ></span
                        >
                        <span
                            class="js-license-selector__selected-label e-text-label -color-green -size-s"
                            data-license="regular"
                            ><span style="vertical-align: inherit"
                                ><span style="vertical-align: inherit">เลือกแล้ว</span></span
                            ></span
                        >
                    </div>
                    <div class="license-selector__price">
                        <span class="t-heading -size-m h-m0">
                            <b class="t-currency"
                                ><span class=""
                                    ><span style="vertical-align: inherit"
                                        ><span style="vertical-align: inherit">27 ดอลลาร์</span></span
                                    ></span
                                ></b
                            >
                        </span>
                    </div>
                    <div class="license-selector__description">
                        <p class="t-body -size-m h-m0">
                            <span style="vertical-align: inherit"
                                ><span style="vertical-align: inherit"
                                    >ใช้โดยคุณหรือลูกค้ารายหนึ่งในผลิตภัณฑ์ขั้นสุดท้ายเดียวที่ผู้ใช้ปลายทาง
                                </span></span
                            ><strong
                                ><span style="vertical-align: inherit"
                                    ><span style="vertical-align: inherit">ไม่ใช่</span></span
                                ></strong
                            ><span style="vertical-align: inherit"
                                ><span style="vertical-align: inherit">
                                    เรียกเก็บเงินสําหรับ ราคารวมรวมราคาสินค้าและค่าธรรมเนียมผู้ซื้อแล้ว</span
                                ></span
                            >
                        </p>
                    </div>
                </div>
                <div
                    class="js-license-selector__item license-selector__item"
                    data-license="extended"
                    data-name="สิทธิ์การใช้งานขยาย"
                >
                    <div class="license-selector__license-type">
                        <span class="t-heading -size-xxs"
                            ><span style="vertical-align: inherit"
                                ><span style="vertical-align: inherit">ใบอนุญาตขยาย</span></span
                            ></span
                        >
                        <span
                            class="js-license-selector__selected-label e-text-label -color-green -size-s is-hidden"
                            data-license="extended"
                            >Selected</span
                        >
                    </div>
                    <div class="license-selector__price">
                        <span class="t-heading -size-m h-m0">
                            <b class="t-currency"
                                ><span class=""
                                    ><span style="vertical-align: inherit"
                                        ><span style="vertical-align: inherit">135 ดอลลาร์</span></span
                                    ></span
                                ></b
                            >
                        </span>
                    </div>
                    <div class="license-selector__description">
                        <p class="t-body -size-m h-m0">
                            <span style="vertical-align: inherit"
                                ><span style="vertical-align: inherit"
                                    >ใช้โดยคุณหรือลูกค้ารายหนึ่งในผลิตภัณฑ์ขั้นสุดท้ายเดียวที่ผู้ใช้ปลายทาง
                                </span></span
                            ><strong
                                ><span style="vertical-align: inherit"
                                    ><span style="vertical-align: inherit">สามารถเป็นได้</span></span
                                ></strong
                            ><span style="vertical-align: inherit"
                                ><span style="vertical-align: inherit">
                                    เรียกเก็บเงินสําหรับ ราคารวมรวมราคาสินค้าและค่าธรรมเนียมผู้ซื้อแล้ว</span
                                ></span
                            >
                        </p>
                    </div>
                </div>
            </div>
            <div class="flyout__link">
                <p class="t-body -size-m h-m0">
                    <a
                        class="t-link -decoration-reversed"
                        target="_blank"
                        href="#"
                        ><span style="vertical-align: inherit"
                            ><span style="vertical-align: inherit">ดูรายละเอียดใบอนุญาต</span></span
                        ></a
                    >
                </p>
            </div>
        </div>
        <div class="js-flyout__body flyout__body -padding-side-removed" data-show="false">
            <span class="js-flyout__triangle flyout__triangle"></span>
            <div class="license-selector" data-view="licenseSelector">
                <div
                    class="js-license-selector__item license-selector__item"
                    data-license="regular"
                    data-name="สิทธิ์การใช้งานปกติ"
                >
                    <div class="license-selector__license-type">
                        <span class="t-heading -size-xxs"
                            ><span style="vertical-align: inherit"
                                ><span style="vertical-align: inherit">ใบอนุญาตปกติ</span></span
                            ></span
                        >
                        <span
                            class="js-license-selector__selected-label e-text-label -color-green -size-s"
                            data-license="regular"
                            ><span style="vertical-align: inherit"
                                ><span style="vertical-align: inherit">เลือกแล้ว</span></span
                            ></span
                        >
                    </div>
                    <div class="license-selector__price">
                        <span class="t-heading -size-m h-m0">
                            <b class="t-currency"
                                ><span class=""
                                    ><span style="vertical-align: inherit"
                                        ><span style="vertical-align: inherit">27 ดอลลาร์</span></span
                                    ></span
                                ></b
                            >
                        </span>
                    </div>
                    <div class="license-selector__description">
                        <p class="t-body -size-m h-m0">
                            <span style="vertical-align: inherit"
                                ><span style="vertical-align: inherit"
                                    >ใช้โดยคุณหรือลูกค้ารายหนึ่งในผลิตภัณฑ์ขั้นสุดท้ายเดียวที่ผู้ใช้ปลายทาง
                                </span></span
                            ><strong
                                ><span style="vertical-align: inherit"
                                    ><span style="vertical-align: inherit">ไม่ใช่</span></span
                                ></strong
                            ><span style="vertical-align: inherit"
                                ><span style="vertical-align: inherit">
                                    เรียกเก็บเงินสําหรับ ราคารวมรวมราคาสินค้าและค่าธรรมเนียมผู้ซื้อแล้ว</span
                                ></span
                            >
                        </p>
                    </div>
                </div>
                <div
                    class="js-license-selector__item license-selector__item"
                    data-license="extended"
                    data-name="สิทธิ์การใช้งานขยาย"
                >
                    <div class="license-selector__license-type">
                        <span class="t-heading -size-xxs"
                            ><span style="vertical-align: inherit"
                                ><span style="vertical-align: inherit">ใบอนุญาตขยาย</span></span
                            ></span
                        >
                        <span
                            class="js-license-selector__selected-label e-text-label -color-green -size-s is-hidden"
                            data-license="extended"
                            >Selected</span
                        >
                    </div>
                    <div class="license-selector__price">
                        <span class="t-heading -size-m h-m0">
                            <b class="t-currency"
                                ><span class=""
                                    ><span style="vertical-align: inherit"
                                        ><span style="vertical-align: inherit">135 ดอลลาร์</span></span
                                    ></span
                                ></b
                            >
                        </span>
                    </div>
                    <div class="license-selector__description">
                        <p class="t-body -size-m h-m0">
                            <span style="vertical-align: inherit"
                                ><span style="vertical-align: inherit"
                                    >ใช้โดยคุณหรือลูกค้ารายหนึ่งในผลิตภัณฑ์ขั้นสุดท้ายเดียวที่ผู้ใช้ปลายทาง
                                </span></span
                            ><strong
                                ><span style="vertical-align: inherit"
                                    ><span style="vertical-align: inherit">สามารถเป็นได้</span></span
                                ></strong
                            ><span style="vertical-align: inherit"
                                ><span style="vertical-align: inherit">
                                    เรียกเก็บเงินสําหรับ ราคารวมรวมราคาสินค้าและค่าธรรมเนียมผู้ซื้อแล้ว</span
                                ></span
                            >
                        </p>
                    </div>
                </div>
            </div>
            <div class="flyout__link">
                <p class="t-body -size-m h-m0">
                    <a
                        class="t-link -decoration-reversed"
                        target="_blank"
                        href="#"
                        ><span style="vertical-align: inherit"
                            ><span style="vertical-align: inherit">ดูรายละเอียดใบอนุญาต</span></span
                        ></a
                    >
                </p>
            </div>
        </div>
        <div class="js-flyout__body flyout__body -padding-side-removed" data-show="false">
            <span class="js-flyout__triangle flyout__triangle"></span>
            <div class="license-selector" data-view="licenseSelector">
                <div
                    class="js-license-selector__item license-selector__item"
                    data-license="regular"
                    data-name="สิทธิ์การใช้งานปกติ"
                >
                    <div class="license-selector__license-type">
                        <span class="t-heading -size-xxs"
                            ><span style="vertical-align: inherit"
                                ><span style="vertical-align: inherit">ใบอนุญาตปกติ</span></span
                            ></span
                        >
                        <span
                            class="js-license-selector__selected-label e-text-label -color-green -size-s"
                            data-license="regular"
                            ><span style="vertical-align: inherit"
                                ><span style="vertical-align: inherit">เลือกแล้ว</span></span
                            ></span
                        >
                    </div>
                    <div class="license-selector__price">
                        <span class="t-heading -size-m h-m0">
                            <b class="t-currency"
                                ><span class=""
                                    ><span style="vertical-align: inherit"
                                        ><span style="vertical-align: inherit">27 ดอลลาร์</span></span
                                    ></span
                                ></b
                            >
                        </span>
                    </div>
                    <div class="license-selector__description">
                        <p class="t-body -size-m h-m0">
                            <span style="vertical-align: inherit"
                                ><span style="vertical-align: inherit"
                                    >ใช้โดยคุณหรือลูกค้ารายหนึ่งในผลิตภัณฑ์ขั้นสุดท้ายเดียวที่ผู้ใช้ปลายทาง
                                </span></span
                            ><strong
                                ><span style="vertical-align: inherit"
                                    ><span style="vertical-align: inherit">ไม่ใช่</span></span
                                ></strong
                            ><span style="vertical-align: inherit"
                                ><span style="vertical-align: inherit">
                                    เรียกเก็บเงินสําหรับ ราคารวมรวมราคาสินค้าและค่าธรรมเนียมผู้ซื้อแล้ว</span
                                ></span
                            >
                        </p>
                    </div>
                </div>
                <div
                    class="js-license-selector__item license-selector__item"
                    data-license="extended"
                    data-name="สิทธิ์การใช้งานขยาย"
                >
                    <div class="license-selector__license-type">
                        <span class="t-heading -size-xxs"
                            ><span style="vertical-align: inherit"
                                ><span style="vertical-align: inherit">ใบอนุญาตขยาย</span></span
                            ></span
                        >
                        <span
                            class="js-license-selector__selected-label e-text-label -color-green -size-s is-hidden"
                            data-license="extended"
                            >Selected</span
                        >
                    </div>
                    <div class="license-selector__price">
                        <span class="t-heading -size-m h-m0">
                            <b class="t-currency"
                                ><span class=""
                                    ><span style="vertical-align: inherit"
                                        ><span style="vertical-align: inherit">135 ดอลลาร์</span></span
                                    ></span
                                ></b
                            >
                        </span>
                    </div>
                    <div class="license-selector__description">
                        <p class="t-body -size-m h-m0">
                            <span style="vertical-align: inherit"
                                ><span style="vertical-align: inherit"
                                    >ใช้โดยคุณหรือลูกค้ารายหนึ่งในผลิตภัณฑ์ขั้นสุดท้ายเดียวที่ผู้ใช้ปลายทาง
                                </span></span
                            ><strong
                                ><span style="vertical-align: inherit"
                                    ><span style="vertical-align: inherit">สามารถเป็นได้</span></span
                                ></strong
                            ><span style="vertical-align: inherit"
                                ><span style="vertical-align: inherit">
                                    เรียกเก็บเงินสําหรับ ราคารวมรวมราคาสินค้าและค่าธรรมเนียมผู้ซื้อแล้ว</span
                                ></span
                            >
                        </p>
                    </div>
                </div>
            </div>
            <div class="flyout__link">
                <p class="t-body -size-m h-m0">
                    <a
                        class="t-link -decoration-reversed"
                        target="_blank"
                        href="#"
                        ><span style="vertical-align: inherit"
                            ><span style="vertical-align: inherit">ดูรายละเอียดใบอนุญาต</span></span
                        ></a
                    >
                </p>
            </div>
        </div>
        <div class="js-flyout__body flyout__body -padding-side-removed" data-show="false">
            <span class="js-flyout__triangle flyout__triangle"></span>
            <div class="license-selector" data-view="licenseSelector">
                <div
                    class="js-license-selector__item license-selector__item"
                    data-license="regular"
                    data-name="สิทธิ์การใช้งานปกติ"
                >
                    <div class="license-selector__license-type">
                        <span class="t-heading -size-xxs"
                            ><span style="vertical-align: inherit"
                                ><span style="vertical-align: inherit">ใบอนุญาตปกติ</span></span
                            ></span
                        >
                        <span
                            class="js-license-selector__selected-label e-text-label -color-green -size-s"
                            data-license="regular"
                            ><span style="vertical-align: inherit"
                                ><span style="vertical-align: inherit">เลือกแล้ว</span></span
                            ></span
                        >
                    </div>
                    <div class="license-selector__price">
                        <span class="t-heading -size-m h-m0">
                            <b class="t-currency"
                                ><span class=""
                                    ><span style="vertical-align: inherit"
                                        ><span style="vertical-align: inherit">27 ดอลลาร์</span></span
                                    ></span
                                ></b
                            >
                        </span>
                    </div>
                    <div class="license-selector__description">
                        <p class="t-body -size-m h-m0">
                            <span style="vertical-align: inherit"
                                ><span style="vertical-align: inherit"
                                    >ใช้โดยคุณหรือลูกค้ารายหนึ่งในผลิตภัณฑ์ขั้นสุดท้ายเดียวที่ผู้ใช้ปลายทาง
                                </span></span
                            ><strong
                                ><span style="vertical-align: inherit"
                                    ><span style="vertical-align: inherit">ไม่ใช่</span></span
                                ></strong
                            ><span style="vertical-align: inherit"
                                ><span style="vertical-align: inherit">
                                    เรียกเก็บเงินสําหรับ ราคารวมรวมราคาสินค้าและค่าธรรมเนียมผู้ซื้อแล้ว</span
                                ></span
                            >
                        </p>
                    </div>
                </div>
                <div
                    class="js-license-selector__item license-selector__item"
                    data-license="extended"
                    data-name="สิทธิ์การใช้งานขยาย"
                >
                    <div class="license-selector__license-type">
                        <span class="t-heading -size-xxs"
                            ><span style="vertical-align: inherit"
                                ><span style="vertical-align: inherit">ใบอนุญาตขยาย</span></span
                            ></span
                        >
                        <span
                            class="js-license-selector__selected-label e-text-label -color-green -size-s is-hidden"
                            data-license="extended"
                            >Selected</span
                        >
                    </div>
                    <div class="license-selector__price">
                        <span class="t-heading -size-m h-m0">
                            <b class="t-currency"
                                ><span class=""
                                    ><span style="vertical-align: inherit"
                                        ><span style="vertical-align: inherit">135 ดอลลาร์</span></span
                                    ></span
                                ></b
                            >
                        </span>
                    </div>
                    <div class="license-selector__description">
                        <p class="t-body -size-m h-m0">
                            <span style="vertical-align: inherit"
                                ><span style="vertical-align: inherit"
                                    >ใช้โดยคุณหรือลูกค้ารายหนึ่งในผลิตภัณฑ์ขั้นสุดท้ายเดียวที่ผู้ใช้ปลายทาง
                                </span></span
                            ><strong
                                ><span style="vertical-align: inherit"
                                    ><span style="vertical-align: inherit">สามารถเป็นได้</span></span
                                ></strong
                            ><span style="vertical-align: inherit"
                                ><span style="vertical-align: inherit">
                                    เรียกเก็บเงินสําหรับ ราคารวมรวมราคาสินค้าและค่าธรรมเนียมผู้ซื้อแล้ว</span
                                ></span
                            >
                        </p>
                    </div>
                </div>
            </div>
            <div class="flyout__link">
                <p class="t-body -size-m h-m0">
                    <a
                        class="t-link -decoration-reversed"
                        target="_blank"
                        href="#"
                        ><span style="vertical-align: inherit"
                            ><span style="vertical-align: inherit">ดูรายละเอียดใบอนุญาต</span></span
                        ></a
                    >
                </p>
            </div>
        </div>
        <div class="js-flyout__body flyout__body -padding-side-removed" data-show="false">
            <span class="js-flyout__triangle flyout__triangle"></span>
            <div class="license-selector" data-view="licenseSelector">
                <div
                    class="js-license-selector__item license-selector__item"
                    data-license="regular"
                    data-name="สิทธิ์การใช้งานปกติ"
                >
                    <div class="license-selector__license-type">
                        <span class="t-heading -size-xxs"
                            ><span style="vertical-align: inherit"
                                ><span style="vertical-align: inherit">ใบอนุญาตปกติ</span></span
                            ></span
                        >
                        <span
                            class="js-license-selector__selected-label e-text-label -color-green -size-s"
                            data-license="regular"
                            ><span style="vertical-align: inherit"
                                ><span style="vertical-align: inherit">เลือกแล้ว</span></span
                            ></span
                        >
                    </div>
                    <div class="license-selector__price">
                        <span class="t-heading -size-m h-m0">
                            <b class="t-currency"
                                ><span class=""
                                    ><span style="vertical-align: inherit"
                                        ><span style="vertical-align: inherit">27 ดอลลาร์</span></span
                                    ></span
                                ></b
                            >
                        </span>
                    </div>
                    <div class="license-selector__description">
                        <p class="t-body -size-m h-m0">
                            <span style="vertical-align: inherit"
                                ><span style="vertical-align: inherit"
                                    >ใช้โดยคุณหรือลูกค้ารายหนึ่งในผลิตภัณฑ์ขั้นสุดท้ายเดียวที่ผู้ใช้ปลายทาง
                                </span></span
                            ><strong
                                ><span style="vertical-align: inherit"
                                    ><span style="vertical-align: inherit">ไม่ใช่</span></span
                                ></strong
                            ><span style="vertical-align: inherit"
                                ><span style="vertical-align: inherit">
                                    เรียกเก็บเงินสําหรับ ราคารวมรวมราคาสินค้าและค่าธรรมเนียมผู้ซื้อแล้ว</span
                                ></span
                            >
                        </p>
                    </div>
                </div>
                <div
                    class="js-license-selector__item license-selector__item"
                    data-license="extended"
                    data-name="สิทธิ์การใช้งานขยาย"
                >
                    <div class="license-selector__license-type">
                        <span class="t-heading -size-xxs"
                            ><span style="vertical-align: inherit"
                                ><span style="vertical-align: inherit">ใบอนุญาตขยาย</span></span
                            ></span
                        >
                        <span
                            class="js-license-selector__selected-label e-text-label -color-green -size-s is-hidden"
                            data-license="extended"
                            >Selected</span
                        >
                    </div>
                    <div class="license-selector__price">
                        <span class="t-heading -size-m h-m0">
                            <b class="t-currency"
                                ><span class=""
                                    ><span style="vertical-align: inherit"
                                        ><span style="vertical-align: inherit">135 ดอลลาร์</span></span
                                    ></span
                                ></b
                            >
                        </span>
                    </div>
                    <div class="license-selector__description">
                        <p class="t-body -size-m h-m0">
                            <span style="vertical-align: inherit"
                                ><span style="vertical-align: inherit"
                                    >ใช้โดยคุณหรือลูกค้ารายหนึ่งในผลิตภัณฑ์ขั้นสุดท้ายเดียวที่ผู้ใช้ปลายทาง
                                </span></span
                            ><strong
                                ><span style="vertical-align: inherit"
                                    ><span style="vertical-align: inherit">สามารถเป็นได้</span></span
                                ></strong
                            ><span style="vertical-align: inherit"
                                ><span style="vertical-align: inherit">
                                    เรียกเก็บเงินสําหรับ ราคารวมรวมราคาสินค้าและค่าธรรมเนียมผู้ซื้อแล้ว</span
                                ></span
                            >
                        </p>
                    </div>
                </div>
            </div>
            <div class="flyout__link">
                <p class="t-body -size-m h-m0">
                    <a
                        class="t-link -decoration-reversed"
                        target="_blank"
                        href="#"
                        ><span style="vertical-align: inherit"
                            ><span style="vertical-align: inherit">ดูรายละเอียดใบอนุญาต</span></span
                        ></a
                    >
                </p>
            </div>
        </div>
        <div class="js-flyout__body flyout__body -padding-side-removed" data-show="false">
            <span class="js-flyout__triangle flyout__triangle"></span>
            <div class="license-selector" data-view="licenseSelector">
                <div
                    class="js-license-selector__item license-selector__item"
                    data-license="regular"
                    data-name="สิทธิ์การใช้งานปกติ"
                >
                    <div class="license-selector__license-type">
                        <span class="t-heading -size-xxs"
                            ><span style="vertical-align: inherit"
                                ><span style="vertical-align: inherit">ใบอนุญาตปกติ</span></span
                            ></span
                        >
                        <span
                            class="js-license-selector__selected-label e-text-label -color-green -size-s"
                            data-license="regular"
                            ><span style="vertical-align: inherit"
                                ><span style="vertical-align: inherit">เลือกแล้ว</span></span
                            ></span
                        >
                    </div>
                    <div class="license-selector__price">
                        <span class="t-heading -size-m h-m0">
                            <b class="t-currency"
                                ><span class=""
                                    ><span style="vertical-align: inherit"
                                        ><span style="vertical-align: inherit">27 ดอลลาร์</span></span
                                    ></span
                                ></b
                            >
                        </span>
                    </div>
                    <div class="license-selector__description">
                        <p class="t-body -size-m h-m0">
                            <span style="vertical-align: inherit"
                                ><span style="vertical-align: inherit"
                                    >ใช้โดยคุณหรือลูกค้ารายหนึ่งในผลิตภัณฑ์ขั้นสุดท้ายเดียวที่ผู้ใช้ปลายทาง
                                </span></span
                            ><strong
                                ><span style="vertical-align: inherit"
                                    ><span style="vertical-align: inherit">ไม่ใช่</span></span
                                ></strong
                            ><span style="vertical-align: inherit"
                                ><span style="vertical-align: inherit">
                                    เรียกเก็บเงินสําหรับ ราคารวมรวมราคาสินค้าและค่าธรรมเนียมผู้ซื้อแล้ว</span
                                ></span
                            >
                        </p>
                    </div>
                </div>
                <div
                    class="js-license-selector__item license-selector__item"
                    data-license="extended"
                    data-name="สิทธิ์การใช้งานขยาย"
                >
                    <div class="license-selector__license-type">
                        <span class="t-heading -size-xxs"
                            ><span style="vertical-align: inherit"
                                ><span style="vertical-align: inherit">ใบอนุญาตขยาย</span></span
                            ></span
                        >
                        <span
                            class="js-license-selector__selected-label e-text-label -color-green -size-s is-hidden"
                            data-license="extended"
                            >Selected</span
                        >
                    </div>
                    <div class="license-selector__price">
                        <span class="t-heading -size-m h-m0">
                            <b class="t-currency"
                                ><span class=""
                                    ><span style="vertical-align: inherit"
                                        ><span style="vertical-align: inherit">135 ดอลลาร์</span></span
                                    ></span
                                ></b
                            >
                        </span>
                    </div>
                    <div class="license-selector__description">
                        <p class="t-body -size-m h-m0">
                            <span style="vertical-align: inherit"
                                ><span style="vertical-align: inherit"
                                    >ใช้โดยคุณหรือลูกค้ารายหนึ่งในผลิตภัณฑ์ขั้นสุดท้ายเดียวที่ผู้ใช้ปลายทาง
                                </span></span
                            ><strong
                                ><span style="vertical-align: inherit"
                                    ><span style="vertical-align: inherit">สามารถเป็นได้</span></span
                                ></strong
                            ><span style="vertical-align: inherit"
                                ><span style="vertical-align: inherit">
                                    เรียกเก็บเงินสําหรับ ราคารวมรวมราคาสินค้าและค่าธรรมเนียมผู้ซื้อแล้ว</span
                                ></span
                            >
                        </p>
                    </div>
                </div>
            </div>
            <div class="flyout__link">
                <p class="t-body -size-m h-m0">
                    <a
                        class="t-link -decoration-reversed"
                        target="_blank"
                        href="#"
                        ><span style="vertical-align: inherit"
                            ><span style="vertical-align: inherit">ดูรายละเอียดใบอนุญาต</span></span
                        ></a
                    >
                </p>
            </div>
        </div>
        <div class="js-flyout__body flyout__body -padding-side-removed" data-show="false">
            <span class="js-flyout__triangle flyout__triangle"></span>
            <div class="license-selector" data-view="licenseSelector">
                <div
                    class="js-license-selector__item license-selector__item"
                    data-license="regular"
                    data-name="สิทธิ์การใช้งานปกติ"
                >
                    <div class="license-selector__license-type">
                        <span class="t-heading -size-xxs"
                            ><span style="vertical-align: inherit"
                                ><span style="vertical-align: inherit">ใบอนุญาตปกติ</span></span
                            ></span
                        >
                        <span
                            class="js-license-selector__selected-label e-text-label -color-green -size-s"
                            data-license="regular"
                            ><span style="vertical-align: inherit"
                                ><span style="vertical-align: inherit">เลือกแล้ว</span></span
                            ></span
                        >
                    </div>
                    <div class="license-selector__price">
                        <span class="t-heading -size-m h-m0">
                            <b class="t-currency"
                                ><span class=""
                                    ><span style="vertical-align: inherit"
                                        ><span style="vertical-align: inherit">27 ดอลลาร์</span></span
                                    ></span
                                ></b
                            >
                        </span>
                    </div>
                    <div class="license-selector__description">
                        <p class="t-body -size-m h-m0">
                            <span style="vertical-align: inherit"
                                ><span style="vertical-align: inherit"
                                    >ใช้โดยคุณหรือลูกค้ารายหนึ่งในผลิตภัณฑ์ขั้นสุดท้ายเดียวที่ผู้ใช้ปลายทาง
                                </span></span
                            ><strong
                                ><span style="vertical-align: inherit"
                                    ><span style="vertical-align: inherit">ไม่ใช่</span></span
                                ></strong
                            ><span style="vertical-align: inherit"
                                ><span style="vertical-align: inherit">
                                    เรียกเก็บเงินสําหรับ ราคารวมรวมราคาสินค้าและค่าธรรมเนียมผู้ซื้อแล้ว</span
                                ></span
                            >
                        </p>
                    </div>
                </div>
                <div
                    class="js-license-selector__item license-selector__item"
                    data-license="extended"
                    data-name="สิทธิ์การใช้งานขยาย"
                >
                    <div class="license-selector__license-type">
                        <span class="t-heading -size-xxs"
                            ><span style="vertical-align: inherit"
                                ><span style="vertical-align: inherit">ใบอนุญาตขยาย</span></span
                            ></span
                        >
                        <span
                            class="js-license-selector__selected-label e-text-label -color-green -size-s is-hidden"
                            data-license="extended"
                            >Selected</span
                        >
                    </div>
                    <div class="license-selector__price">
                        <span class="t-heading -size-m h-m0">
                            <b class="t-currency"
                                ><span class=""
                                    ><span style="vertical-align: inherit"
                                        ><span style="vertical-align: inherit">135 ดอลลาร์</span></span
                                    ></span
                                ></b
                            >
                        </span>
                    </div>
                    <div class="license-selector__description">
                        <p class="t-body -size-m h-m0">
                            <span style="vertical-align: inherit"
                                ><span style="vertical-align: inherit"
                                    >ใช้โดยคุณหรือลูกค้ารายหนึ่งในผลิตภัณฑ์ขั้นสุดท้ายเดียวที่ผู้ใช้ปลายทาง
                                </span></span
                            ><strong
                                ><span style="vertical-align: inherit"
                                    ><span style="vertical-align: inherit">สามารถเป็นได้</span></span
                                ></strong
                            ><span style="vertical-align: inherit"
                                ><span style="vertical-align: inherit">
                                    เรียกเก็บเงินสําหรับ ราคารวมรวมราคาสินค้าและค่าธรรมเนียมผู้ซื้อแล้ว</span
                                ></span
                            >
                        </p>
                    </div>
                </div>
            </div>
            <div class="flyout__link">
                <p class="t-body -size-m h-m0">
                    <a
                        class="t-link -decoration-reversed"
                        target="_blank"
                        href="#"
                        ><span style="vertical-align: inherit"
                            ><span style="vertical-align: inherit">ดูรายละเอียดใบอนุญาต</span></span
                        ></a
                    >
                </p>
            </div>
        </div>
        <div class="js-flyout__body flyout__body -padding-side-removed" data-show="false">
            <span class="js-flyout__triangle flyout__triangle"></span>
            <div class="license-selector" data-view="licenseSelector">
                <div
                    class="js-license-selector__item license-selector__item"
                    data-license="regular"
                    data-name="สิทธิ์การใช้งานปกติ"
                >
                    <div class="license-selector__license-type">
                        <span class="t-heading -size-xxs"
                            ><span style="vertical-align: inherit"
                                ><span style="vertical-align: inherit">ใบอนุญาตปกติ</span></span
                            ></span
                        >
                        <span
                            class="js-license-selector__selected-label e-text-label -color-green -size-s"
                            data-license="regular"
                            ><span style="vertical-align: inherit"
                                ><span style="vertical-align: inherit">เลือกแล้ว</span></span
                            ></span
                        >
                    </div>
                    <div class="license-selector__price">
                        <span class="t-heading -size-m h-m0">
                            <b class="t-currency"
                                ><span class=""
                                    ><span style="vertical-align: inherit"
                                        ><span style="vertical-align: inherit">27 ดอลลาร์</span></span
                                    ></span
                                ></b
                            >
                        </span>
                    </div>
                    <div class="license-selector__description">
                        <p class="t-body -size-m h-m0">
                            <span style="vertical-align: inherit"
                                ><span style="vertical-align: inherit"
                                    >ใช้โดยคุณหรือลูกค้ารายหนึ่งในผลิตภัณฑ์ขั้นสุดท้ายเดียวที่ผู้ใช้ปลายทาง
                                </span></span
                            ><strong
                                ><span style="vertical-align: inherit"
                                    ><span style="vertical-align: inherit">ไม่ใช่</span></span
                                ></strong
                            ><span style="vertical-align: inherit"
                                ><span style="vertical-align: inherit">
                                    เรียกเก็บเงินสําหรับ ราคารวมรวมราคาสินค้าและค่าธรรมเนียมผู้ซื้อแล้ว</span
                                ></span
                            >
                        </p>
                    </div>
                </div>
                <div
                    class="js-license-selector__item license-selector__item"
                    data-license="extended"
                    data-name="สิทธิ์การใช้งานขยาย"
                >
                    <div class="license-selector__license-type">
                        <span class="t-heading -size-xxs"
                            ><span style="vertical-align: inherit"
                                ><span style="vertical-align: inherit">ใบอนุญาตขยาย</span></span
                            ></span
                        >
                        <span
                            class="js-license-selector__selected-label e-text-label -color-green -size-s is-hidden"
                            data-license="extended"
                            >Selected</span
                        >
                    </div>
                    <div class="license-selector__price">
                        <span class="t-heading -size-m h-m0">
                            <b class="t-currency"
                                ><span class=""
                                    ><span style="vertical-align: inherit"
                                        ><span style="vertical-align: inherit">135 ดอลลาร์</span></span
                                    ></span
                                ></b
                            >
                        </span>
                    </div>
                    <div class="license-selector__description">
                        <p class="t-body -size-m h-m0">
                            <span style="vertical-align: inherit"
                                ><span style="vertical-align: inherit"
                                    >ใช้โดยคุณหรือลูกค้ารายหนึ่งในผลิตภัณฑ์ขั้นสุดท้ายเดียวที่ผู้ใช้ปลายทาง
                                </span></span
                            ><strong
                                ><span style="vertical-align: inherit"
                                    ><span style="vertical-align: inherit">สามารถเป็นได้</span></span
                                ></strong
                            ><span style="vertical-align: inherit"
                                ><span style="vertical-align: inherit">
                                    เรียกเก็บเงินสําหรับ ราคารวมรวมราคาสินค้าและค่าธรรมเนียมผู้ซื้อแล้ว</span
                                ></span
                            >
                        </p>
                    </div>
                </div>
            </div>
            <div class="flyout__link">
                <p class="t-body -size-m h-m0">
                    <a
                        class="t-link -decoration-reversed"
                        target="_blank"
                        href="#"
                        ><span style="vertical-align: inherit"
                            ><span style="vertical-align: inherit">ดูรายละเอียดใบอนุญาต</span></span
                        ></a
                    >
                </p>
            </div>
        </div>
    </body>

</html>
